﻿namespace ProjectBuilder
{
  public enum ProjectBuilderType
  {
    Dtos,
    Controllers,
    Services,
    Tests
  }
}
