﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("ModelsMap")]
    public class ModelsMap
    {
        [XmlAttribute("Version")]
        public int Version { set; get; }

        [XmlAttribute("Namespace")]
        public string Namespace { set; get; }

        [XmlAttribute("Target")]
        public string Target { set; get; }

        [XmlAttribute("Scope")]
        public string Scope { set; get; }

        [XmlElement("Entity")]
        public List<Entity> Entities { set; get; }
    }
}
