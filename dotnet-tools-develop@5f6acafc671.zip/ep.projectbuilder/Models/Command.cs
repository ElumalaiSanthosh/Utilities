﻿using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("Commands")]
    public class Command
    {
        [XmlAttribute("Name")]
        public string Name { set; get; }
    }
}
