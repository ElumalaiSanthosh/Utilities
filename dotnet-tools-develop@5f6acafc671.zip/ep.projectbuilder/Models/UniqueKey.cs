﻿using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("UniqueKey")]
    public class UniqueKey
    {
        [XmlAttribute("Name")]
        public string Name { set; get; }

        [XmlAttribute("Properties")]
        public string Properties { set; get; }
    }
}
