﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("Entity")]
    [XmlType("Entity")]
    public class Entity
    {
        public Entity()
        {
            EnableCache = false;
        }

        [XmlAttribute("Name")]
        public string Name { set; get; }

        [XmlAttribute("PluralName")]
        public string PluralName { set; get; }

        [XmlAttribute("Table")]
        public string Table { set; get; }
        
        [XmlAttribute("Schema")]
        public string Schema { set; get; }

        [XmlAttribute("JsonName")]
        public string JsonName { set; get; }

        [XmlAttribute("HasDataset")]
        public bool HasDataset { set; get; }

        [XmlAttribute("Visibility")]
        public string Visibility { set; get; }

        [XmlAttribute("DbName")]
        public string DbName { set; get; }

        [XmlElement("Property")]
        public List<Property> Properties { set; get; }

        [XmlElement("Relationship")]
        public List<Relationship> Relationships { set; get; }

        [XmlElement("Command")]
        public List<Command> Commands { set; get; }

        [XmlElement("ExcludeTest")]
        public List<ExcludeTest> ExcludeTests { set; get; }

        [XmlElement("UniqueKey")]
        public List<UniqueKey> UniqueKeys { set; get; }

        [XmlAttribute("EnableCache")]
        public bool EnableCache { set; get; }
    }
}
