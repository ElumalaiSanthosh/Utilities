﻿using System;
using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("Entity")]
    public class CreatedFile
    {
        [XmlAttribute("Name")]
        public string Name { get; set; }
        [XmlAttribute("ModifiedTime")]
        public DateTime ModifiedTime { get; set; }
        [XmlAttribute("BuilderVersion")]
        public string BuilderVersion { get; set; }
    }
}
