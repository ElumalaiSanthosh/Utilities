﻿using ProjectBuilder.Extensions;
using System.Collections;
using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("Property")]
    public class Property
    {
        [XmlAttribute("Name")]
        public string Name { set; get; }

        [XmlAttribute("Type")]
        public string Type { set; get; }

        [XmlAttribute("DbName")]
        public string DbName { set; get; }

        [XmlAttribute("DbType")]
        public string DbType { set; get; }

        [XmlAttribute("Size")]
        public int Size { set; get; }

        [XmlAttribute("Precision")]
        public int Precision { set; get; }

        [XmlAttribute("NullValue")]
        public string NullValue { set; get; }

        [XmlAttribute("AllowNull")]
        public bool AllowNull { set; get; }

        [XmlAttribute("Ordinal")]
        public int Ordinal { set; get; }

        [XmlAttribute("PrimaryKey")]
        public bool PrimaryKey { set; get; }

        [XmlAttribute("IsDbGenerated")]
        public bool IsDbGenerated { set; get; }

        [XmlAttribute("JsonName")]
        public string JsonName { set; get; }

        [XmlAttribute("Description")]
        public string Description { set; get; }

        public string EntityType()
        {
            return Type.GetEntityType();
        }        
    }
}
