﻿namespace ProjectBuilder.Models
{
    public class BuilderData
    {
      public string OutPath { get; set; }
      public string Type { get; set; }

      public ModelsMap ModelsMap { get; set; }
  }
}
