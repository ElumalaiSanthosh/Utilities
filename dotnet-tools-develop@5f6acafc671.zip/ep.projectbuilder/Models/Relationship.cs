﻿using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("Relationship")]
    public class Relationship
    {
        [XmlAttribute("Name")]
        public string Name { set; get; }

        [XmlAttribute("PluralName")]
        public string PluralName { set; get; }

        [XmlAttribute("DbName")]
        public string DbName { set; get; }

        [XmlAttribute("Properties")]
        public string Property { set; get; }

        [XmlAttribute("RelatedEntity")]
        public string RelatedEntity { set; get; }

        [XmlAttribute("RelatedProperty")]
        public string RelatedProperty { set; get; }

        [XmlAttribute("PropertyName")]
        public string PropertyName { set; get; }

        [XmlAttribute("Type")]
        public string Type { set; get; }

        [XmlAttribute("Cardinality")]
        public string Cardinality { set; get; }

        [XmlAttribute("LazyLoad")]
        public bool LazyLoad { set; get; }

        [XmlAttribute("JsonName")]
        public string JsonName { set; get; }
    }
}
