﻿using System.Xml.Serialization;

namespace ProjectBuilder.Models
{
    [XmlRoot("ExcludeTest")]
    public class ExcludeTest
    {
        [XmlAttribute("Name")]
        public string Name { set; get; }
    }
}
