﻿using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    internal interface IWriter
    {
        void Create(ref bool firstPass);

        string GetFileName();

        string GetProjectPath();

        string GetProjectPathAndName();

        string GetFilePath();

        string GetFilePathAndName();

        bool VerifyVisibility();

        Entity GetEntity();
    }
}
