﻿using System.IO;
using ProjectBuilder.Extensions;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers.TestCases
{
    public class ControllerCommandTestWriter : WriterBase, IWriter
    {
        internal ControllerCommandTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}CommandControllerTest.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                    Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Data;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Controllers;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using Microsoft.Extensions.DependencyInjection;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Http;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Controller.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");
                outputFile.WriteLine($"    public partial class {Entity.PluralName}ControllerTests");
                outputFile.WriteLine("    {");

                if (Entity.HasCommand("create"))
                {
                    outputFile.WriteLine("");
                    BuildPostAsync(outputFile);
                }

                if (Entity.HasCommand("update"))
                {
                    outputFile.WriteLine("");
                    BuildPutAsync(outputFile);
                }

                if (Entity.HasCommand("delete"))
                {
                    outputFile.WriteLine("");
                    BuildDeleteAsync(outputFile);
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        public void BuildPostAsync(StreamWriter outputFile)
        {
            outputFile.WriteLine("        [TestMethod]");
            outputFile.WriteLine($"        public void {Entity.PluralName}PostAsync()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
            outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => new {Entity.Name}());");
            outputFile.WriteLine($"            service.Setup(d => d.PostAsync(It.IsAny<{Entity.Name}>(), It.IsAny<IDbTransaction>(), It.IsAny<bool>())).Returns(lookupTask);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var result = controller.PostAsync(new {Entity.Name}());");
            outputFile.WriteLine("            var createdResult = result.Result as CreatedResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(createdResult);");
            outputFile.WriteLine("            Assert.AreEqual(201, createdResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
            outputFile.WriteLine($"            service.Setup(d => d.PostAsync(It.IsAny<{Entity.Name}>(), It.IsAny<IDbTransaction>(), It.IsAny<bool>())).Returns(lookupTask);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            result = controller.PostAsync(new {Entity.Name}());");
            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
            outputFile.WriteLine("        }");
        }

        public void BuildPutAsync(StreamWriter outputFile)
        {
            outputFile.WriteLine("        [TestMethod]");
            outputFile.WriteLine($"        public void {Entity.PluralName}PutAsync()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
            outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => new {Entity.Name}());");
            outputFile.WriteLine($"            service.Setup(d => d.PutAsync({Entity.PrimaryKeysForMoq()}, It.IsAny<{Entity.Name}>(), It.IsAny<IDbTransaction>(), It.IsAny<bool>())).Returns(lookupTask);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var result = controller.PutAsync({Entity.PrimaryKeyValuesForTest()}, new {Entity.Name}());");
            outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
            outputFile.WriteLine($"            service.Setup(d => d.PutAsync({Entity.PrimaryKeysForMoq()}, It.IsAny<{Entity.Name}>(), It.IsAny<IDbTransaction>(), It.IsAny<bool>())).Returns(lookupTask);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            result = controller.PutAsync({Entity.PrimaryKeyValuesForTest()}, new {Entity.Name}());");
            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
            outputFile.WriteLine("        }");
        }

        public void BuildDeleteAsync(StreamWriter outputFile)
        {
            outputFile.WriteLine("        [TestMethod]");
            outputFile.WriteLine($"        public void {Entity.PluralName}DeleteAsync()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
            outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var lookupTask = Task<bool>.Factory.StartNew(() => true);");
            outputFile.WriteLine($"            service.Setup(d => d.DeleteAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var result = controller.DeleteAsync({Entity.PrimaryKeyValuesForTest()});");
            outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            lookupTask = Task<bool>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
            outputFile.WriteLine($"            service.Setup(d => d.DeleteAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            result = controller.DeleteAsync({Entity.PrimaryKeyValuesForTest()});");
            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
            outputFile.WriteLine("        }");
        }
    }
}