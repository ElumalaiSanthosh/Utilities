﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers.TestCases
{
    public class DtoTestWriter : WriterBase, IWriter
    {
        internal DtoTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}Test.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Dtos;

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
              Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine("");
                outputFile.WriteLine("namespace " + EntityMap.Namespace + ".Models.Dtos.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestClass]");
                outputFile.WriteLine($"    public partial class {Entity.Name}Tests");
                outputFile.WriteLine("    {");

                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine($"        public void {Entity.Name}ConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            {Entity.Name} dto = new {Entity.Name}({GetDtoConstructorValuesForTest(Entity)});");
                outputFile.WriteLine("            Assert.IsNotNull(dto);");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine($"        public void {Entity.Name}PropertyTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            {Entity.Name} dto = new {Entity.Name}");
                outputFile.WriteLine("            {");

                foreach (Property p in Entity.Properties)
                {
                    outputFile.WriteLine($"                {p.GetPropertyWithValueForTest()},");
                }
                outputFile.WriteLine("            };");
                outputFile.WriteLine("");

                foreach (Property p in Entity.Properties)
                {
                    outputFile.WriteLine($"            {GetPropertyAssertCheck(p)};");
                }
                outputFile.WriteLine("        }");

                if (Entity.Relationships != null && Entity.Relationships.Any())
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        [TestMethod]");
                    outputFile.WriteLine($"        public void {Entity.Name}RelationshipTest()");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            {Entity.Name} dto = new {Entity.Name}");
                    outputFile.WriteLine("            {");

                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal" ||
                            rel.Cardinality == "OneToOne")
                        {
                            continue;
                        }
                        outputFile.WriteLine($"                {GetRelationshipWithValueForTest(rel)}");
                    }
                    outputFile.WriteLine("            };");
                    outputFile.WriteLine("");

                    foreach (Relationship r in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(e => e.Name == r.RelatedEntity).Visibility == "internal" ||
                            r.Cardinality == "OneToOne")
                        {
                            continue;
                        }

                        outputFile.WriteLine($"            {GetRelationshipAssertTest(r)};");
                    }
                    outputFile.WriteLine("        }");
                }
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private string GetDtoConstructorValuesForTest(Entity entity)
        {
            IList<string> values = new List<string>();

            foreach (Property p in entity.Properties)
            {
                values.Add(p.TestValue());
            }

            foreach (Relationship r in entity.Relationships)
            {
                if (EntityMap.Entities.First(e => e.Name == r.RelatedEntity).Visibility == "internal" ||
                            r.Cardinality == "OneToOne")
                {
                    continue;
                }

                if (r.Cardinality == "OneToMany")
                {
                    values.Add($"new List<{r.RelatedEntity}>" + "{" + $"new {r.RelatedEntity}()" + "}");
                    continue;
                }

                values.Add($"new {r.RelatedEntity}()");
            }

            return string.Join(", ", values);
        }
        
        private string GetRelationshipWithValueForTest(Relationship r)
        {
            if (r.Cardinality == "OneToMany")
            {
                return $"{r.PluralName} = new List<{r.RelatedEntity}>" +"{" + $"new {r.RelatedEntity}()" + "},";
            }

            return $"{r.Name} = new {r.RelatedEntity}(),";
        }

        private string GetPropertyAssertCheck(Property p)
        {
            return $"Assert.AreEqual({p.TestValue()}, dto.{p.Name})";
        }

        private string GetRelationshipAssertTest(Relationship r)
        {
            if (r.Cardinality == "OneToMany")
            {
                return $"Assert.AreEqual(1, dto.{r.PluralName}.Count)";
            }

            return $"Assert.IsNotNull(dto.{r.Name})";
        }
    }
}
