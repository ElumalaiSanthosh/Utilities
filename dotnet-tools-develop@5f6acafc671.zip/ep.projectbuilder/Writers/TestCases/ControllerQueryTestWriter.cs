﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Extensions;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers.TestCases
{
    public class ControllerQueryTestWriter : WriterBase, IWriter
    {
        internal ControllerQueryTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}QueryControllerTest.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                    Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Data;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Controllers;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using Microsoft.Extensions.DependencyInjection;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Builder;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Http;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Routing;");
                outputFile.WriteLine("using Microsoft.AspNet.OData;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Builder;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Extensions;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Query;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Query.Validators;");
                outputFile.WriteLine("using Microsoft.OData.UriParser;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Controller.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestClass]");
                outputFile.WriteLine($"    public partial class {Entity.PluralName}ControllerTests");
                outputFile.WriteLine("    {");

                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine($"        public void {Entity.PluralName}ControllerConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
                outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
                outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
                outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
                outputFile.WriteLine("");
                outputFile.WriteLine("            Assert.IsNotNull(controller);");
                outputFile.WriteLine("        }");

                if (Entity.HasCommand("get"))
                {
                    outputFile.WriteLine("");
                    if (Entity.HasPrimaryKey())
                    {
                        BuildGetAsync(outputFile);
                    }

                    BuildOneToOne(outputFile);
                    BuildGetMany(outputFile);
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        public void BuildGetAsync(StreamWriter outputFile)
        {
            outputFile.WriteLine("        [TestMethod]");
            outputFile.WriteLine($"        public void {Entity.PluralName}GetAsync()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
            outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => new {Entity.Name}());");
            outputFile.Write($"            service.Setup(d => d.GetAsync({Entity.PrimaryKeysForMoq()}");

            if (Entity.HasDataset)
            {
                outputFile.Write(", It.IsAny<IDbTransaction>()");

                if (Entity.HasOneToMany())
                {
                    outputFile.Write(", It.IsAny<bool>()");
                }
            }

            outputFile.Write($")).Returns(lookupTask);{Environment.NewLine}");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var result = controller.GetAsync({Entity.PrimaryKeyValuesForTest()});");
            outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            lookupTask = Task<{Entity.Name}>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
            outputFile.Write($"            service.Setup(d => d.GetAsync({Entity.PrimaryKeysForMoq()}");

            if (Entity.HasDataset)
            {
                outputFile.Write(", It.IsAny<IDbTransaction>()");

                if (Entity.HasOneToMany())
                {
                    outputFile.Write(", It.IsAny<bool>()");
                }
            }

            outputFile.Write($")).Returns(lookupTask);{Environment.NewLine}");

            outputFile.WriteLine("");
            outputFile.WriteLine($"            result = controller.GetAsync({Entity.PrimaryKeyValuesForTest()});");
            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
            outputFile.WriteLine("        }");
        }

        public void BuildOneToOne(StreamWriter outputFile)
        {
            IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");
            if (relationships.Any())
            {
                foreach (var r in relationships)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        [TestMethod]");
                    outputFile.WriteLine($"        public void GetMany{Entity.PluralName}By{r.PropertyName}AsyncTest()");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
                    outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
                    outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
                    outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"            var lookupTask = Task<List<{Entity.Name}>>.Factory.StartNew(() => new List<{Entity.Name}>() " + "{ { new " + Entity.Name + "() } });");
                    outputFile.WriteLine($"            service.Setup(d => d.GetBy{r.PropertyName}Async(It.IsAny<{r.Type.GetEntityType()}>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
                    outputFile.WriteLine("            lookupTask.Wait();");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"            var result = controller.GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipValuesForTest(Entity)});");
                    outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            Assert.IsNotNull(okResult);");
                    outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
                    outputFile.WriteLine("");

                    outputFile.WriteLine($"            lookupTask = Task<List<{Entity.Name}>>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
                    outputFile.WriteLine($"            service.Setup(d => d.GetBy{r.PropertyName}Async(It.IsAny<{r.Type.GetEntityType()}>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"            result = controller.GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipValuesForTest(Entity)});");
                    outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            Assert.IsNotNull(noResult);");
                    outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
                    outputFile.WriteLine("        }");
                }
            }
        }

        //public void BuildUnique(StreamWriter outputFile)
        //{
        //    if (Entity.UniqueKeys.Any())
        //    {
        //        foreach (var key in Entity.UniqueKeys)
        //        {
        //            List<string> props = key.Properties.Split(",").ToList();
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine("        [TestMethod]");
        //            outputFile.WriteLine($"        public void GetBy{props.UniqueName()}AsyncTest()");
        //            outputFile.WriteLine("        {");
        //            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
        //            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(service.Object);");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine($"            var lookupTask = Task<QueryResults<{Entity.Name}>>.Factory.StartNew(() => new QueryResults<{Entity.Name}>());");
        //            outputFile.WriteLine("            service.Setup(d => d.GetManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
        //            outputFile.WriteLine("            lookupTask.Wait();");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine($"            var result = controller.GetBy{props.UniqueName()}Async({r.RelationshipValuesForTest(Entity)});");
        //            outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
        //            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine($"            lookupTask = Task<QueryResults<{Entity.Name}>>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
        //            outputFile.WriteLine("            service.Setup(d => d.GetManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine($"            result = controller.GetBy{props.UniqueName()}Async({r.RelationshipValuesForTest(Entity)});");
        //            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
        //            outputFile.WriteLine("");
        //            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
        //            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
        //            outputFile.WriteLine("        }");
        //        }
        //    }
        //}

        public void BuildGetMany(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [TestMethod]");
            outputFile.WriteLine("        public void GetManyAsyncTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            var service = new Mock<I{Entity.Name}Service>();");
            outputFile.WriteLine("            var collection = new ServiceCollection();");
            outputFile.WriteLine("            collection.AddOData();");
            outputFile.WriteLine("            collection.AddODataQueryFilter();");
            outputFile.WriteLine("            collection.AddTransient<ODataUriResolver>();");
            outputFile.WriteLine("            collection.AddTransient<ODataQueryValidator>();");
            outputFile.WriteLine("            collection.AddTransient<TopQueryValidator>();");
            outputFile.WriteLine("            collection.AddTransient<FilterQueryValidator>();");
            outputFile.WriteLine("            collection.AddTransient<SkipQueryValidator>();");
            outputFile.WriteLine("            collection.AddTransient<OrderByQueryValidator>();");
            outputFile.WriteLine("            var provider = collection.BuildServiceProvider();");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
            outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
            outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller(config.Object, service.Object, cache.Object);");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var routeBuilder = new RouteBuilder(Mock.Of<IApplicationBuilder>(x => x.ApplicationServices == provider));");
            outputFile.WriteLine("            routeBuilder.EnableDependencyInjection();");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var modelBuilder = new ODataConventionModelBuilder(provider);");
            outputFile.WriteLine($"            modelBuilder.EntitySet<{Entity.Name}>(\"{ Entity.Name}\");");
            outputFile.WriteLine("            var model = modelBuilder.GetEdmModel();");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var uri = new Uri(\"http://localhost/api/" + Entity.Name + "/1?$select=Id\");");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var httpContext = new DefaultHttpContext");
            outputFile.WriteLine("            {");
            outputFile.WriteLine("                RequestServices = provider");
            outputFile.WriteLine("            };");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var context = new ODataQueryContext(model, typeof({Entity.Name}), new Microsoft.AspNet.OData.Routing.ODataPath());");
            outputFile.WriteLine($"            var options = new ODataQueryOptions<{Entity.Name}>(context, httpContext.Request);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            var lookupTask = Task<QueryResults<{Entity.Name}>>.Factory.StartNew(() => new QueryResults<{Entity.Name}>() " + "{ Items = new List<" + Entity.Name + ">() { new " + Entity.Name + "() } });");
            outputFile.WriteLine("            service.Setup(d => d.GetManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var result = controller.GetManyAsync(options);");
            outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine("            var lookupList = Task<QueryResults<object>>.Factory.StartNew(() => new QueryResults<object>{Items = new List<object>{ new " + Entity.Name + "()}});");
            outputFile.WriteLine("            service.Setup(d => d.GetListAsync(It.IsAny<string>(), It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupList);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine("            result = controller.GetManyAsync(options, \"" + Entity.Properties.First().Name + "\");");
            outputFile.WriteLine("            okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine("            service.Setup(d => d.GetDynamicObjectsAsync(It.IsAny<List<string>>(), It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupList);");
            outputFile.WriteLine("            lookupTask.Wait();");
            outputFile.WriteLine("");
            outputFile.WriteLine("            result = controller.GetManyAsync(options, \"" + Entity.PropertyNameForTest() + "\");");
            outputFile.WriteLine("            okResult = result.Result as OkObjectResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(okResult);");
            outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            lookupTask = Task<QueryResults<{Entity.Name}>>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, \"No Content\"));");
            outputFile.WriteLine("            service.Setup(d => d.GetManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);");
            outputFile.WriteLine("");
            outputFile.WriteLine("            result = controller.GetManyAsync(options);");
            outputFile.WriteLine("            var noResult = result.Result as NoContentResult;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(noResult);");
            outputFile.WriteLine("            Assert.AreEqual(204, noResult.StatusCode);");
            outputFile.WriteLine("        }");
        }
    }
}