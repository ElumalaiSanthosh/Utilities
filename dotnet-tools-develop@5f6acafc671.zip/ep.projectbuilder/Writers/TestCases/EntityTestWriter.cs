﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers.TestCases
{
    public class EntityTestWriter : WriterBase, IWriter
    {
        internal EntityTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}EntityTest.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Entities;

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
              Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("");
                outputFile.WriteLine("namespace " + EntityMap.Namespace + ".Models.Entities.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestClass]");
                outputFile.WriteLine($"    public partial class {Entity.Name}EntityTests");
                outputFile.WriteLine("    {");

                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine($"        public void {Entity.Name}EntityConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            {Entity.Name}Entity entity = new {Entity.Name}Entity({GetDtoConstructorValuesForTest(Entity)});");
                outputFile.WriteLine("            Assert.IsNotNull(entity);");
                outputFile.WriteLine("");
                outputFile.WriteLine($"            entity = new {Entity.Name}Entity();");
                outputFile.WriteLine("            Assert.IsNotNull(entity.EntityDto);");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine($"        public void {Entity.Name}EntityPropertyTest()");
                outputFile.WriteLine("        {");

                if (Entity.Visibility == "public")
                {
                    outputFile.WriteLine($"            {Entity.Name}Entity entity = new {Entity.Name}Entity");
                    outputFile.WriteLine("            {");

                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"                {GetPropertyWithValueForTest(p)}");
                    }
                    outputFile.WriteLine("            };");
                }
                else
                {
                    outputFile.WriteLine($"            {Entity.Name}Entity entity = new {Entity.Name}Entity(new {Entity.Name}");
                    outputFile.WriteLine("            {");

                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"                {GetPropertyWithValueForTest(p)}");
                    }
                    outputFile.WriteLine("            });");
                }
                outputFile.WriteLine("");

                foreach (Property p in Entity.Properties)
                {
                    outputFile.WriteLine($"            {GetPropertyAssertCheck(p)};");
                }

                if (Entity.HasPrimaryKey())
                {
                    outputFile.WriteLine($"            Assert.AreEqual({Entity.CreateHashCodesForAssert()}, entity.GetHashCode());");
                }

                if (Entity.Visibility == "public")
                {
                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"            {GetPropertyWithValueForTest(p, "entity")}");
                    }

                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"            {GetPropertyAssertCheck(p)};");
                    }

                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"            {GetPropertyWithValueForTest2(p, "entity")}");
                    }

                    foreach (Property p in Entity.Properties)
                    {
                        outputFile.WriteLine($"            {GetPropertyAssertCheck2(p)};");
                    }
                }

                outputFile.WriteLine("        }");

                if (Entity.Relationships != null && Entity.Relationships.Any())
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        [TestMethod]");
                    outputFile.WriteLine($"        public void {Entity.Name}EntityRelationshipTest()");
                    outputFile.WriteLine("        {");

                    if (Entity.Visibility == "public")
                    {
                        outputFile.WriteLine($"            {Entity.Name}Entity entity = new {Entity.Name}Entity");
                        outputFile.WriteLine("            {");

                        foreach (Relationship rel in Entity.Relationships)
                        {
                            if (EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                            {
                                continue;
                            }

                            outputFile.WriteLine($"                {GetRelationshipWithValueForTest(rel)}");
                        }
                        outputFile.WriteLine("            };");
                    }
                    else
                    {
                        outputFile.WriteLine($"            {Entity.Name}Entity entity = new {Entity.Name}Entity(new {Entity.Name}");
                        outputFile.WriteLine("            {");

                        foreach (Relationship rel in Entity.Relationships)
                        {
                            if (EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                            {
                                continue;
                            }
                            outputFile.WriteLine($"                {GetDtoRelationshipWithValueForTest(rel)}");
                        }
                        outputFile.WriteLine("            });");
                    }

                    outputFile.WriteLine("");

                    foreach (Relationship r in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(e => e.Name == r.RelatedEntity).Visibility == "internal" || r.Cardinality == "OneToOne")
                        {
                            continue;
                        }

                        outputFile.WriteLine($"            {GetRelationshipAssertTest(r)};");
                    }
                    outputFile.WriteLine("        }");
                }
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private string GetDtoConstructorValuesForTest(Entity entity)
        {
            IList<string> values = new List<string>();

            foreach (Property p in entity.Properties)
            {
                values.Add(p.TestValue());
            }

            foreach (Relationship r in entity.Relationships)
            {
                if (EntityMap.Entities.First(e => e.Name == r.RelatedEntity).Visibility == "internal" ||
                    r.Cardinality == "OneToOne")
                {
                    continue;
                }
                
                if (r.Cardinality == "OneToMany")
                {
                    values.Add($"new List<{r.RelatedEntity}>" + "{" + $"new {r.RelatedEntity}()" + "}");
                    continue;
                }

                values.Add($"new {r.RelatedEntity}()");
            }

            return string.Join(", ", values);
        }

        public string CreateHashCodes( Entity entity)
        {
            List<string> result = new List<string>();

            foreach (Property prop in entity.Properties)
            {
                if (prop.PrimaryKey)
                    result.Add(string.Format("entity.{0}.GetHashCode()", prop.Name));
            }
            return string.Join(" ^ ", result);
        }

        private string GetPropertyWithValueForTest(Property p, string s = null)
        {
            return s != null ? $"{s}.{p.Name} = {p.TestValue()};" : $"{p.Name} = {p.TestValue()},";
        }

        private string GetPropertyWithValueForTest2(Property p, string s = null)
        {
            return s != null ? $"{s}.{p.Name} = {p.TestValue2()};" : $"{p.Name} = {p.TestValue2()},";
        }

        private string GetRelationshipWithValueForTest(Relationship r)
        {
            if (r.Cardinality == "OneToMany")
            {
                return $"{r.PluralName} = new List<{r.RelatedEntity}Entity>" +"{" + $"new {r.RelatedEntity}Entity()" + "},";
            }

            return $"{r.Name} = new {r.RelatedEntity}Entity(),";
        }

        private string GetDtoRelationshipWithValueForTest(Relationship r)
        {
            if (r.Cardinality == "OneToMany")
            {
                return $"{r.PluralName} = new List<{r.RelatedEntity}>" + "{" + $"new {r.RelatedEntity}()" + "},";
            }

            return $"{r.Name} = new {r.RelatedEntity}(),";
        }

        private string GetPropertyAssertCheck(Property p)
        {
            return $"Assert.AreEqual({p.TestValue()}, entity.{p.Name})";
        }

        private string GetPropertyAssertCheck2(Property p)
        {
            return $"Assert.AreEqual({p.TestValue2()}, entity.{p.Name})";
        }

        private string GetRelationshipAssertTest(Relationship r)
        {
            if (r.Cardinality == "OneToMany")
            {
                return $"Assert.AreEqual(1, entity.{r.PluralName}.Count)";
            }

            return $"Assert.IsNotNull(entity.{r.Name})";
        }
    }
}
