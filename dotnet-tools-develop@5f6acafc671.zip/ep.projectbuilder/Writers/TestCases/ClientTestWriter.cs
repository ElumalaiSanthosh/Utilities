﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers.TestCases
{
    public class ClientTestWriter : WriterBase, IWriter
    {
        internal ClientTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}ClientTest.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Clients;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }


        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System.Configuration;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Entities;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Clients;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Tests.Clients");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestClass]");
                outputFile.WriteLine($"    public partial class {Entity.Name}ClientTests");
                outputFile.WriteLine("    {");
                outputFile.WriteLine("        public static IConfiguration Configuration { get; }");
                outputFile.WriteLine("");
                outputFile.WriteLine($"        static {Entity.Name}ClientTests()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("            Configuration = new ConfigurationBuilder()");
                outputFile.WriteLine("                .AddJsonFile(\"test.json\")");
                outputFile.WriteLine("                .Build();");
                outputFile.WriteLine("        }");
                
                if (firstPass)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        [TestMethod]");
                    outputFile.WriteLine($"        public void {EntityMap.Namespace}GetInstance()");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                    outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            Assert.IsNotNull(client);");
                    outputFile.WriteLine("        }");
                }

                if (Entity.HasCommand("get") )
                {
                    if (Entity.HasPrimaryKey())
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        [TestMethod]");
                        outputFile.WriteLine($"        public async Task Get{Entity.Name}TestMethod()");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            RequestResponse<{Entity.Name}> value = new RequestResponse<{Entity.Name}>" + "{StatusCode = HttpStatusCode.OK, Value = new " + Entity.Name + "()};");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<{Entity.Name}>>.Factory.StartNew(()=> " + "{ return value;});");
                        outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Get, HttpStatusCode.OK, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        outputFile.WriteLine($"            var result = client.Get{Entity.Name}Async({Entity.PrimaryKeyValuesForTest()});");
                        outputFile.WriteLine("            lookupTask.Wait();");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                        outputFile.WriteLine("");

                        int count = Entity.PrimaryKeyCount();
                        for (int i = 0; i < count; i++)
                        {
                            outputFile.WriteLine($"            await Assert.ThrowsExceptionAsync<ArgumentException>(async() => await client.Get{Entity.Name}Async({GetValuesForFailTest(count, i)}));");
                        }

                        outputFile.WriteLine("        }");
                    }

                    if (Entity.Relationships.Any())
                    {
                        IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");
                        foreach (var r in relationships)
                        {
                            Entity ent = EntityMap.Entities.First(e => e.Name == r.RelatedEntity);
                            outputFile.WriteLine("");
                            outputFile.WriteLine("");
                            outputFile.WriteLine("        [TestMethod]");
                            outputFile.WriteLine($"        public void GetMany{ent.Name}TestMethod()");
                            outputFile.WriteLine("        {");
                            outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                            outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                            outputFile.WriteLine("");
                            outputFile.WriteLine($"            {Entity.Name} entity = new {Entity.Name}");
                            outputFile.WriteLine("            {");

                            foreach (Property p in Entity.Properties)
                            {
                                outputFile.WriteLine($"                {GetPropertyWithValueForTest(p)}");
                            }

                            outputFile.WriteLine("            };");
                            outputFile.WriteLine("");
                            outputFile.WriteLine($"            RequestResponse<List<{Entity.Name}>> value = new RequestResponse<List<{Entity.Name}>>" + "{StatusCode = HttpStatusCode.OK, Value = new List<" + Entity.Name + $">(new List<{Entity.Name}>" + "{entity})};");
                            outputFile.WriteLine("");
                            outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<List<{Entity.Name}>>>.Factory.StartNew(()=> " + "{ return value;});");
                            outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<List<{Entity.Name}>>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Get, HttpStatusCode.OK, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                            outputFile.WriteLine($"            var result = client.GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipValueTest(Entity)});");
                            outputFile.WriteLine("            lookupTask.Wait();");
                            outputFile.WriteLine("");
                            outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                            outputFile.WriteLine("        }");
                        }
                    }

                    if (Entity.UniqueKeys.Any())
                    {
                        //foreach (var key in Entity.UniqueKeys)
                        //{
                        //    List<string> props = key.Properties.Split(',').ToList();
                        //    outputFile.WriteLine("");
                        //    outputFile.WriteLine("        [TestMethod]");
                        //    outputFile.WriteLine($"        public void Get{Entity.Name}By{props.UniqueName()}TestMethod()");
                        //    outputFile.WriteLine("        {");
                        //    outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        //    outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        //    outputFile.WriteLine("");
                        //    outputFile.WriteLine(
                        //        $"            {Entity.Name} entity = new {Entity.Name}");
                        //    outputFile.WriteLine("            {");

                        //    foreach (Property p in Entity.Properties)
                        //    {
                        //        outputFile.WriteLine($"                {GetPropertyWithValueForTest(p)}");
                        //    }

                        //    outputFile.WriteLine("            };");
                        //    outputFile.WriteLine("");
                        //    outputFile.WriteLine($"            RequestResponse<{Entity.Name}> value = new RequestResponse<{Entity.Name}>" + "{StatusCode = HttpStatusCode.OK, Value = new " + Entity.Name + "()};");
                        //    outputFile.WriteLine("");
                        //    outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<{Entity.Name}>>.Factory.StartNew(()=> " + "{ return value;});");
                        //    outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Get, HttpStatusCode.OK, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        //    outputFile.WriteLine($"            var result = client.Get{Entity.Name}By{props.UniqueName()}Async({props.GetUniqueKeyValuesForTest(Entity)});");
                        //    outputFile.WriteLine("            lookupTask.Wait();");
                        //    outputFile.WriteLine("");
                        //    outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                        //    outputFile.WriteLine("        }");
                        //}
                    }

                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        [TestMethod]");
                        outputFile.WriteLine($"        public void GetMany{Entity.Name}TestMethod()");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        outputFile.WriteLine(
                            $"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine(
                            $"            {Entity.Name} entity = new {Entity.Name}");
                        outputFile.WriteLine("            {");

                        foreach (Property p in Entity.Properties)
                        {
                            outputFile.WriteLine($"                {GetPropertyWithValueForTest(p)}");
                        }

                        outputFile.WriteLine("            };");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            RequestResponse<PageResults<{Entity.Name}>> value = new RequestResponse<PageResults<{Entity.Name}>>" + "{StatusCode = HttpStatusCode.OK, Value = new PageResults<" + Entity.Name + $">(new List<{Entity.Name}>" +
                            "{entity}, new Uri(\"http://test_first\"), new Uri(\"http://test_last\"), new Uri(\"http://test_previous\"), new Uri(\"http://test_next\"), 500)};");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<PageResults<{Entity.Name}>>>.Factory.StartNew(()=> " + "{ return value;});");
                        outputFile.WriteLine($"            serviceClient.Setup(d => d.GetOdataPagedRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", It.IsAny<List<string>>(), It.IsAny<QueryOptions>(), It.IsAny<List<string>>(),It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        outputFile.WriteLine($"            var result = client.GetMany{Entity.PluralName}Async(null);");
                        outputFile.WriteLine("            lookupTask.Wait();");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                        outputFile.WriteLine("        }");
                    }
                }

                if (Entity.Visibility == "public")
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        #region Commands");

                    if (Entity.HasCommand("create"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        [TestMethod]");
                        outputFile.WriteLine($"        public void Post{Entity.Name}TestMethod()");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            RequestResponse<{Entity.Name}> value = new RequestResponse<{Entity.Name}>" + "{StatusCode = HttpStatusCode.Created, Value = new " + Entity.Name + "()};");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<{Entity.Name}>>.Factory.StartNew(()=> " +"{ return value;});");
                        outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Post, HttpStatusCode.Created, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        outputFile.WriteLine($"            var result = client.Post{Entity.Name}Async(null);");
                        outputFile.WriteLine("            lookupTask.Wait();");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.Created, result.Result.StatusCode);");
                        outputFile.WriteLine("        }");
                    }

                    if (Entity.HasCommand("update"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        [TestMethod]");
                        outputFile.WriteLine($"        public void Put{Entity.Name}TestMethod()");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            RequestResponse<{Entity.Name}> value = new RequestResponse<{Entity.Name}>" + "{StatusCode = HttpStatusCode.OK, Value = " + $"new {Entity.Name}()"+"};");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"            var lookupTask = Task<RequestResponse<{Entity.Name}>>.Factory.StartNew(()=> " + "{ return value;});");
                        outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Put, HttpStatusCode.OK, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        outputFile.WriteLine($"            var result = client.Put{Entity.Name}Async(new {Entity.Name}(), {Entity.PrimaryKeyValuesForTest()});");
                        outputFile.WriteLine("            lookupTask.Wait();");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                        outputFile.WriteLine("        }");
                    }

                    if (Entity.HasCommand("delete"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        [TestMethod]");
                        outputFile.WriteLine($"        public async Task Delete{Entity.Name}TestMethod()");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            var serviceClient = new Mock<IServiceClientBase<{EntityMap.Namespace}Client>>();");
                        outputFile.WriteLine($"            {EntityMap.Namespace}Client client = new {EntityMap.Namespace}Client(serviceClient.Object);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            RequestResponse<bool> value = new RequestResponse<bool>" + "{StatusCode = HttpStatusCode.OK, Value = true};");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            var lookupTask = Task<RequestResponse<bool>>.Factory.StartNew(()=> " + "{ return value;});");
                        outputFile.WriteLine($"            serviceClient.Setup(d => d.GetRequestResponseAsync<bool>(\"{Entity.PluralName.ToLower()}\", ApiRestVerbs.Delete, HttpStatusCode.OK, It.IsAny<List<object>>(), It.IsAny<List<string>>(), It.IsAny<Dictionary<string, string>>(), It.IsAny<Dictionary<string, string>>(), 0)).Returns(lookupTask);");
                        outputFile.WriteLine($"            var result = client.Delete{Entity.Name}Async({Entity.PrimaryKeyValuesForTest()});");
                        outputFile.WriteLine("            lookupTask.Wait();");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            Assert.AreEqual(HttpStatusCode.OK, result.Result.StatusCode);");
                        outputFile.WriteLine("");

                        int count = Entity.PrimaryKeyCount();
                        for (int i = 0; i < count; i++)
                        {
                            outputFile.WriteLine($"            await Assert.ThrowsExceptionAsync<ArgumentException>(async() => await client.Delete{Entity.Name}Async({GetValuesForFailTest(count, i)}));");
                        }
                        outputFile.WriteLine("        }");
                    }

                    outputFile.WriteLine("        #endregion Commands");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private string GetPropertyWithValueForTest(Property p, string s = null)
        {
            return s != null ? $"{s}.{p.Name} = {p.TestValue()};" : $"{p.Name} = {p.TestValue()},";
        }

        private string GetValuesForFailTest(int count, int place)
        {
            List<string> values = new List<string>();
            Property[] keys = Entity.PrimaryKeyList().ToArray();
            for (int i = 0; i < count; i++)
            {
                if (i == place)
                {
                    values.Add(keys[i].EntityType() == "string" ? "null" : "0");
                    continue;
                }
                values.Add(keys[i].TestValue());
            }

            return string.Join(", ", values);
        }
    }
}
