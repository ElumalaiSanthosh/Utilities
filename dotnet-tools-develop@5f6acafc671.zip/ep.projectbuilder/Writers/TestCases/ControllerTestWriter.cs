﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers.TestCases
{
    public class ControllerTestWriter : WriterBase, IWriter
    {
        internal ControllerTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return ($"{Entity.Name}ControllerTest.generated.cs");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                    Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using NUnit.Framework;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Controllers;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Controller.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestFixture()]");
                outputFile.WriteLine($"    public partial class {Entity.PluralName}ControllerTests");
                outputFile.WriteLine("    {");

                outputFile.WriteLine("        [Test()]");
                outputFile.WriteLine($"        public void {Entity.PluralName}ControllerConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            {Entity.PluralName}Controller controller = new {Entity.PluralName}Controller();");
                outputFile.WriteLine("            Assert.IsNotNull(controller);");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
