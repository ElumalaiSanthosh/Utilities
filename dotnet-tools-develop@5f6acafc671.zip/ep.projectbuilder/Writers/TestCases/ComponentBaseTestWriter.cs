﻿using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers.TestCases
{
    public class ServiceBaseTestWriter : WriterBase, IWriter
    {
        internal ServiceBaseTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return "ServiceTestBase.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Services;
    
        public override bool VerifyVisibility()
        {
            if (EntityMap.Entities.Any(e => e.Visibility != "dto"))
            {
                return true;
            }

            return false;
        }

        public void Create(ref bool firstPass)
        {
            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using ApiService.DataStore;");
                outputFile.WriteLine("using ApiService.Repositories;");
                outputFile.WriteLine("using ApiService.Commons.Exceptions;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Service.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("    public class ServiceTestBase");
                outputFile.WriteLine("    {");

                foreach (Entity entity in EntityMap.Entities)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        internal {entity.Name} Get{entity.Name}()");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            return new {entity.Name}");
                    outputFile.WriteLine("                       {");

                    foreach (Property p in entity.Properties)
                    {
                        outputFile.WriteLine($"                           {p.GetPropertyWithValueForTest()},");
                    }

                    if (entity.HasChildren())
                    {
                        foreach (Relationship rel in entity.Relationships)
                        {
                            if (rel.Cardinality == "OneToOne" ||
                                EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal")
                            {
                                continue;
                            }

                            outputFile.WriteLine(
                                $"                           {rel.PluralName} = new List<{rel.RelatedEntity}>" + "{Get" +
                                rel.Name + "()},");
                        }
                    }

                    outputFile.WriteLine("                       };");
                    outputFile.WriteLine("        }");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
