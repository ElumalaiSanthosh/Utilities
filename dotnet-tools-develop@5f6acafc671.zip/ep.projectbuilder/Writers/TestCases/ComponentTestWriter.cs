﻿using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers.TestCases
{
    public class ServiceTestWriter : WriterBase, IWriter
    {
        internal ServiceTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return ($"{Entity.Name}ServiceTest.generated.cs");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Services;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "dto")
            {
                return false;
            }
            return true;
        }

        public void Create(ref bool firstPass)
        {
            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using ApiService.DataStore;");
                outputFile.WriteLine("using ApiService.Repositories;");
                outputFile.WriteLine("using ApiService.Commons.Exceptions;");
                outputFile.WriteLine($"using EP.{EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using EP.{EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("using NUnit.Framework;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Service.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("    [TestFixture()]");
                outputFile.WriteLine($"    public partial class {Entity.Name}ServiceTests : ComponentTestBase");
                outputFile.WriteLine("    {");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        private Mock<IDataStoreProvider> Provider {set; get;}");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        private Mock<IRepository<{Entity.Name}>> Repository " + "{ set; get; }");

                    foreach (Relationship r in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                        {
                            continue;
                        }

                        outputFile.WriteLine("");
                        outputFile.WriteLine($"        private Mock<I{r.RelatedEntity}Service> {r.RelatedEntity}Component " + "{ set; get; }");
                    }
                }
                
                outputFile.WriteLine("");
                outputFile.WriteLine("        [Test()]");
                outputFile.WriteLine($"        public void {Entity.Name}ServiceConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("        }");

                if (Entity.HasPrimaryKey() && !Entity.ExcludeTest("get") && Entity.HasDataset)
                {
                    CreateGet(outputFile);
                }

                if (Entity.HasDataset)
                {
                    CreateGetMany(outputFile);
                }

                if (Entity.Visibility != "view" && Entity.Visibility != "custom")
                {
                    if (!Entity.ExcludeTest("post"))
                    {
                        CreatePost(outputFile);
                    }

                    if (!Entity.ExcludeTest("put"))
                    {
                        CreatePut(outputFile);
                    }
                    if (!Entity.ExcludeTest("delete"))
                    {
                        CreateDelete(outputFile);
                    }
                }

                outputFile.WriteLine("");
                outputFile.WriteLine($"        public {Entity.Name}Service GetComponent()");
                outputFile.WriteLine("        {");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("            Provider = new Mock<IDataStoreProvider>();");
                    outputFile.WriteLine($"            Repository= new Mock<IRepository<{Entity.Name}>>();");

                    foreach (Relationship r in Entity.Relationships)
                    {
                        outputFile.WriteLine($"            {r.Name}Service = new Mock<I{r.Name}Component>();");
                    }

                    outputFile.WriteLine($"            return new {Entity.Name}Service(Provider.Object, DataStoreFactory.GetQueryBuilder<{Entity.Name}>(), Repository.Object{(Entity.HasChildren() ? "," : "")} {Entity.RelationshipsForBuild()});");
                }
                else
                {
                    outputFile.WriteLine($"            return new {Entity.Name}Service();");
                }
                
                outputFile.WriteLine("        }");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private void CreateGet(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServiceGetTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service component = GetComponent();");

            foreach (Relationship r in Entity.Relationships)
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                if (r.Cardinality == "OneToMany")
                {
                    outputFile.WriteLine($"            {r.RelatedEntity}Service.Setup(d => d.ReadMany(It.IsAny<QueryOptions>(), null))");
                    outputFile.WriteLine($"                .Returns(new QueryResults<{r.RelatedEntity}>");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    Items = new List<{r.RelatedEntity}> "+ "{" + $"Get{r.RelatedEntity}()" + "}");
                    outputFile.WriteLine("                });");
                    continue;
                }
                outputFile.WriteLine($"            {r.RelatedEntity}Service.Setup(d => d.Read(It.IsAny<QueryOptions>(), null, false)).Returns(Get{r.RelatedEntity}());");
            }

            outputFile.WriteLine($"            Repository.Setup(d => d.Read(It.IsAny<QueryOptions>(), null, false)).Returns(Get{Entity.Name}());");
            outputFile.WriteLine("");
            outputFile.WriteLine($"            Assert.IsNotNull(service.Get({Entity.PrimaryKeyValuesForTest()}));");
            outputFile.WriteLine("        }");
            
        }

        private void CreateGetMany(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServiceGetManyTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service component = GetComponent();");
            
            outputFile.WriteLine($"            Repository.Setup(d => d.ReadMany(It.IsAny<QueryOptions>(), null)).Returns(new QueryResults<{Entity.Name}>");

            outputFile.WriteLine("                {");
            outputFile.WriteLine($"                    Items = new List<{Entity.Name}>" + "{" + $"Get{Entity.Name}()" + "}");
            outputFile.WriteLine("                });");

            outputFile.WriteLine("");
            outputFile.WriteLine("            QueryOptions options = new QueryOptions");
            outputFile.WriteLine("            {");
            outputFile.WriteLine($"               Filter = \"{Entity.PrimaryKeyValuesForFilterTest()}\"");
            outputFile.WriteLine("            };");
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNotNull(service.GetMany(options));");
            outputFile.WriteLine("        }");

        }

        private void CreatePost(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServicePostTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service service = GetComponent();");

            foreach (Relationship r in Entity.Relationships.Where(e => e.Cardinality == "OneToMany"))
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "view" ||
                    EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                outputFile.WriteLine($"            {r.RelatedEntity}Service.Setup(d => d.Post(It.IsAny<{r.RelatedEntity}>(), null, false)).Returns(Get{r.RelatedEntity}());");
            }

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Create(It.IsAny<{Entity.Name}>(), null)).Returns(Get{Entity.Name}());");
            }
            outputFile.WriteLine("");
            outputFile.WriteLine($"            Assert.IsNotNull(service.Post(Get{Entity.Name}()));");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Create(It.IsAny<{Entity.Name}>(), null)).Throws(new Exception());");
                outputFile.WriteLine($"            Assert.Throws<Exception>(() => service.Post(Get{Entity.Name}()));");
            }
            
            outputFile.WriteLine("        }");

            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServicePostManyTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service service = GetService);");

            foreach (Relationship r in Entity.Relationships.Where(e => e.Cardinality == "OneToMany"))
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "view" ||
                    EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                outputFile.WriteLine($"            {r.RelatedEntity}Service.Setup(d => d.Post(It.IsAny<{r.RelatedEntity}>(), null, true)).Returns(Get{r.RelatedEntity}());");
            }

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Create(It.IsAny<{Entity.Name}>(), null)).Returns(Get{Entity.Name}());");
            }
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNull(service.Post(dto: null));");
            outputFile.WriteLine($"            Assert.IsNull(service.Post(new List<{Entity.Name}>()));");
            outputFile.WriteLine($"            Assert.IsNotNull(service.Post(new List<{Entity.Name}>"+"{"+$"Get{Entity.Name}()"+"}"+"));");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Create(It.IsAny<{Entity.Name}>(), null)).Throws(new Exception());");
                outputFile.WriteLine($"            Assert.Throws<Exception>(() => service.Post(new List<{Entity.Name}>" + "{" + $"Get{Entity.Name}()" + "}" + "));");
            }
            
            outputFile.WriteLine("        }");
        }

        private void CreatePut(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServicePutTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service service = GetService();");

            foreach (Relationship r in Entity.Relationships.Where(e => e.Cardinality == "OneToMany"))
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "view" ||
                    EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                outputFile.WriteLine($"            {r.RelatedEntity}Service.Setup(d => d.Put(It.IsAny<{r.RelatedEntity}>(), null, false)).Returns(Get{r.RelatedEntity}());");
            }

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Update(It.IsAny<{Entity.Name}>(), null)).Returns(Get{Entity.Name}());");
            }
            outputFile.WriteLine("");
            outputFile.WriteLine($"            Assert.IsNotNull(service.Put(Get{Entity.Name}()));");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Update(It.IsAny<{Entity.Name}>(), null)).Throws(new Exception());");
                outputFile.WriteLine($"            Assert.Throws<Exception>(() => service.Put(Get{Entity.Name}()));");
            }

            outputFile.WriteLine("        }");

            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ServicePutManyTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Service service = GetService();");

            foreach (Relationship r in Entity.Relationships.Where(e => e.Cardinality == "OneToMany"))
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "view" ||
                    EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                outputFile.WriteLine($"            {r.RelatedEntity}Component.Setup(d => d.Put(It.IsAny<{r.RelatedEntity}>(), null, true)).Returns(Get{r.RelatedEntity}());");
            }

            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Update(It.IsAny<{Entity.Name}>(), null)).Returns(Get{Entity.Name}());");
            }
            outputFile.WriteLine("");
            outputFile.WriteLine("            Assert.IsNull(component.Put(dto: null));");
            outputFile.WriteLine($"            Assert.IsNull(component.Put(new List<{Entity.Name}>()));");
            outputFile.WriteLine($"            Assert.IsNotNull(component.Put(new List<{Entity.Name}>" + "{" + $"Get{Entity.Name}()" + "}" + "));");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine($"            Repository.Setup(d => d.Update(It.IsAny<{Entity.Name}>(), null)).Throws(new Exception());");
                outputFile.WriteLine($"            Assert.Throws<Exception>(() => component.Put(new List<{Entity.Name}>" + "{" + $"Get{Entity.Name}()" + "}" + "));");
            }

            outputFile.WriteLine("        }");
        }

        private void CreateDelete(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("        [Test()]");
            outputFile.WriteLine($"        public void {Entity.PluralName}ComponentDeleteTest()");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            {Entity.Name}Component component = GetComponent();");

            foreach (Relationship r in Entity.Relationships.Where(e => e.Cardinality == "OneToMany"))
            {
                if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "view" ||
                    EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "dto")
                {
                    continue;
                }

                outputFile.WriteLine($"            {r.RelatedEntity}Component.Setup(d => d.Delete(It.IsAny<QueryOptions>(), null)).Returns(true);");
            }

            outputFile.WriteLine("");
            outputFile.WriteLine("            QueryOptions options = new QueryOptions");
            outputFile.WriteLine("            {");
            outputFile.WriteLine($"               Filter = \"{Entity.PrimaryKeyValuesForFilterTest()}\"");
            outputFile.WriteLine("            };");
            outputFile.WriteLine("");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("            Repository.Setup(d => d.Delete(It.IsAny<QueryOptions>(), null)).Returns(true);");
            }

            outputFile.WriteLine("            Assert.IsFalse(component.Delete(new QueryOptions()));");
            outputFile.WriteLine("            Assert.IsTrue(component.Delete(options));");
            outputFile.WriteLine("");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("            Repository.Setup(d => d.Delete(It.IsAny<QueryOptions>(), null)).Returns(false);");
                outputFile.WriteLine("            Assert.IsFalse(component.Delete(options));");
            }
            
            outputFile.WriteLine("");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("            Repository.Setup(d => d.Delete(It.IsAny<QueryOptions>(), null)).Throws(new Exception());");
                outputFile.WriteLine("            Assert.Throws<Exception>(() => component.Delete(options));");
            }

            outputFile.WriteLine("        }");
        }
    }
}
