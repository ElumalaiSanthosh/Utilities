﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers.TestCases
{
    public class HealthControllerTestWriter : WriterBase, IWriter
    {
        internal HealthControllerTestWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return "HealthChecksControllerTest.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;
        

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Controllers;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using ApiService.HealthChecks;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine("using ApiService.Web;");
                outputFile.WriteLine("using Moq;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Controller.Tests");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    [TestClass]");
                outputFile.WriteLine("    public partial class HealthChecksControllerTests");
                outputFile.WriteLine("    {");

                outputFile.WriteLine("        [TestMethod]");
                outputFile.WriteLine("        public void HealthChecksControllerConstructorTest()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            var config = new Mock<IConfiguration>();");
                outputFile.WriteLine($"            var cache = new Mock<IApiCache>();");
                outputFile.WriteLine("            HealthChecksController controller = new HealthChecksController(config.Object, cache.Object);");
                outputFile.WriteLine("");
                outputFile.WriteLine("            var result = controller.GetHealthAsync();");
                outputFile.WriteLine("            var okResult = result.Result as OkObjectResult;");
                outputFile.WriteLine("");
                outputFile.WriteLine("            Assert.IsNotNull(okResult);");
                outputFile.WriteLine("            Assert.AreEqual(200, okResult.StatusCode);");
                outputFile.WriteLine("");
                outputFile.WriteLine("            HealthChecks.RegisterHealthCheck(\"FileSystemHealthCheck\", CommonHealthChecks.FileSystemHealthCheck(100000000, new List<string>{\"ZT\"}));");
                outputFile.WriteLine("            var rest = controller.GetHealthAsync(\"FailMe\");");
                outputFile.WriteLine("            rest.Wait();");
                outputFile.WriteLine("            var value = rest.Result as RestExceptionObjectResult;");
                outputFile.WriteLine("            Assert.AreEqual(503, value.StatusCode);");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
