﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    public class HealthControllerWriter : WriterBase, IWriter
    {
        internal HealthControllerWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetSubPath()
        {
            return "HealthCheck";
        }

        public override string GetFileName()
        {
            return "HealthChecksController.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using ApiService.Commons.Logger;");
                outputFile.WriteLine("using Microsoft.Extensions.Logging;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using ApiService.Controllers;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Controllers");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");
                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// Provides API methods for testing the Health of the service");
                outputFile.WriteLine("    /// </summary>");
                outputFile.WriteLine("    [Route(\"healthchecks\")]");
                outputFile.WriteLine("    public partial class HealthChecksController : DefaultApiController<HealthChecksController>");
                outputFile.WriteLine("    {");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        ///");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine($"        public HealthChecksController(IConfiguration config, IApiCache cache) : base(config, \"{EntityMap.Namespace}\", {EntityMap.Version}, cache)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");

                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        /// Returns true if the Service is Healthy, or false otherwise");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine("        /// <param name=\"accessToken\">Optional access token used for validating the request</param>");
                outputFile.WriteLine("        /// <response code=\"200\">Service is Healthy</response>");
                outputFile.WriteLine("        /// <response code=\"500\">Service is UnHealthy and raised an Exception</response>");
                outputFile.WriteLine("        /// <response code=\"503\">Service is Unhealthy and details are in the response</response>");
                outputFile.WriteLine("        [HttpGet(Name = \"health\")]");
                outputFile.WriteLine("        [Produces(\"application/json\")]");
                outputFile.WriteLine("        public async Task<IActionResult> GetHealthAsync(string accessToken = null)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("            var result = await ApiService.HealthChecks.HealthChecks.GetStatusAsync(null, accessToken);");
                outputFile.WriteLine("");
                outputFile.WriteLine("            if (result.Item1)");
                outputFile.WriteLine("                return Ok(\"true\");");
                outputFile.WriteLine("");
                outputFile.WriteLine("            return RestException(HttpStatusCode.ServiceUnavailable, result.Item2);");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
