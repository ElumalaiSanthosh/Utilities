﻿using System.IO;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;
using System.Linq;
using System;
using System.Collections.Generic;

namespace ProjectBuilder.Writers
{
    public class ControllerCommandWriter : WriterBase, IWriter
    {
        internal ControllerCommandWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}CommandController.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility != "public")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using ApiService.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Logger;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Controllers;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Query;");
                outputFile.WriteLine("using Microsoft.ApplicationInsights.AspNetCore.Extensions;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");                
                outputFile.WriteLine("using System.ComponentModel.DataAnnotations;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Controllers");
                outputFile.WriteLine("{");
                outputFile.WriteLine($"    public partial class {Entity.PluralName}Controller");
                outputFile.WriteLine("    {");

                if (Entity.HasCommand("create"))
                {
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine(
                        $"        /// Creates a {Entity.Name} record using the provided {Entity.Name.CamelCase()} object.");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"dto\"></param>");
                    outputFile.WriteLine("        /// <returns></returns>");
                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine(
                            "        /// <response code=\"201\">Created - The request has been fulfilled and resulted in a new resource being created</response>");
                    }
                    else
                    {
                        outputFile.WriteLine(
                            "        /// <response code=\"200\">OK - The request has been fulfilled and the process was successful</response>");
                    }
                    outputFile.WriteLine(
                        "        /// <response code=\"202\">Accepted - The request has been accepted for processing, but the processing has not been completed</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"205\">Reset Content - The server has fulfilled the request and the user agent SHOULD reset the document view which caused the request to be sent</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"400\">Bad Request - The request could not be understood by the server due to malformed syntax</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"401\">Unauthorized - The request requires user authentication</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"409\">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                    outputFile.WriteLine("        [HttpPost]");
                    outputFile.WriteLine($"        [ProducesResponseType(201, Type = typeof({Entity.Name}))]");
                    //outputFile.WriteLine("        [Route(\"\")]");
                    outputFile.WriteLine(
                        $"        public async Task<IActionResult> PostAsync([FromBody, Required]{Entity.Name} dto)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            try");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine($"                var result = await {Entity.Name}Service.PostAsync(dto);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                var location = $\"{BaseRequestUrl(Request)}/{" + Entity.PrimaryKeysForLocation() + "}\";");
                    outputFile.WriteLine("                return Created(location, result);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("            catch (Exception e)");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine("                return HandleException(e);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("        }");
                }

                if (Entity.HasCommand("update"))
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine($"        /// Updates a {Entity.PluralName} record using the provided {Entity.Name.CamelCase()} object.");
                    outputFile.WriteLine("        /// </summary>");
                    foreach (var p in Entity.PrimaryKeyList())
                    {
                        outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                    }
                    outputFile.WriteLine($"        /// <param name=\"{Entity.Name.CamelCase()}\"></param>");
                    outputFile.WriteLine("        /// <returns></returns>");
                    outputFile.WriteLine("        /// <response code=\"200\">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>");
                    outputFile.WriteLine("        /// <response code=\"204\">No Content - The server has fulfilled the request but does not need to return an entity-body</response>");
                    outputFile.WriteLine("        /// <response code=\"400\">Bad Request - The request could not be understood by the server due to malformed syntax</response>");
                    outputFile.WriteLine("        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                    outputFile.WriteLine("        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                    outputFile.WriteLine("        /// <response code=\"409\">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>");
                    outputFile.WriteLine("        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                    outputFile.WriteLine($"        [HttpPut(\"{Entity.PrimaryKeysForRoute()}\")]");
                    //outputFile.WriteLine($"        [ResponseType(typeof({Entity.Name}))]");
                    outputFile.WriteLine($"        [ProducesResponseType(200, Type = typeof({Entity.Name}))]");
                    outputFile.WriteLine($"        public async Task<IActionResult> PutAsync({Entity.PrimaryKeysWithTypes()}, [FromBody, Required]{Entity.Name} {Entity.Name.CamelCase()})");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            try");
                    outputFile.WriteLine("            {");

                    outputFile.WriteLine($"                {Entity.Name.CamelCase()} = await {Entity.Name}Service.PutAsync({Entity.PrimaryKeysWithTypes(false)}, {Entity.Name.CamelCase()});");

                    if (Entity.HasCommand("get"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"                RemoveCacheKeys(ref { Entity.Name.CamelCase()});");
                    }

                    outputFile.WriteLine("");
                    outputFile.WriteLine($"                return Ok({Entity.Name.CamelCase()});");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("            catch (Exception e)");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine("                return HandleException(e);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("        }");
                }

                if (Entity.HasCommand("delete"))
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine($"        /// Delete a single {Entity.Name} record using the primary key.");
                    outputFile.WriteLine("        /// </summary>");
                    foreach (var p in Entity.PrimaryKeyList())
                    {
                        outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                    }
                    outputFile.WriteLine("        /// <returns></returns>");
                    outputFile.WriteLine(
                        "        /// <response code=\"200\">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"204\">No Content - The server has fulfilled the request but does not need to return an entity-body</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"409\">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>");
                    outputFile.WriteLine(
                        "        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                    outputFile.WriteLine($"        [HttpDelete(\"{Entity.PrimaryKeysForRoute()}\")]");
                    //outputFile.WriteLine($"        [Route(\"{Entity.PrimaryKeysForRoute()}\")]");
                    outputFile.WriteLine(
                        $"        public async Task<IActionResult> DeleteAsync({Entity.PrimaryKeysWithTypes()})");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            try");
                    outputFile.WriteLine("            {");

                    if (Entity.HasCommand("get"))
                    {
                        outputFile.WriteLine($"                var {Entity.Name.CamelCase()} = await {Entity.Name}Service.GetAsync({Entity.PrimaryKeys(false)});");
                        outputFile.WriteLine("");
                    }

                    outputFile.WriteLine($"                var result = await {Entity.Name}Service.DeleteAsync(new QueryOptions()");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    Filter = {Entity.PrimaryKeysWhere()}");
                    outputFile.WriteLine("                });");

                    if (Entity.HasCommand("get"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"                RemoveCacheKeys(ref { Entity.Name.CamelCase()});");
                    }

                    outputFile.WriteLine("");
                    outputFile.WriteLine($"                if (result == true)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    return Ok(result);");
                    outputFile.WriteLine("                }");

                    outputFile.WriteLine("                return NoContent();");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("            catch (Exception e)");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine("                return HandleException(e);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("        }");
                }

                if (Entity.HasCommand("get") && (Entity.HasCommand("update") || Entity.HasCommand("delete")))
                {
                    WriteDeleteCache(outputFile);
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        partial void RemoveAdditionalCacheKeys(ref {Entity.Name} {Entity.Name.CamelCase()});");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private void WriteDeleteCache(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine($"        private void RemoveCacheKeys(ref {Entity.Name} {Entity.Name.CamelCase()})");
            outputFile.WriteLine("        {");
            outputFile.WriteLine($"            if ({Entity.Name.CamelCase()} == null)");
            outputFile.WriteLine("            {");
            outputFile.WriteLine("                return;");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("");
            if (Entity.EnableCache)
            {
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("            Cache.RemoveByKeyPattern($\"" + "{Startup.BaseCacheKey}" + $"*{Entity.PrimaryKeysForDeleteCache()}*\");");
                }

                if (Entity.UniqueKeys.Any())
                {
                    foreach (var key in Entity.UniqueKeys)
                    {
                        List<string> props = key.Properties.Split(",").ToList();
                        if (Entity.HasDataset)
                        {
                            outputFile.WriteLine($"            Cache.RemoveByKeyPattern($\"" + "{Startup.BaseCacheKey}" + $"*{props.UniqueKeyDeleteCache(Entity)}*\");");
                        }
                    }
                }
            }

            outputFile.WriteLine($"            RemoveAdditionalCacheKeys(ref {Entity.Name.CamelCase()});");
            outputFile.WriteLine("        }");
        }
    }
}
