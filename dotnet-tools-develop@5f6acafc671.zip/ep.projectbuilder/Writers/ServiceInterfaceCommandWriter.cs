﻿using System;
using System.IO;
using ProjectBuilder.Extensions;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    public class ServiceInterfaceCommandWriter : WriterBase, IWriter
    {
        internal ServiceInterfaceCommandWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"I{Entity.Name}CommandServices.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Services;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility.ToLower() == "view" || 
                Entity.Visibility.ToLower() == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Data;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using ApiService.DataStore;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using System.Reflection;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using ApiService.Commons.Helpers;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Exceptions;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Services");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");
                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// ");
                outputFile.WriteLine("    /// </summary>");

                outputFile.Write($"    public partial interface I{Entity.Name}Service");
                if (Entity.HasDataset)
                {
                    outputFile.Write($" : IService<{Entity.Name}>");
                }
                outputFile.Write($"{Environment.NewLine}");

                outputFile.WriteLine("    {");

                if (Entity.Visibility != "view" &&
                    Entity.Visibility != "custom")
                {
                    outputFile.WriteLine("        #region CommandService");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// Post Method");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"dto\"></param>");
                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                        outputFile.WriteLine("        /// <param name=\"createRelatedRecords\"></param>");
                    }
                    outputFile.WriteLine("");
                    outputFile.Write($"        Task<{Entity.Name}> PostAsync({Entity.Name} dto");

                    if (Entity.HasDataset)
                    {
                        outputFile.Write(", IDbTransaction transaction = null, bool createRelatedRecords = true");
                    }
                    outputFile.Write($");{Environment.NewLine}");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// Post Method");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"dtos\"></param>");
                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                        outputFile.WriteLine("        /// <param name=\"createRelatedRecords\"></param>");
                    }
                    outputFile.WriteLine("");
                    outputFile.Write(
                        $"        Task<IEnumerable<{Entity.Name}>> PostAsync(IEnumerable<{Entity.Name}> dtos");

                    if (Entity.HasDataset)
                    {
                        outputFile.Write(", IDbTransaction transaction = null, bool createRelatedRecords = true");
                    }
                    outputFile.Write($");{Environment.NewLine}");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// Put Method");
                    outputFile.WriteLine("        /// </summary>");
                    foreach (var p in Entity.PrimaryKeyList())
                    {
                        outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                    }

                    outputFile.WriteLine("        /// <param name=\"dto\"></param>");
                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                        outputFile.WriteLine("        /// <param name=\"updateRelatedRecords\"></param>");
                    }
                    outputFile.Write($"        Task<{Entity.Name}> PutAsync({Entity.PrimaryKeysWithTypes()}, {Entity.Name} dto");

                    if (Entity.HasDataset)
                    {
                        outputFile.Write(", IDbTransaction transaction = null, bool updateRelatedRecords = true");
                    }
                    outputFile.Write($");{Environment.NewLine}");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// Put Method");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"dtos\"></param>");
                    if (Entity.HasDataset)
                    {
                        outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                        outputFile.WriteLine("        /// <param name=\"updateRelatedRecords\"></param>");
                    }
                    outputFile.Write($"        Task<IEnumerable<{Entity.Name}>> PutAsync(IEnumerable<{Entity.Name}> dtos");

                    if (Entity.HasDataset)
                    {
                        outputFile.Write(", IDbTransaction transaction = null, bool updateRelatedRecords = true");
                    }
                    outputFile.Write($");{Environment.NewLine}");

                    //outputFile.WriteLine("");
                    //outputFile.WriteLine("        /// <summary>");
                    //outputFile.WriteLine("        /// Delete Method");
                    //outputFile.WriteLine("        /// </summary>");
                    //outputFile.WriteLine("        /// <param name=\"options\"></param>");
                    //if (Entity.HasDataset)
                    //{
                    //    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                    //}
                    //outputFile.WriteLine("");
                    //outputFile.Write("        Task<bool> DeleteAsync(QueryOptions options");

                    //if (Entity.HasDataset)
                    //{
                    //    outputFile.Write(",IDbTransaction transaction = null");
                    //}
                    //outputFile.Write($");{Environment.NewLine}");

                    outputFile.WriteLine("        #endregion CommandService");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");

                firstPass = false;
            }
        }
    }
}
