﻿using System.IO;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ClientInterfaceCommandWriter : WriterBase, IWriter
    {
        internal ClientInterfaceCommandWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"I{Entity.Name}CommandClient.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Clients;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "view" || 
                Entity.Visibility == "internal" ||
                Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Clients");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine($"    public partial interface I{EntityMap.Namespace}Client");
                outputFile.WriteLine("    {");
                
                if (Entity.Visibility == "public" && Entity.HasCommandElement())
                {
                    outputFile.WriteLine("        #region Commands");
                    if (Entity.HasCommand("create"))
                    {
                        outputFile.WriteLine(
                            $"        Task<RequestResponse<{Entity.Name}>> Post{Entity.Name}Async({Entity.Name} entity, int timeout = 0);");
                    }

                    if (Entity.HasCommand("update"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine(
                            $"        Task<RequestResponse<{Entity.Name}>> Put{Entity.Name}Async({Entity.Name} entity, {Entity.PrimaryKeysWithTypes()}, int timeout = 0);");
                    }
                    if (Entity.HasCommand("delete"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine(
                            $"        Task<RequestResponse<bool>> Delete{Entity.Name}Async({Entity.PrimaryKeysWithTypes()}, int timeout = 0);");
                    }
                    outputFile.WriteLine("        #endregion Commands");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");

                firstPass = false;
            }
        }
    }
}
