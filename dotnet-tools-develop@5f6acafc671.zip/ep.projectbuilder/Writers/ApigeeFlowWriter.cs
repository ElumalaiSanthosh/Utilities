﻿using System.IO;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ApigeeFlowWriter : WriterBase
    {
        internal ApigeeFlowWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return "default.xml";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Flow;

        public override string GetProjectPath()
        {
            return @"apiproxy\proxies";
        }

        public override bool VerifyVisibility()
        {
            return true;
        }

        public void Create(ref bool firstPass)
        {
            bool exists = Directory.Exists(Path.Combine(EntityDir, "apiproxy", "proxies"));

            if (!exists) Directory.CreateDirectory(Path.Combine(EntityDir, "apiproxy", "proxies"));
            
            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteStart(outputFile);

                foreach (Entity entity in EntityMap.Entities)
                {
                    if (entity.Visibility == "internal" ||
                            entity.Visibility == "dto")
                    {
                        continue;
                    }

                    if (entity.HasCommand("get") && entity.HasPrimaryKey())
                    {
                        outputFile.WriteLine(
                            $"       <Flow name=\"get-{entity.PluralName.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}\">");
                        outputFile.WriteLine(
                            $"           <Description>get-{entity.PluralName.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}</Description>");
                        outputFile.WriteLine("           <Request/>");
                        outputFile.WriteLine("           <Response/>");
                        outputFile.WriteLine(
                            $"           <Condition>(proxy.pathsuffix MatchesPath \"/{entity.PluralName.ToLower()}/{entity.PrimaryKeysForRoute()}\") and (request.verb = \"GET\")</Condition>");
                        outputFile.WriteLine("       </Flow>");
                    }


                    if (entity.HasCommand("getmany"))
                    {
                        outputFile.WriteLine($"       <Flow name=\"get-{entity.Name.FriendlyCase().ToLower()}\">");
                        outputFile.WriteLine($"           <Description>get-{entity.Name.FriendlyCase().ToLower()}</Description>");
                        outputFile.WriteLine("           <Request/>");
                        outputFile.WriteLine("           <Response/>");
                        outputFile.WriteLine(
                            $"           <Condition>(proxy.pathsuffix MatchesPath \"/{entity.PluralName.ToLower()}\") and (request.verb = \"GET\")</Condition>");
                        outputFile.WriteLine("       </Flow>");
                    }

                    if (entity.HasCommand("create"))
                    {
                        outputFile.WriteLine($"       <Flow name=\"post-{entity.Name.FriendlyCase().ToLower()}\">");
                        outputFile.WriteLine($"           <Description>post-{entity.Name.FriendlyCase().ToLower()}</Description>");
                        outputFile.WriteLine("           <Request/>");
                        outputFile.WriteLine("           <Response/>");
                        outputFile.WriteLine(
                            $"           <Condition>(proxy.pathsuffix MatchesPath \"/{entity.PluralName.ToLower()}\") and (request.verb = \"POST\")</Condition>");
                        outputFile.WriteLine("       </Flow>");
                    }

                    if (entity.HasCommand("update"))
                    {
                        outputFile.WriteLine(
                            $"       <Flow name=\"put-{entity.Name.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}\">");
                        outputFile.WriteLine(
                            $"           <Description>put-{entity.Name.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}</Description>");
                        outputFile.WriteLine("           <Request/>");
                        outputFile.WriteLine("           <Response/>");
                        outputFile.WriteLine(
                            $"           <Condition>(proxy.pathsuffix MatchesPath \"/{entity.PluralName.ToLower()}/{entity.PrimaryKeysForRoute()}\") and (request.verb = \"PUT\")</Condition>");
                        outputFile.WriteLine("       </Flow>");
                    }

                    if (entity.HasCommand("delete") && entity.HasPrimaryKey())
                    {
                        outputFile.WriteLine(
                            $"       <Flow name=\"delete-{entity.Name.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}\">");
                        outputFile.WriteLine(
                            $"           <Description>delete-{entity.Name.FriendlyCase().ToLower()}-by-{entity.PrimaryKeysForApigee()}</Description>");
                        outputFile.WriteLine("           </Request/>");
                        outputFile.WriteLine("           <Response/>");
                        outputFile.WriteLine(
                            $"           <Condition>(proxy.pathsuffix MatchesPath \"/{entity.PluralName.ToLower()}/{entity.PrimaryKeysForRoute()}\") and (request.verb = \"DELETE\")</Condition>");
                        outputFile.WriteLine("       </Flow>");
                    }
                }
                
                WriteEnd(outputFile);
            }
        }

        public void WriteStart(StreamWriter outputFile)
        {
            outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>");
            outputFile.WriteLine("<ProxyEndpoint name=\"default\">");
            outputFile.WriteLine("    <Description/>");
            outputFile.WriteLine("    <FaultRules/>");
            outputFile.WriteLine("    <PreFlow name=\"PreFlow\">");
            outputFile.WriteLine("        <Request>");
            outputFile.WriteLine("            <Step>");
            outputFile.WriteLine("                <Name>verify-oauth-v2-access-token</Name>");
            outputFile.WriteLine("            </Step>");
            outputFile.WriteLine("            <Step>");
            outputFile.WriteLine("                <Name>remove-header-authorization</Name>");
            outputFile.WriteLine("            </Step>");
            outputFile.WriteLine("            <Step>");
            outputFile.WriteLine("                <Name>impose-quota</Name>");
            outputFile.WriteLine("            </Step>");
            outputFile.WriteLine("        </Request>");
            outputFile.WriteLine("        <Response/>");
            outputFile.WriteLine("    </PreFlow>");
            outputFile.WriteLine("    <PostFlow name=\"PostFlow\">");
            outputFile.WriteLine("        <Request/>");
            outputFile.WriteLine("        <Response/>");
            outputFile.WriteLine("    </PostFlow>");
            outputFile.WriteLine("    <Flows>");
        }

        public void WriteEnd(StreamWriter outputFile)
        {

            outputFile.WriteLine("       <Flow name=\"catch-all - flow\">");
            outputFile.WriteLine("           <Description>catch-all-flow</Description>");
            outputFile.WriteLine("           <Request>");
            outputFile.WriteLine("               <Step>");
            outputFile.WriteLine("                   <Name>Raise-Fault-NoFlowMatch</Name>");
            outputFile.WriteLine("               </Step>");
            outputFile.WriteLine("           </Request>");
            outputFile.WriteLine("           <Response/>");
            outputFile.WriteLine($"           <Condition>(proxy.basepath MatchesPath \"/{EntityMap.Namespace.ToLower()}\")</Condition>");
            outputFile.WriteLine("       </Flow>");
            outputFile.WriteLine("    </Flows>");
            outputFile.WriteLine("    <HTTPProxyConnection>");

            outputFile.WriteLine($"        <BasePath>/{EntityMap.Namespace.ToLower()}</BasePath>");
            outputFile.WriteLine("        <Properties/>");
            outputFile.WriteLine("        <VirtualHost>expenses</VirtualHost>");
            outputFile.WriteLine("    </HTTPProxyConnection>");
            outputFile.WriteLine("    <RouteRule name=\"default\">");
            outputFile.WriteLine("        <TargetEndpoint>default</TargetEndpoint>");
            outputFile.WriteLine("    </RouteRule>");
            outputFile.WriteLine("</ProxyEndpoint>");
        }
    }
}