﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class WriterBase
    {
        internal static ModelsMap EntityMap { get; set; }

        internal Entity Entity { get; }

        internal string EntityDir { get; }

        internal string SubDir { get; }

        private WriterBase()
        {
        }

        internal WriterBase(ModelsMap entityMap, Entity entity, string entityDir, string subDir)
        {
            EntityMap = entityMap;
            Entity = entity;
            EntityDir = entityDir;
            SubDir = subDir;
        }

        public Entity GetEntity() => Entity;

        public virtual WriterTypes GetWriterType() => WriterTypes.Clients;

        public virtual string GetSubPath()
        {
            return $"{Entity.Name}";
        }

        public virtual string GetFileName()
        {
            return $"{Entity.Name}.generated.cs";
        }

        public virtual bool VerifyVisibility()
        {
            return true;
        }

        public virtual string GetProjectPath()
        {
            return !string.IsNullOrEmpty(SubDir) ? Path.Combine(SubDir, Path.Combine(GetWriterType().ToString(), "Generated")) : Path.Combine(GetWriterType().ToString(), "Generated", GetSubPath());
        }

        public string GetProjectPathAndName()
        {
            return Path.Combine(GetProjectPath(), GetFileName());
        }

        public string GetFilePath()
        {
            return Path.Combine(EntityDir, GetProjectPath());
        }

        public virtual string GetFilePathAndName()
        {
            return Path.Combine(EntityDir, GetProjectPathAndName());
        }

        protected static void WriteHeader(StreamWriter outputFile, string fileName)
        {
            outputFile.WriteLine("/*");
            outputFile.WriteLine($"Created by ProjectBuilder Version: {new WriterBase().GetType().Assembly.GetName().Version}");
            outputFile.WriteLine($"On: {DateTime.Now}");
            outputFile.WriteLine("*/");
            outputFile.WriteLine("");
        }

        protected static string GetMethodParameterNamesFromProperties(ModelsMap entityMap, IEnumerable<Property> props, IEnumerable<Relationship> relationships, bool namesOnly = false)
        {
            List<string> result = new List<string>();

            foreach (Property prop in props)
            {
                if (namesOnly)
                    result.Add(string.Format("{0}", prop.Name.CamelCase()));
                else
                {
                    string format;
                    if (prop.Type.ToLower() != "string" && prop.Type.GetEntityType() != "byte[]" && prop.AllowNull)
                    {
                        format = "{0}? {1}";
                    }
                    else
                    {
                        format = "{0} {1}";
                    }

                    result.Add(string.Format(format, prop.EntityType(), prop.Name.CamelCase()));
                }
            }

            foreach (Relationship rel in relationships)
            {
                if (EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                {
                    continue;
                }

                if (namesOnly)
                    result.Add(string.Format("{0}", rel.RelatedEntity.CamelCase()));
                else
                {
                    if (rel.Cardinality == "OneToMany")
                        result.Add(string.Format("List<{0}> {1}", rel.RelatedEntity, rel.RelatedEntity.CamelCase()));
                    else
                        result.Add(string.Format("{0} {1}", rel.RelatedEntity, rel.RelatedEntity.CamelCase()));
                }

            }

            return string.Join(", ", result);
        }
    }
}
