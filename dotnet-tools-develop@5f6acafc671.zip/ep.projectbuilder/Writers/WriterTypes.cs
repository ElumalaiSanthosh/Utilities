﻿namespace ProjectBuilder.Writers
{
    public enum WriterTypes
    {
        Dtos,
        Entities,
        Clients,
        Controllers,
        Services,
        Flow
    }
}
