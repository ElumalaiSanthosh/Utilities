﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ControllerQueryWriter : WriterBase, IWriter
    {
        internal ControllerQueryWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}QueryController.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                    Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using ApiService.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Logger;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Controllers;");
                outputFile.WriteLine("using Microsoft.AspNet.OData;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Query;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Mvc;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Controllers");
                outputFile.WriteLine("{");
                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine($"    /// Provides API methods for the {Entity.Name} entity");
                outputFile.WriteLine("    /// </summary>");
                outputFile.WriteLine($"    [Route(\"{Entity.PluralName.ToLower()}\")]");
                outputFile.WriteLine("    [Produces(\"application/json\")]");
                outputFile.WriteLine($"    public partial class {Entity.PluralName}Controller : DefaultApiController<{Entity.PluralName}Controller>");
                outputFile.WriteLine("    {");
                outputFile.WriteLine($"        private I{Entity.Name}Service {Entity.Name}Service " + "{ get; }");
                outputFile.WriteLine("");                
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        ///");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine($"        public {Entity.PluralName}Controller(IConfiguration config, I{Entity.Name}Service {Entity.Name.CamelCase()}Service, IApiCache cache): base(config, \"{EntityMap.Namespace}\", {EntityMap.Version}, cache)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine($"            {Entity.Name}Service = {Entity.Name.CamelCase()}Service;");                
                outputFile.WriteLine("        }");

                if (Entity.HasCommand("get"))
                {
                    if (Entity.HasPrimaryKey())
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("        /// <summary>");
                        outputFile.WriteLine($"        /// Returns a {Entity.Name}");
                        outputFile.WriteLine("        /// </summary>");

                        foreach (var p in Entity.PrimaryKeyList())
                        {
                            outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                        }
                        if (Entity.HasDataset && Entity.HasOneToMany())
                        {
                            outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\">Optional flag used to return child / related records. Defaults to true.</param>");
                        }

                        outputFile.WriteLine("        /// <returns></returns>");
                        outputFile.WriteLine("        /// <response code=\"200\">Record found and returned</response>");
                        outputFile.WriteLine("        /// <response code=\"204\">Record Not found</response>");
                        outputFile.WriteLine("        /// <response code=\"400\">Bad Request - The request is malformed or invalid</response>");
                        outputFile.WriteLine("        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                        outputFile.WriteLine("        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                        outputFile.WriteLine("        /// <response code=\"404\">Record not found for id</response>");
                        outputFile.WriteLine("        /// <response code=\"410\">The requested resource is no longer available at the server and no forwarding address is known </response>");
                        outputFile.WriteLine("        /// <response code=\"414\">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>");
                        outputFile.WriteLine("        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                        outputFile.WriteLine($"        [HttpGet(\"{Entity.PrimaryKeysForRoute()}\")]");
                        outputFile.WriteLine($"        [ProducesResponseType(200, Type = typeof({Entity.Name}))]");
                        outputFile.Write($"        public async Task<IActionResult> GetAsync({Entity.PrimaryKeysWithTypes()}");

                        if (Entity.HasDataset && Entity.HasOneToMany())
                        {
                            outputFile.Write(", bool shouldReturnRelatedRecords = false");
                        }

                        outputFile.Write($"){Environment.NewLine}");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine("            try");
                        outputFile.WriteLine("            {");

                        if (Entity.EnableCache)
                        {
                            outputFile.Write("                string cacheKey = $\"" + "{Startup.BaseCacheKey}" + $".{Entity.PluralName.ToLower()}.{Entity.PrimaryKeysForCache()}");
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write(".shouldReturnRelatedRecords={shouldReturnRelatedRecords}");
                            }
                            outputFile.Write($"\";{Environment.NewLine}");

                            outputFile.WriteLine("");
                            outputFile.WriteLine($"                var cacheValue = Cache.GetJson<{Entity.Name}>(cacheKey);");
                            outputFile.WriteLine("");
                            outputFile.WriteLine("                if (cacheValue != null)");
                            outputFile.WriteLine("                {");
                            outputFile.WriteLine("                    return Ok(cacheValue);");
                            outputFile.WriteLine("                }");
                            outputFile.WriteLine("");
                        }

                        if (Entity.HasDataset)
                        {
                            outputFile.Write($"                var result = await {Entity.Name}Service.GetAsync({Entity.PrimaryKeys(false)}");

                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write(", shouldReturnRelatedRecords: shouldReturnRelatedRecords");
                            }

                            outputFile.Write($");{Environment.NewLine}");
                        }
                        else
                        {
                            outputFile.WriteLine($"                var result = await {Entity.Name}Service.GetAsync({Entity.PrimaryKeys(false)});");
                        }

                        outputFile.WriteLine("");
                        outputFile.WriteLine("                if (result == null) return NoContent();");
                        outputFile.WriteLine("");

                        if (Entity.EnableCache)
                        {
                            outputFile.WriteLine("                Cache.SetJson(cacheKey, result);");
                            outputFile.WriteLine("");
                        }

                        outputFile.WriteLine("                return Ok(result);");
                        outputFile.WriteLine("            }");
                        outputFile.WriteLine("            catch (Exception e)");
                        outputFile.WriteLine("            {");
                        outputFile.WriteLine("                return HandleException(e);");
                        outputFile.WriteLine("            }");
                        outputFile.WriteLine("        }");
                        outputFile.WriteLine("");


                        IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");
                        if (relationships.Any())
                        {
                            foreach (var r in relationships)
                            {
                                outputFile.WriteLine("");
                                outputFile.WriteLine("        /// <summary>");
                                outputFile.WriteLine($"        /// Returns a List of {Entity.PluralName}");
                                outputFile.WriteLine("        /// </summary>");
                                outputFile.WriteLine($"        /// <param name=\"{r.PropertyName.CamelCase()}\">Unique identifier used to retrieve a {Entity.Name} Entity</param>");
                                outputFile.WriteLine("        /// <returns></returns>");
                                outputFile.WriteLine("        /// <response code=\"200\">Record found and returned</response>");
                                outputFile.WriteLine("        /// <response code=\"204\">Record Not found</response>");
                                outputFile.WriteLine("        /// <response code=\"400\">Bad Request - The request is malformed or invalid</response>");
                                outputFile.WriteLine("        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                                outputFile.WriteLine("        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                                outputFile.WriteLine("        /// <response code=\"404\">Record not found for id</response>");
                                outputFile.WriteLine("        /// <response code=\"410\">The requested resource is no longer available at the server and no forwarding address is known </response>");
                                outputFile.WriteLine("        /// <response code=\"414\">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>");
                                outputFile.WriteLine("        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                                outputFile.WriteLine($"        [HttpGet(\"{r.Name.ToLower()}/" + "{" + r.PropertyName.CamelCase() + "}\")]");
                                outputFile.WriteLine($"        [ProducesResponseType(200, Type = typeof(List<{Entity.Name}>))]");
                                outputFile.WriteLine($"        public async Task<IActionResult> GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipWithType(Entity)})");
                                outputFile.WriteLine("        {");
                                outputFile.WriteLine("            try");
                                outputFile.WriteLine("            {");                                
                                outputFile.WriteLine($"                var result = await {Entity.Name}Service.GetBy{r.PropertyName}Async({r.PropertyName.CamelCase()});");
                                outputFile.WriteLine("");
                                outputFile.WriteLine("                if (result == null || !result.Any()) return NoContent();");
                                outputFile.WriteLine("");
                                outputFile.WriteLine("                return Ok(result);");
                                outputFile.WriteLine("            }");
                                outputFile.WriteLine("            catch (Exception e)");
                                outputFile.WriteLine("            {");
                                outputFile.WriteLine("                return HandleException(e);");
                                outputFile.WriteLine("            }");
                                outputFile.WriteLine("        }");
                            }
                        }

                        if (Entity.UniqueKeys.Any())
                        {
                            foreach (var key in Entity.UniqueKeys)
                            {
                                List<string> props = key.Properties.Split(",").ToList();
                                outputFile.WriteLine("");
                                outputFile.WriteLine("        /// <summary>");
                                outputFile.WriteLine($"        /// Returns a {Entity.Name}");
                                outputFile.WriteLine("        /// </summary>");

                                foreach (var p in props)
                                {
                                    outputFile.WriteLine($"        /// <param name=\"{p.CamelCase()}\"></param>");
                                }
                                if (Entity.HasDataset && Entity.HasOneToMany())
                                {
                                    outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\"></param>");
                                }

                                outputFile.WriteLine("        /// <returns></returns>");
                                outputFile.WriteLine("        /// <response code=\"200\">Record found and returned</response>");
                                outputFile.WriteLine("        /// <response code=\"204\">Record Not found</response>");
                                outputFile.WriteLine("        /// <response code=\"400\">Bad Request - The request is malformed or invalid</response>");
                                outputFile.WriteLine("        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                                outputFile.WriteLine("        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                                outputFile.WriteLine("        /// <response code=\"404\">Record not found for id</response>");
                                outputFile.WriteLine("        /// <response code=\"410\">The requested resource is no longer available at the server and no forwarding address is known </response>");
                                outputFile.WriteLine("        /// <response code=\"414\">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>");
                                outputFile.WriteLine("        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                                outputFile.WriteLine($"        [HttpGet(\"{props.UniqueKeyTarget(Entity)}\")]");
                                outputFile.WriteLine($"        [ProducesResponseType(200, Type = typeof({Entity.Name}))]");
                                outputFile.Write($"        public async Task<IActionResult> GetBy{props.UniqueName()}Async({props.UniqueKeysWithTypes(Entity)}");

                                if (Entity.HasDataset && Entity.HasOneToMany())
                                {
                                    outputFile.Write(", bool shouldReturnRelatedRecords = false");
                                }

                                outputFile.Write($"){Environment.NewLine}");
                                outputFile.WriteLine("        {");
                                outputFile.WriteLine("            try");
                                outputFile.WriteLine("            {");

                                if (Entity.EnableCache)
                                {
                                    outputFile.Write($"                string cacheKey = $\"" + "{Startup.BaseCacheKey}" + $".{Entity.PluralName.ToLower()}.{props.UniqueKeyCache(Entity)}");
                                    if (Entity.HasDataset && Entity.HasOneToMany())
                                    {
                                        outputFile.Write(".shouldReturnRelatedRecords={shouldReturnRelatedRecords}");
                                    }
                                    outputFile.Write($"\";{Environment.NewLine}");

                                    outputFile.WriteLine("");
                                    outputFile.WriteLine($"                var cacheValue = Cache.GetJson<{Entity.Name}>(cacheKey);");
                                    outputFile.WriteLine("");
                                    outputFile.WriteLine("                if (cacheValue != null)");
                                    outputFile.WriteLine("                {");
                                    outputFile.WriteLine("                    return Ok(cacheValue);");
                                    outputFile.WriteLine("                }");
                                    outputFile.WriteLine("");
                                }

                                outputFile.Write($"                var result = await {Entity.Name}Service.GetBy{props.UniqueName()}Async({props.UniqueKeys()}");

                                if (Entity.HasDataset && Entity.HasOneToMany())
                                {
                                    outputFile.Write(", shouldReturnRelatedRecords: shouldReturnRelatedRecords");
                                }

                                outputFile.Write($");{Environment.NewLine}");
                                outputFile.WriteLine("");
                                outputFile.WriteLine("                if (result == null) return NoContent();");
                                outputFile.WriteLine("");

                                if (Entity.EnableCache)
                                {
                                    outputFile.WriteLine("                Cache.SetJson(cacheKey, result);");
                                    outputFile.WriteLine("");
                                }

                                outputFile.WriteLine("                return Ok(result);");
                                outputFile.WriteLine("            }");
                                outputFile.WriteLine("            catch (Exception e)");
                                outputFile.WriteLine("            {");
                                outputFile.WriteLine("                return HandleException(e);");
                                outputFile.WriteLine("            }");

                                outputFile.WriteLine("        }");
                            }
                        }

                        outputFile.WriteLine("");
                    }

                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine($"        /// Returns a list of {Entity.PluralName}");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"options\"></param>");
                    outputFile.WriteLine($"        /// <param name=\"columns\">Optional comma-delimited list of {Entity.Name} fields to return</param>");
                    outputFile.WriteLine("        /// <response code=\"200\">Record found and returned</response>");
                    outputFile.WriteLine("        /// <response code=\"204\">Record Not found</response>");
                    outputFile.WriteLine("        /// <response code=\"400\">Bad Request - The request is malformed or invalid</response>");
                    outputFile.WriteLine("        /// <response code=\"401\">Unauthorized - The request requires user authentication </response>");
                    outputFile.WriteLine("        /// <response code=\"403\">Forbidden - The server understood the request, but is refusing to fulfill it </response>");
                    outputFile.WriteLine("        /// <response code=\"404\">Record not found for id</response>");
                    outputFile.WriteLine("        /// <response code=\"410\">The requested resource is no longer available at the server and no forwarding address is known </response>");
                    outputFile.WriteLine("        /// <response code=\"414\">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>");
                    outputFile.WriteLine("        /// <response code=\"500\">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>");
                    outputFile.WriteLine($"        [HttpGet(Name = \"getMany{Entity.PluralName.ToLower()}\")]");
                    outputFile.WriteLine($"        public async Task<IActionResult> GetManyAsync(ODataQueryOptions<{Entity.Name}> options, string columns = null)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            try");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine("                ICollection<string> listColumns = columns?.Split(',').Select(p => p.Trim()).ToList();");
                    
                    outputFile.WriteLine("                QueryOptions queryOptions = options.ParseOdata(MaxTop);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (listColumns == null || listColumns.Count == 0)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    var returnMany = (await {Entity.Name}Service.GetManyAsync(queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                    if (returnMany == null || returnMany.Items == null || !returnMany.Items.Any()) return NoContent();");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                    return Ok(returnMany);");

                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (listColumns.Count == 1)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    var returnList = (await {Entity.Name}Service.GetListAsync(listColumns.First(), queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                    if (returnList == null || returnList.Items == null || !returnList.Items.Any()) return NoContent();");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                    return Ok(returnList);");
                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"                var resultDynamic = (await {Entity.Name}Service.GetDynamicObjectsAsync(listColumns, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (resultDynamic == null || resultDynamic.Items == null || !resultDynamic.Items.Any()) return NoContent();");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                return Ok(resultDynamic);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("            catch (Exception e)");
                    outputFile.WriteLine("            {");
                    outputFile.WriteLine("                return HandleException(e);");
                    outputFile.WriteLine("            }");
                    outputFile.WriteLine("        }");
                }
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
