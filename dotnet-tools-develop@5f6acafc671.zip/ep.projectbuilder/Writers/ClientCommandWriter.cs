﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ClientCommandWriter : WriterBase, IWriter
    {
        internal ClientCommandWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{EntityMap.Namespace}.{Entity.Name}CommandClient.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Clients;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "view" ||
                Entity.Visibility == "internal" ||
                Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Entities;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Clients");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.Write($"    public partial class {EntityMap.Namespace}Client : ");
                outputFile.Write($"I{EntityMap.Namespace}Client{Environment.NewLine}");
                outputFile.WriteLine("    {");
                
                if (Entity.Visibility == "public" && Entity.HasCommandElement())
                {   
                    outputFile.WriteLine("        #region Commands");
                    if (Entity.HasCommand("create"))
                    {
                        outputFile.WriteLine($"        public async Task<RequestResponse<{Entity.Name}>> Post{Entity.Name}Async({Entity.Name} entity, int timeout = 0)");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            return await ServiceClient.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", method: ApiRestVerbs.Post, successStatus: HttpStatusCode.Created, bodyObjects: new List<object>" + "{ entity }, timeout: timeout);");                        
                        outputFile.WriteLine("        }");
                    }

                    if (Entity.HasCommand("update"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"        public async Task<RequestResponse<{Entity.Name}>> Put{Entity.Name}Async({Entity.Name} entity, {Entity.PrimaryKeysWithTypes()}, int timeout = 0)");
                        outputFile.WriteLine("        {");
                        outputFile.WriteLine($"            return await ServiceClient.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", method: ApiRestVerbs.Put, successStatus: HttpStatusCode.OK, bodyObjects: new List<object>" + "{ entity }, urlSegments: new List<string> " + "{" + $" {Entity.PrimaryKeys()} " + "}, timeout: timeout);");                        
                        outputFile.WriteLine("        }");
                    }
                    if (Entity.HasCommand("delete"))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"        public async Task<RequestResponse<bool>> Delete{Entity.Name}Async({Entity.PrimaryKeysWithTypes()}, int timeout = 0)");
                        outputFile.WriteLine("        {");

                        foreach (Property property in Entity.Properties)
                        {
                            if (property.PrimaryKey)
                            {
                                if (property.EntityType() == "string")
                                {
                                    outputFile.WriteLine($"            if (string.IsNullOrEmpty({property.Name.CamelCase()}))");
                                }
                                else
                                {
                                    outputFile.WriteLine($"            if ({property.Name.CamelCase()} < 1)");
                                }
                                outputFile.WriteLine("            {");
                                outputFile.WriteLine($"                throw new ArgumentException(\"Invalid Parameter ({property.Name.CamelCase()}).\");");
                                outputFile.WriteLine("            }");
                                outputFile.WriteLine("");
                            }
                        }

                        outputFile.WriteLine($"            return await ServiceClient.GetRequestResponseAsync<bool>(\"{Entity.PluralName.ToLower()}\", method: ApiRestVerbs.Delete, successStatus: HttpStatusCode.OK, urlSegments: new List<string> " + "{" + $" {Entity.PrimaryKeys()} " + "}, timeout: timeout);");                        
                        outputFile.WriteLine("        }");
                    }
                    outputFile.WriteLine("        #endregion Commands");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }


        private static IList<string> GetScopes(string scopes)
        {
            return scopes.Split(',').ToList();
        }
    }
}
