﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    public class ApigeeWriter : WriterBase
    {
        internal ApigeeWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return ($"");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Flow;

        public override string GetProjectPath()
        {
            return @"apiproxy";
        }

        public override bool VerifyVisibility()
        {
            return true;
        }

        public void Create(ref bool firstPass)
        {
            Develop();
        }

        public void Develop()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), $"{EntityMap.Namespace}.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine($"<APIProxy revision=\"1\" name=\"{EntityMap.Namespace}\">");
                outputFile.WriteLine("    <ConfigurationVersion majorVersion=\"0\" minorVersion=\"0\"/>");
                //outputFile.WriteLine($"    <CreatedBy>{System.Security.Principal.WindowsIdentity.GetCurrent().Name}</CreatedBy>");
                outputFile.WriteLine("    <Description></Description>");
                outputFile.WriteLine($"    <DisplayName>{EntityMap.Namespace}</DisplayName>");
                outputFile.WriteLine("    <Policies>");
                outputFile.WriteLine("        <Policy>Raise-Fault-NoFlowMatch</Policy>");
                outputFile.WriteLine("        <Policy>add-cors</Policy>");
                outputFile.WriteLine("        <Policy>impose-quota</Policy>");
                outputFile.WriteLine("        <Policy>remove-header-authorization</Policy>");
                outputFile.WriteLine("        <Policy>verify-oauth-v2-access-token</Policy>");

                if (string.IsNullOrEmpty(EntityMap.Scope)) return;
                string[] scopes = EntityMap.Scope.Split(',');

                foreach (var scope in scopes)
                {
                    outputFile.WriteLine($"        <Policy>OAuth-v20-{scope}</Policy>");
                }

                outputFile.WriteLine("    </Policies>");
                outputFile.WriteLine("    <ProxyEndpoints>");
                outputFile.WriteLine("        <ProxyEndpoint>default</ProxyEndpoint>");
                outputFile.WriteLine("    </ProxyEndpoints>");
                outputFile.WriteLine("    <Resources/>");
                outputFile.WriteLine("    <TargetServers/>");
                outputFile.WriteLine("    <TargetEndpoints>");
                outputFile.WriteLine("        <TargetEndpoint>default</TargetEndpoint>");
                outputFile.WriteLine("    </TargetEndpoints>");
                outputFile.WriteLine("    <validate>false</validate>");
                outputFile.WriteLine("</APIProxy>");
            }
        }
    }
}
