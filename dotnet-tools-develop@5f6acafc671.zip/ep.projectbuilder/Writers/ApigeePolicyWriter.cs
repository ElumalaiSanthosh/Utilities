﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    public class ApigeePolicyWriter : WriterBase
    {
        internal ApigeePolicyWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return ($"");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Flow;

        public override string GetProjectPath()
        {
            return @"apiproxy\policies";
        }

        public override bool VerifyVisibility()
        {
            return true;
        }

        public void Create(ref bool firstPass)
        {
            bool exists = Directory.Exists(Path.Combine(EntityDir, "apiproxy", "policies"));

            if (!exists) Directory.CreateDirectory(Path.Combine(EntityDir, "apiproxy", "policies"));


            DirectoryInfo di = new DirectoryInfo(Path.Combine(EntityDir, GetProjectPath()));
            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }

            AddCors();
            ImposeQuota();
            NoFlow();
            RemoveHeader();
            VerifyOAuth();

            if (string.IsNullOrEmpty(EntityMap.Scope)) return;

            string[] scopes = EntityMap.Scope.Split(',');

            foreach (var scope in scopes)
            {
                Policies(scope);
            }
        }

        public void AddCors()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir,GetProjectPath(), "add-cors.xml")))
            {
                outputFile.WriteLine("<AssignMessage async=\"false\" continueOnError=\"false\" enabled=\"true\" name=\"add-cors\">");
                outputFile.WriteLine("    <DisplayName>Add CORS</DisplayName>");
                outputFile.WriteLine("    <FaultRules/>");
                outputFile.WriteLine("    <Properties/>");
                outputFile.WriteLine("    <Add>");
                outputFile.WriteLine("        <Headers>");
                outputFile.WriteLine("            <Header name=\"Access-Control-Allow-Origin\">*</Header>");
                outputFile.WriteLine("            <Header name=\"Access-Control-Allow-Headers\">origin, x-requested-with, accept</Header>");
                outputFile.WriteLine("            <Header name=\"Access-Control-Max-Age\">3628800</Header>");
                outputFile.WriteLine("            <Header name=\"Access-Control-Allow-Methods\">GET, PUT, POST, DELETE</Header>");
                outputFile.WriteLine("        </Headers>");
                outputFile.WriteLine("    </Add>");
                outputFile.WriteLine("    <IgnoreUnresolvedVariables>true</IgnoreUnresolvedVariables>");
                outputFile.WriteLine("    <AssignTo createNew=\"false\" transport=\"http\" type=\"response\"/>");
                outputFile.WriteLine("</AssignMessage>");
            }
        }

        public void ImposeQuota()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), "impose-quota.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine("<Quota async=\"false\" continueOnError=\"false\" enabled=\"true\" name=\"impose-quota\">");
                outputFile.WriteLine("    <DisplayName>Impose Quota</DisplayName>");
                outputFile.WriteLine("    <Allow countRef=\"apiproduct.developer.quota.limit\" count=\"2000\"/>");
                outputFile.WriteLine("    <Interval ref=\"apiproduct.developer.quota.interval\">1</Interval>");
                outputFile.WriteLine("    <Distributed>true</Distributed>");
                outputFile.WriteLine("    <Synchronous>true</Synchronous>");
                outputFile.WriteLine("    <TimeUnit ref=\"apiproduct.developer.quota.timeunit\">month</TimeUnit>");
                outputFile.WriteLine("</Quota>");
            }
        }

        public void NoFlow()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), "Raise-Fault-NoFlowMatch.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine("<RaiseFault async=\"false\" continueOnError=\"false\" enabled=\"true\" name=\"Raise-Fault-NoFlowMatch\">");
                outputFile.WriteLine("    <DisplayName>Raise Fault-NoFlowMatch</DisplayName>");
                outputFile.WriteLine("    <Properties/>");
                outputFile.WriteLine("    <FaultResponse>");
                outputFile.WriteLine("        <Set>");
                outputFile.WriteLine("            <Headers/>");
                outputFile.WriteLine("            <Payload contentType=\"text/plain\"/>");
                outputFile.WriteLine("            <StatusCode>404</StatusCode>");
                outputFile.WriteLine("            <ReasonPhrase>Not Found</ReasonPhrase>");
                outputFile.WriteLine("        </Set>");
                outputFile.WriteLine("    </FaultResponse>");
                outputFile.WriteLine("    <IgnoreUnresolvedVariables>true</IgnoreUnresolvedVariables>");
                outputFile.WriteLine("</RaiseFault>");
            }
        }
        public void RemoveHeader()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), "remove-header-authorization.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine("<AssignMessage async=\"false\" continueOnError=\"false\" enabled=\"false\" name=\"remove-header-authorization\">");
                outputFile.WriteLine("    <DisplayName>Remove Header Authorization</DisplayName>");
                outputFile.WriteLine("    <Remove>");
                outputFile.WriteLine("        <Headers>");
                outputFile.WriteLine("            <Header name=\"Authorization\"/>");
                outputFile.WriteLine("        </Headers>");
                outputFile.WriteLine("    </Remove>");
                outputFile.WriteLine("    <IgnoreUnresolvedVariables>true</IgnoreUnresolvedVariables>");
                outputFile.WriteLine("    <AssignTo createNew=\"false\" transport=\"http\" type=\"request\"/>");
                outputFile.WriteLine("</AssignMessage>");
            }
        }
        public void VerifyOAuth()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), "verify-oauth-v2-access-token.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine("<OAuthV2 async=\"false\" continueOnError=\"false\" enabled=\"true\" name=\"verify-oauth-v2-access-token\">");
                outputFile.WriteLine("    <DisplayName>Verify OAuth v2.0 Access Token</DisplayName>");
                outputFile.WriteLine("    <Operation>VerifyAccessToken</Operation>");
                outputFile.WriteLine("</OAuthV2>");
            }
        }

        public void Policies(string scope)
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), $"OAuth-v20-{scope}.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine($"<OAuthV2 async=\"false\" continueOnError=\"false\" enabled=\"true\" name=\"OAuth-v20-{scope}\">");
                outputFile.WriteLine($"    <DisplayName>OAuth v2.0-{scope}</DisplayName>");
                outputFile.WriteLine("    <Properties/>");
                outputFile.WriteLine("    <Attributes/>");
                outputFile.WriteLine("    <ExternalAuthorization>false</ExternalAuthorization>");
                outputFile.WriteLine("    <Operation>VerifyAccessToken</Operation>");
                outputFile.WriteLine($"    <Scope>{scope}</Scope>");
                outputFile.WriteLine("    <SupportedGrantTypes/>");
                outputFile.WriteLine("    <GenerateResponse enabled=\"true\"/>");
                outputFile.WriteLine("    <Tokens/>");
                outputFile.WriteLine("</OAuthV2>");
            }
        }
    }
}
