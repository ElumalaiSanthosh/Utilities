﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ServiceWriterQuery : WriterBase, IWriter
    {
        internal ServiceWriterQuery(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}QueryService.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Services;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Data;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using ApiService.Commons.Helpers;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Exceptions;");
                outputFile.WriteLine("using ApiService.Repositories;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using ApiService.Commons.Logger;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");
                outputFile.WriteLine("using ApiService.Commons.Events;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("using Microsoft.Extensions.Logging;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Services");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// ");
                outputFile.WriteLine("    /// </summary>");
                outputFile.Write($"    public partial class {Entity.Name}Service : ");

                if (Entity.HasDataset)
                {
                    outputFile.Write($"Service<{Entity.Name}>, ");
                }
                outputFile.Write($"I{Entity.Name}Service{Environment.NewLine}");

                outputFile.WriteLine("    {");                
                outputFile.WriteLine("");
                if (Entity.HasDataset)
                {
                    HashSet<string> serviceNames = new HashSet<string>();
                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (!serviceNames.Contains(rel.RelatedEntity))
                        {
                            if (rel.Cardinality == "OneToMany" || rel.Cardinality == "ManyToOne")
                            {
                                outputFile.WriteLine($"        private I{rel.RelatedEntity}Service {rel.RelatedEntity}Service " + "{ get; }");
                            }
                            else
                            {
                                outputFile.WriteLine($"        private I{rel.RelatedEntity}Service _{rel.RelatedEntity.CamelCase()}Service;");
                                outputFile.WriteLine($"        private I{rel.RelatedEntity}Service {rel.RelatedEntity}Service => _{rel.RelatedEntity.CamelCase()}Service ?? (_{rel.RelatedEntity.CamelCase()}Service = (I{rel.RelatedEntity}Service) ServiceProvider.GetService(typeof(I{rel.RelatedEntity}Service)));");
                            }
                            serviceNames.Add(rel.RelatedEntity);
                        }
                    }
                    
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// ");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"config\"></param>");
                    outputFile.WriteLine("        /// <param name=\"serviceProvider\"></param>");
                    outputFile.WriteLine("        /// <param name=\"repository\"></param>");
                    outputFile.WriteLine("        /// <param name=\"cache\"></param>");
                    outputFile.WriteLine("        /// <param name=\"producerWrapper\"></param>");

                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (rel.Cardinality == "OneToMany" || rel.Cardinality == "ManyToOne")
                        {
                            outputFile.WriteLine($"        /// <param name=\"{rel.RelatedEntity.CamelCase()}Service\"></param>");
                        }
                    }

                    outputFile.WriteLine($"        public {Entity.Name}Service(IConfiguration config, IServiceProvider serviceProvider, IRepository<{Entity.Name}> repository{((Entity.HasOneToMany() || Entity.HasManyToOne()) ? "," : "")} {Entity.RelationshipsForConstructor()}, IApiCache cache, IProducerWrapper producerWrapper) : base(config, serviceProvider, repository, cache, producerWrapper)");
                    outputFile.WriteLine("        {");
                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (rel.Cardinality == "OneToOne")
                        {
                            //outputFile.WriteLine($"            {rel.RelatedEntity}Service = {rel.RelatedEntity.CamelCase()}Service;");
                            continue;
                        }

                        outputFile.WriteLine($"            {rel.RelatedEntity}Service = {rel.RelatedEntity.CamelCase()}Service;");
                    }

                    outputFile.WriteLine("        }");
                }
                else
                {
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// ");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine("        /// <param name=\"provider\"></param>");
                    outputFile.WriteLine("        /// <param name=\"queryBuilder\"></param>");
                    outputFile.WriteLine($"        public {Entity.Name}Service()");
                    outputFile.WriteLine("        {");

                    outputFile.WriteLine($"            Log = ApiLogging.CreateLogger<{Entity.Name}Service>();");

                    if (Entity.HasDataset)
                    {
                        foreach (Relationship rel in Entity.Relationships)
                        {
                            outputFile.WriteLine($"            {rel.RelatedEntity}Service = new {rel.RelatedEntity}Service(provider, DataStoreFactory.GetQueryBuilder<{rel.RelatedEntity}>());");
                        }
                    }

                    outputFile.WriteLine("        }");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("        #region QueryService");
                if (Entity.HasPrimaryKey())
                {
                    CreateGet(outputFile);
                }
                CreateGetOneToOne(outputFile);
                CreateGetUnique(outputFile);
                CreateGetMany(outputFile);

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private void CreateGet(StreamWriter outputFile)
        {
            if (Entity.HasPrimaryKey())
            {
                outputFile.WriteLine("");
                outputFile.Write($"        partial void BeforeGet(ref bool result, {Entity.PrimaryKeysWithRefTypes()}");

                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.Write(", ref bool shouldReturnRelatedRecords");
                    }
                }
                outputFile.Write($");{Environment.NewLine}");

                if (!Entity.HasDataset)
                {
                    outputFile.Write(
                        $"        partial void GetOverride(ref {Entity.Name} dto, {Entity.PrimaryKeysWithRefTypes()}");
                    if (Entity.HasDataset)
                    {
                        outputFile.Write(", ref IDbTransaction transaction");

                        if (Entity.HasOneToMany())
                        {
                            outputFile.Write(", ref bool shouldReturnRelatedRecords");
                        }
                    }
                    outputFile.Write($");{Environment.NewLine}");
                }

                outputFile.Write($"        partial void AfterGet(ref bool result, {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.Write(", ref bool shouldReturnRelatedRecords");
                    }
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        /// Get Method");
                outputFile.WriteLine("        /// </summary>");
                foreach (var p in Entity.PrimaryKeyList())
                {
                  outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                }

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");                    
                }

                if (Entity.HasOneToMany())
                {
                    outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\"></param>");
                }

                outputFile.WriteLine("");

                outputFile.Write($"        public async Task<{Entity.Name}> GetAsync({Entity.PrimaryKeysWithTypes()}");

                if (Entity.HasDataset)
                {
                    outputFile.Write(", IDbTransaction transaction = null");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.Write(", bool shouldReturnRelatedRecords = false");
                    }
                }

                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");

                foreach (Property property in Entity.Properties)
                {
                    if (property.PrimaryKey)
                    {   
                        if (property.EntityType() == "string")
                        {
                            outputFile.WriteLine($"            if (string.IsNullOrEmpty({property.Name.CamelCase()}))");
                        }
                        else if (property.EntityType() == "Guid")
                        {
                            outputFile.WriteLine($"            if ({property.Name.CamelCase()} == null || {property.Name.CamelCase()} == Guid.Empty)");
                        }
                        else
                        {
                            outputFile.WriteLine($"            if ({property.Name.CamelCase()} < 1)");
                        }
                        outputFile.WriteLine("            {");
                        outputFile.WriteLine($"                throw new ApiRestException(HttpStatusCode.NotAcceptable, \"Invalid Parameter ({property.Name.CamelCase()}).\");");
                        outputFile.WriteLine("            }");
                        outputFile.WriteLine("");
                    }
                }

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                bool preResult = true;");
                outputFile.WriteLine("");
                outputFile.WriteLine("                // BeforeGet is an optional method that is called BEFORE we actually do the DB Get");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write($"                BeforeGet(ref preResult, {Entity.PrimaryKeysRef()}");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.Write(", ref shouldReturnRelatedRecords");
                    }
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if (!preResult)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                QueryOptions options = new QueryOptions");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    Filter = {Entity.PrimaryKeysWhere()}");
                    outputFile.WriteLine("                };");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"                {Entity.Name} result = await ReadAsync(options, trans);");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("                if (result != null && shouldReturnRelatedRecords)");
                        outputFile.WriteLine("                {");                        
                                                
                        foreach (Relationship rel in Entity.Relationships)
                        {
                            Entity RelatedEntity = EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity);
                            if (RelatedEntity.Visibility == "internal" || rel.Cardinality == "OneToOne")
                            {
                                continue;
                            }
                        
                            Property RelatedProperty = Entity.Properties.FirstOrDefault(e => e.Name == rel.PropertyName);
                            Property RelatedEntityProperty = RelatedEntity.Properties.FirstOrDefault(e => e.Name == rel.RelatedProperty);
                            outputFile.WriteLine("");
                            outputFile.WriteLine($"                    var {rel.Name.CamelCase()} = await {rel.RelatedEntity}Service.GetManyAsync(");
                            outputFile.WriteLine("                        new QueryOptions");
                            outputFile.WriteLine("                        {");
                            outputFile.WriteLine($"                           Filter = \" { RelatedEntityProperty?.DbName} eq \" + result.{rel.PropertyName}" + (RelatedProperty?.Type.GetEntityType() == "string" ? ".SqlQuoteString()" : ""));
                            outputFile.WriteLine("                        }, trans);");

                            outputFile.WriteLine("");
                        }
                        
                        foreach (Relationship rel in Entity.Relationships)
                        {
                            if (EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                            {
                                continue;
                            }

                            if (rel.Cardinality == "ManyToOne")
                            {
                                outputFile.WriteLine($"                    result.{rel.Name} = {rel.Name.CamelCase()}?.Items?.First();");
                            }
                            else
                            {
                                outputFile.WriteLine($"                    result.{rel.PluralName} = {rel.Name.CamelCase()}?.Items?.ToList();");
                            }                            
                        }


                        outputFile.WriteLine("                }");
                    }
                }
                else
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"                {Entity.Name} result = null;");
                    outputFile.WriteLine($"                GetOverride(ref result, {Entity.PrimaryKeysRef()});");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("                bool postGet = true;");
                outputFile.WriteLine("                // AfterGet is an optional method that is called AFTER we actually do the DB Get");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                AfterGet(ref postGet, result");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans");

                    if (Entity.HasOneToMany())
                    {
                        outputFile.Write(", ref shouldReturnRelatedRecords");
                    }
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if (!postGet || result == null)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return result;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                    outputFile.WriteLine("                Log.LogError($\"Could not GetAsync for " + Entity.Name + " - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
                }
                outputFile.WriteLine("                throw;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");
            }
        }

        private void CreateGetMany(StreamWriter outputFile)
        {
            outputFile.WriteLine("");
            outputFile.Write("        partial void BeforeGetMany(ref bool result, ref QueryOptions options");

            if (Entity.HasDataset)
            {
                outputFile.Write(", ref IDbTransaction transaction");
            }
            outputFile.Write($");{Environment.NewLine}");

            if (!Entity.HasDataset)
            {
                outputFile.Write("        partial void GetManyOverride(ref bool result, ref QueryOptions options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");
                }
                outputFile.Write($");{Environment.NewLine}");
            }

            outputFile.Write($"        partial void AfterGetMany(ref bool result, ref QueryResults<{Entity.Name}> values");
            if (Entity.HasDataset)
            {
                outputFile.Write(", ref IDbTransaction transaction");
            }
            outputFile.Write($");{Environment.NewLine}");
            outputFile.WriteLine("");
            outputFile.WriteLine("        /// <summary>");
            outputFile.WriteLine("        /// GetMany Method");
            outputFile.WriteLine("        /// </summary>");
            outputFile.WriteLine("        /// <param name=\"options\"></param>");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
            }
            outputFile.WriteLine("");

            outputFile.Write($"        public async Task<QueryResults<{Entity.Name}>> GetManyAsync(QueryOptions options");

            if (Entity.HasDataset)
            {
                outputFile.Write(", IDbTransaction transaction = null");
            }
            outputFile.Write($"){Environment.NewLine}");

            outputFile.WriteLine("        {");
            if (Entity.HasDataset)
            {             
                outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                outputFile.WriteLine("");
            }

            outputFile.WriteLine("            try");
            outputFile.WriteLine("            {");
            outputFile.WriteLine("                bool overrideResults = true;");
            outputFile.WriteLine("");
            outputFile.WriteLine("                // BeforeGetMany is an optional method that is called BEFORE we actually do the DB GetMany");
            outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
            outputFile.Write("                BeforeGetMany(ref overrideResults, ref options");

            if (Entity.HasDataset)
            {
                outputFile.Write(", ref trans");
            }

            outputFile.Write($");{Environment.NewLine}");
            outputFile.WriteLine("");
            outputFile.WriteLine("                if (!overrideResults)");
            outputFile.WriteLine("                {");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
            }
            outputFile.WriteLine("                    return null;");
            outputFile.WriteLine("                }");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("");
                outputFile.WriteLine($"                QueryResults<{Entity.Name}> result = await ReadManyAsync(options, trans);");
            }
            else
            {
                outputFile.WriteLine("");
                outputFile.WriteLine($"                QueryResults<{Entity.Name}> result = null;");
                outputFile.WriteLine("                GetManyOverride(ref overrideResults, ref options);");
            }

            outputFile.WriteLine("");
            outputFile.WriteLine("                // AfterGetMany is an optional method that is called AFTER we actually do the DB Get");
            outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
            outputFile.Write("                AfterGetMany(ref overrideResults, ref result");
            if (Entity.HasDataset)
            {
                outputFile.Write(", ref trans");
            }
            outputFile.Write($");{Environment.NewLine}");
            outputFile.WriteLine("");
            outputFile.WriteLine("                if (!overrideResults || result?.Items == null || !result.Items.Any())");
            outputFile.WriteLine("                {");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
            }
            outputFile.WriteLine("                    return null;");
            outputFile.WriteLine("                }");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("");
                outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
            }
            outputFile.WriteLine("");
            outputFile.WriteLine("                return result;");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("            catch(Exception e)");
            outputFile.WriteLine("            {");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                outputFile.WriteLine("                Log.LogError($\"Could not GetManyAsync for " + Entity.Name + " - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
            }
            outputFile.WriteLine("                throw;");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("        }");
            outputFile.WriteLine("        #endregion QueryService");
        }

        private void CreateGetOneToOne(StreamWriter outputFile)
        {
            IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");

            if (!relationships.Any())
            {
                return;
            }

            foreach (var r in relationships)
            {
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine($"        /// Get Method for Relationship {r.RelatedEntity}");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine($"        /// <param name=\"{r.PropertyName.CamelCase()}\"></param>");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                }

                outputFile.Write($"        public async Task<List<{Entity.Name}>> GetBy{r.PropertyName}Async({r.RelationshipWithType(Entity)}");

                if (Entity.HasDataset)
                {
                    outputFile.Write(", IDbTransaction transaction = null");
                }

                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");

                if (r.Type.GetEntityType() == "string")
                {
                    outputFile.WriteLine($"            if (string.IsNullOrEmpty({r.PropertyName.CamelCase()}))");
                }
                else if (r.Type.GetEntityType() == "Guid")
                {
                    outputFile.WriteLine($"            if ({r.Name.CamelCase()} == null || {r.Name.CamelCase()} == Guid.Empty)");
                }
                else
                {
                    outputFile.WriteLine($"            if ({r.PropertyName.CamelCase()} < 1)");
                }
                outputFile.WriteLine("            {");
                outputFile.WriteLine($"                throw new ApiRestException(HttpStatusCode.NotAcceptable, \"Invalid Parameter ({r.PropertyName.CamelCase()}).\");");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                QueryOptions options = new QueryOptions");
                outputFile.WriteLine("                {");
                outputFile.WriteLine($"                    Filter = {r.RelationshipKeysWhere(Entity)}");
                outputFile.WriteLine("                };");
                outputFile.WriteLine("");
                outputFile.WriteLine("                var result = await ReadManyAsync(options, trans);");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if (result?.Items == null || !result.Items.Any())");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return result?.Items;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");                    
                    outputFile.WriteLine("                Log.LogError($\"Could not GetBy" + r.PropertyName + "Async - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
                }
                outputFile.WriteLine("                throw;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");
            }
        }

        private void CreateGetUnique(StreamWriter outputFile)
        {
            if (!Entity.UniqueKeys.Any())
            {
                return;
            }

            foreach (var key in Entity.UniqueKeys)
            {
                List<string> props = key.Properties.Split(",").ToList();
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine($"        /// Get Method for {key.Name}");
                outputFile.WriteLine("        /// </summary>");
                foreach (var p in props)
                {
                    outputFile.WriteLine($"        /// <param name=\"{p.CamelCase()}\"></param>");
                }

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");                    
                }

                if (Entity.HasOneToMany())
                {
                    outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\"></param>");
                }

                outputFile.Write($"        public async Task<{Entity.Name}> GetBy{props.UniqueName()}Async({props.UniqueKeysWithTypes(Entity)}");

                if (Entity.HasDataset)
                {
                    outputFile.Write(", IDbTransaction transaction = null");                    
                }

                if (Entity.HasOneToMany())
                {
                    outputFile.Write(", bool shouldReturnRelatedRecords = false");
                }

                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");

                foreach (string s in props)
                {
                    Property p = Entity.Properties.First(e => e.Name == s);
                    if (p != null)
                    {
                        if (p.EntityType() == "string")
                        {
                            outputFile.WriteLine($"            if (string.IsNullOrEmpty({p.Name.CamelCase()}))");                            
                        }
                        else if (p.EntityType() == "Guid")
                        {
                            outputFile.WriteLine($"            if ({p.Name.CamelCase()} == null || {p.Name.CamelCase()} == Guid.Empty)");
                        }
                        else
                        {
                            outputFile.WriteLine($"            if ({p.Name.CamelCase()} < 1)");
                        }
                        outputFile.WriteLine("            {");
                        outputFile.WriteLine($"                throw new ApiRestException(HttpStatusCode.NotAcceptable, \"Invalid Parameter ({p.Name.CamelCase()}).\");");
                        outputFile.WriteLine("            }");
                        outputFile.WriteLine("");
                    }
                }

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                QueryOptions options = new QueryOptions");
                outputFile.WriteLine("                {");
                outputFile.WriteLine($"                    Filter = {props.UniqueKeysWhere(Entity)}");
                outputFile.WriteLine("                };");
                outputFile.WriteLine("");
                outputFile.WriteLine("                var result = await ReadAsync(options, trans);");
                outputFile.WriteLine("");
                                             
                if (Entity.HasOneToMany())
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (result != null && shouldReturnRelatedRecords)");
                    outputFile.WriteLine("                {");                    

                    foreach (Relationship rel in Entity.Relationships)
                    {
                        Entity RelatedEntity = EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity);
                        if (RelatedEntity.Visibility == "internal" || rel.Cardinality == "OneToOne")
                        {
                            continue;
                        }
                        Property RelatedProperty = Entity.Properties.FirstOrDefault(e => e.Name == rel.PropertyName);
                        Property RelatedEntityProperty = RelatedEntity.Properties.FirstOrDefault(e => e.Name == rel.RelatedProperty);
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"                    var {rel.Name.CamelCase()} = await {rel.RelatedEntity}Service.GetManyAsync(");
                        outputFile.WriteLine("                        new QueryOptions");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine($"                            Filter = \" { RelatedEntityProperty?.DbName} eq \" + result.{rel.PropertyName}" + (RelatedProperty?.Type.GetEntityType() == "string" ? ".SqlQuoteString()" : ""));
                        outputFile.WriteLine("                        }, trans);");

                        outputFile.WriteLine("");
                    }
                    
                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                        {
                            continue;
                        }

                        if (rel.Cardinality == "ManyToOne")
                        {
                            outputFile.WriteLine($"                    result.{rel.Name} = {rel.Name.CamelCase()}?.Items?.First();");
                        }
                        else
                        {
                            outputFile.WriteLine($"                    result.{rel.PluralName} = {rel.Name.CamelCase()}?.Items?.ToList();");
                        }
                    }


                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("                if (result == null)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return result;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                    outputFile.WriteLine("                Log.LogError($\"Could not GetBy" + props.UniqueName() + "Async - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
                }
                outputFile.WriteLine("                throw;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");
            }
        }
    }
}