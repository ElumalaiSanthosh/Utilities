﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ClientQueryWriter : WriterBase, IWriter
    {
        internal ClientQueryWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{EntityMap.Namespace}.{Entity.Name}QueryClient.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Clients;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Entities;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Logger;");
                outputFile.WriteLine("using Microsoft.Extensions.Logging;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using ApiService.Commons.CacheService;");                
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Clients");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.Write($"    public partial class {EntityMap.Namespace}Client : ");
                outputFile.Write($"I{EntityMap.Namespace}Client{Environment.NewLine}");
                outputFile.WriteLine("    {");

                if (firstPass)
                {                    
                    outputFile.WriteLine("        /// <summary>");
                    outputFile.WriteLine("        /// Base portion of Caching Key.");
                    outputFile.WriteLine("        /// </summary>");
                    outputFile.WriteLine($"        protected string BaseCacheKey = \"{EntityMap.Namespace}.v{EntityMap.Version}\";");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        private IApiCache Cache " + "{ get; }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        IServiceClientBase<{EntityMap.Namespace}Client> ServiceClient " + "{ get; }");
                    outputFile.WriteLine("");                    
                    outputFile.WriteLine("        protected ILogger Log { get; }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        public {EntityMap.Namespace}Client(IConfiguration config, ITokenManager tokenManager, IApiCache cache)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            Cache = cache;");
                    outputFile.WriteLine($"            Log = ApiLogging.CreateLogger<{EntityMap.Namespace}Client>();");
                    outputFile.WriteLine($"            ServiceClient = new ServiceClientBase<{EntityMap.Namespace}Client>(Log, config, tokenManager, cache, ServiceTypeEnum.SmartAccountingApiKey, {EntityMap.Version}, \"{EntityMap.Namespace.ToLower()}\", \"{EntityMap.Scope}\");");
                    outputFile.WriteLine("        }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        public {EntityMap.Namespace}Client(IServiceClientBase<{EntityMap.Namespace}Client> clientBase)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            ServiceClient = clientBase;");
                    outputFile.WriteLine("        }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        public async Task<RequestResponse<T>> GetRequestResponseAsync<T>(string resource, ApiRestVerbs method = ApiRestVerbs.Get, HttpStatusCode successStatus = HttpStatusCode.OK, List<object> bodyObjects = null, IList<string> urlSegments = null, IDictionary<string, string> queryParams = null, IDictionary<string, string> headers = null, int timeout = 0)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            return await ServiceClient.GetRequestResponseAsync<T>(resource, method, successStatus, bodyObjects, urlSegments, queryParams, headers, timeout);");
                    outputFile.WriteLine("        }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        public async Task<RequestResponse<PageResults<T>>> GetOdataPagedRequestResponseAsync<T>(string resource, IList<string> urlSegments = null, QueryOptions options = null, IEnumerable<string> columns = null, IDictionary<string, string> queryParams = null, IDictionary<string, string> headers = null, int timeout = 0)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            return await ServiceClient.GetOdataPagedRequestResponseAsync<T>(resource, urlSegments, options, columns, queryParams, headers, timeout);");
                    outputFile.WriteLine("        }");
                    outputFile.WriteLine("");
                }
                
                outputFile.WriteLine("        #region Query");

                if (Entity.HasCommand("get"))
                {
                    if (Entity.HasPrimaryKey())
                    {
                        outputFile.Write($"        public async Task<RequestResponse<{Entity.Name}>> Get{Entity.Name}Async({Entity.PrimaryKeysWithTypes()}");

                        if (Entity.HasDataset && Entity.HasOneToMany())
                        {
                            outputFile.Write(", bool shouldReturnRelatedRecords = false");
                        }

                        outputFile.Write($", int timeout = 0){Environment.NewLine}");
                        outputFile.WriteLine("        {");

                        foreach (Property property in Entity.Properties)
                        {
                            if (property.PrimaryKey)
                            {
                                if (property.EntityType() == "string")
                                {
                                    outputFile.WriteLine($"            if (string.IsNullOrEmpty({property.Name.CamelCase()}))");
                                }
                                else if (property.EntityType() == "Guid")
                                {
                                    outputFile.WriteLine($"            if ({property.Name.CamelCase()} == null || {property.Name.CamelCase()} == Guid.Empty)");
                                }
                                else
                                {
                                    outputFile.WriteLine($"            if ({property.Name.CamelCase()} < 1)");
                                }
                                outputFile.WriteLine("            {");
                                outputFile.WriteLine($"                throw new ArgumentException(\"Invalid Parameter ({property.Name.CamelCase()}).\");");
                                outputFile.WriteLine("            }");
                                outputFile.WriteLine("");
                            }
                        }

                        if (Entity.EnableCache)
                        {
                            outputFile.Write("            string key = $\"" + "{BaseCacheKey}" + $".{Entity.PluralName.ToLower()}.{Entity.PrimaryKeysForCache()}");
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write(".shouldReturnRelatedRecords={shouldReturnRelatedRecords}");
                            }
                            outputFile.Write($"\";{Environment.NewLine}");

                            outputFile.WriteLine($"            var cacheValue = ServiceClient.CheckCache<{Entity.Name}>(key);");
                            outputFile.WriteLine("");
                            outputFile.WriteLine("            if (cacheValue != null) return cacheValue;");
                            outputFile.WriteLine("");
                        }

                        if (Entity.HasDataset && Entity.HasOneToMany())
                        {
                            outputFile.WriteLine("            IDictionary<string, string> queryParams = new Dictionary<string, string>{{\"shouldReturnRelatedRecords\", shouldReturnRelatedRecords.ToString()}};");
                            outputFile.WriteLine("");
                        }

                        outputFile.Write($"            return await ServiceClient.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", successStatus: HttpStatusCode.OK, urlSegments: new List<string> " + "{ " + Entity.PrimaryKeys() + " }");

                        if (Entity.HasDataset && Entity.HasOneToMany())
                        {
                            outputFile.Write($", queryParams: queryParams");
                        }

                        outputFile.Write($", timeout: timeout);{Environment.NewLine}");

                        outputFile.WriteLine("        }");

                        outputFile.WriteLine("");
                    }

                    outputFile.WriteLine($"        public async Task<RequestResponse<PageResults<{Entity.Name}>>> GetMany{Entity.PluralName}Async(IList<string> urlSegments = null, QueryOptions options = null, IList<string> columns = null, int timeout = 0)");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine($"            return await ServiceClient.GetOdataPagedRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", urlSegments: urlSegments, options: options, columns: columns, timeout:timeout);");
                    outputFile.WriteLine("        }");

                    IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");
                    if (relationships.Any())
                    {
                        foreach (var r in relationships)
                        {
                            outputFile.WriteLine("");
                            outputFile.WriteLine("        /// <summary>");
                            outputFile.WriteLine($"        /// Get Method for Relationship {r.RelatedEntity}");
                            outputFile.WriteLine("        /// </summary>");
                            outputFile.WriteLine($"        /// <param name=\"{r.PropertyName.CamelCase()}\"></param>");
                            outputFile.WriteLine("        /// <param name=\"columns\"></param>");
                            outputFile.WriteLine("        /// <param name=\"timeout\"></param>");
                            outputFile.WriteLine($"        public async Task<RequestResponse<List<{Entity.Name}>>> GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipWithType(Entity)}, int timeout = 0)");
                            outputFile.WriteLine("        {");

                            if (r.Type.GetEntityType() == "string")
                            {
                                outputFile.WriteLine($"            if (string.IsNullOrEmpty({r.PropertyName.CamelCase()}))");
                            }
                            else if (r.Type.GetEntityType() == "Guid")
                            {
                                outputFile.WriteLine($"            if ({r.Name.CamelCase()} == null || {r.Name.CamelCase()} == Guid.Empty)");
                            }
                            else
                            {
                                outputFile.WriteLine($"            if ({r.PropertyName.CamelCase()} < 1)");
                            }
                            outputFile.WriteLine("            {");
                            outputFile.WriteLine($"                throw new ArgumentException(\"Invalid Parameter ({r.PropertyName.CamelCase()}).\");");
                            outputFile.WriteLine("            }");
                            outputFile.WriteLine("");
                            outputFile.WriteLine($"            return await ServiceClient.GetRequestResponseAsync<List<{Entity.Name}>>(\"{Entity.PluralName.ToLower()}\", successStatus: HttpStatusCode.OK, urlSegments: new List<string>" + "{ \"" + r.Name.ToLower() + $"\", {(r.Type == "string" ? r.PropertyName.CamelCase() : r.PropertyName.CamelCase() + ".ToString()")}" + " }, timeout:timeout);");
                            outputFile.WriteLine("        }");
                        }
                    }

                    if (Entity.UniqueKeys.Any())
                    {
                        foreach (var key in Entity.UniqueKeys)
                        {
                            List<string> props = key.Properties.Split(",").ToList();
                            outputFile.WriteLine("");
                            outputFile.WriteLine("        /// <summary>");
                            outputFile.WriteLine($"        /// Get Method for {key.Name}");
                            outputFile.WriteLine("        /// </summary>");
                            foreach (var p in props)
                            {
                                outputFile.WriteLine($"        /// <param name=\"{p.CamelCase()}\"></param>");
                            }
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\"></param>");
                            }
                            outputFile.WriteLine("        /// <param name=\"timeout\"></param>");
                            outputFile.Write($"        public async Task<RequestResponse<{Entity.Name}>> Get{Entity.Name}By{props.UniqueName()}Async({props.UniqueKeysWithTypes(Entity)}");
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write(", bool shouldReturnRelatedRecords = false");
                            }

                            outputFile.Write($", int timeout = 0){Environment.NewLine}");
                            outputFile.WriteLine("        {");

                            foreach (string s in props)
                            {
                                Property p = Entity.Properties.First(e => e.Name == s);
                                if (p != null)
                                {
                                    if (p.EntityType() == "string")
                                    {
                                        outputFile.WriteLine($"            if (string.IsNullOrEmpty({p.Name.CamelCase()}))");
                                    }
                                    else if (p.EntityType() == "Guid")
                                    {
                                        outputFile.WriteLine($"            if ({p.Name.CamelCase()} == null || {p.Name.CamelCase()} == Guid.Empty)");
                                    }
                                    else
                                    {
                                        outputFile.WriteLine($"            if ({p.Name.CamelCase()} < 1)");
                                    }
                                    outputFile.WriteLine("            {");
                                    outputFile.WriteLine($"                throw new ArgumentException(\"Invalid Parameter ({p.Name.CamelCase()}).\");");
                                    outputFile.WriteLine("            }");
                                    outputFile.WriteLine("");
                                }
                            }

                            if (Entity.EnableCache)
                            {
                                outputFile.Write("            string key = $\"" + "{BaseCacheKey}" + $".{Entity.PluralName.ToLower()}.{props.UniqueKeyCache(Entity)}");
                                if (Entity.HasDataset && Entity.HasOneToMany())
                                {
                                    outputFile.Write(".shouldReturnRelatedRecords={shouldReturnRelatedRecords}");
                                }
                                outputFile.Write($"\";{Environment.NewLine}");
                                outputFile.WriteLine("");

                                outputFile.WriteLine($"            var cacheValue = ServiceClient.CheckCache<{Entity.Name}>(key);");
                                outputFile.WriteLine("");
                                outputFile.WriteLine("            if (cacheValue != null) return cacheValue;");
                                outputFile.WriteLine("");
                            }

                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.WriteLine("            IDictionary<string, string> queryParams = new Dictionary<string, string>{{\"shouldReturnRelatedRecords\", shouldReturnRelatedRecords.ToString()}};");
                                outputFile.WriteLine("");
                            }

                            outputFile.Write($"            return await ServiceClient.GetRequestResponseAsync<{Entity.Name}>(\"{Entity.PluralName.ToLower()}\", successStatus: HttpStatusCode.OK, urlSegments: new List<string> " + "{ " + props.UniqueKeysForQuery(Entity) + " }");

                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write($", queryParams: queryParams");
                            }

                            outputFile.Write($", timeout: timeout);{Environment.NewLine}");
                            outputFile.WriteLine("        }");
                        }
                    }                    
                }
                outputFile.WriteLine("        #endregion Query");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
