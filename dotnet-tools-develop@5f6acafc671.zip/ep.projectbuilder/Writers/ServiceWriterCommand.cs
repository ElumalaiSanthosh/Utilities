﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ServiceWriterCommand : WriterBase, IWriter
    {
        internal ServiceWriterCommand(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}CommandService.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Services;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility.ToLower() == "view" || 
                Entity.Visibility.ToLower() == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Data;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using ApiService.Commons.Helpers;");
                outputFile.WriteLine("using ApiService.Commons.Extensions;");
                outputFile.WriteLine("using ApiService.Commons.Exceptions;");
                outputFile.WriteLine("using ApiService.Repositories;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using Microsoft.Extensions.Configuration;");
                outputFile.WriteLine("using Microsoft.Extensions.Logging;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Services");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// ");
                outputFile.WriteLine("    /// </summary>");
                outputFile.Write($"    public partial class {Entity.Name}Service : ");
                if (Entity.HasDataset)
                {
                    outputFile.Write($"Service<{Entity.Name}>, ");
                }
                outputFile.Write($"I{Entity.Name}Service{Environment.NewLine}");

                outputFile.WriteLine("    {");

                CreatePost(outputFile);
                CreatePut(outputFile);
                CreateDelete(outputFile);

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private void CreatePost(StreamWriter outputFile)
        {
            if (Entity.Visibility != "view" &&
                Entity.Visibility != "custom")
            {
                outputFile.WriteLine("        #region CommandService");
                outputFile.Write($"        partial void BeforePost(ref bool result, ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool createRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write($"        partial void PostOverride(ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool createRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write($"        partial void AfterPost(ref bool result, ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool createRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        /// Post Method");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine("        /// <param name=\"dto\"></param>");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                    outputFile.WriteLine("        /// <param name=\"createRelatedRecords\"></param>");
                }

                outputFile.Write($"        public async Task<{Entity.Name}> PostAsync({Entity.Name} dto");

                if (Entity.HasDataset)
                {
                    outputFile.Write(", IDbTransaction transaction = null, bool createRelatedRecords = true");
                }
                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");
                outputFile.WriteLine("            if(dto == null)");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                throw new ApiRestException(HttpStatusCode.BadRequest,\"The Dto is null.\");");
                outputFile.WriteLine("            }");                
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }
                
                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");

                outputFile.WriteLine("                bool result = true;");
                outputFile.WriteLine("");
                outputFile.WriteLine("                // BeforePost is an optional method that is called BEFORE we actually do the DB Create");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                BeforePost(ref result, ref dto");                
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans, ref createRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                List<string> results;");
                outputFile.WriteLine("                if (!dto.IsValid(out results))");
                outputFile.WriteLine("                {");
                outputFile.WriteLine("                    throw new ApiRestException(HttpStatusCode.NotAcceptable,  string.Join(\", \", results));");
                outputFile.WriteLine("                }");

                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");
                outputFile.WriteLine("");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine($"                if (ReflectionHelper<{Entity.Name}Service>.GetMethod(\"PostOverride\", true) == null)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine($"                    {Entity.Name} {Entity.Name.CamelCase()} = await CreateAsync(dto, trans);");
                    if (Entity.Relationships.Any(e => (e.Cardinality == "OneToMany")))
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("                    if (createRelatedRecords)");
                        outputFile.WriteLine("                    {");

                        IList<string> relationsWaitFor = new List<string>();
                        foreach (Relationship rel in Entity.Relationships)
                        {
                            if (EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity).Visibility != "public" ||
                                rel.Cardinality == "OneToOne")
                            {
                                continue;
                            }

                            relationsWaitFor.Add(rel.Name.CamelCase());
                            outputFile.WriteLine($"                        if (dto.{rel.PluralName} != null && dto.{rel.PluralName}.Count() > 0)");
                            outputFile.WriteLine("                        {");
                            outputFile.WriteLine($"                            dto.{rel.PluralName}.ToList().ForEach(c => c.{rel.RelatedProperty} = {Entity.Name.CamelCase()}.{rel.PropertyName});");
                            outputFile.WriteLine($"                            {Entity.Name.CamelCase()}.{rel.PluralName} = (await {rel.RelatedEntity}Service.PostAsync(dto.{rel.PluralName}, trans)).ToList();");
                            outputFile.WriteLine("                        }");
                        }
                        outputFile.WriteLine("                    }");
                        outputFile.WriteLine("");                        
                    }

                    outputFile.WriteLine($"                    dto = {Entity.Name.CamelCase()};");

                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("                else");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine("                    PostOverride(ref dto, ref trans, ref createRelatedRecords);");
                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (dto == null)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine("                    throw new ApiServiceException(100, \"Record Not Inserted properly\");");
                    outputFile.WriteLine("                }");
                }
                else
                {
                    outputFile.WriteLine("                PostOverride(ref dto);");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("                 // AfterPost is an optional method that is called AFTER we actually do the DB Create");
                outputFile.WriteLine("                 // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                AfterPost(ref result, ref dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans, ref createRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return dto;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                    outputFile.WriteLine("                Log.LogError($\"Could not post " + Entity.Name + " - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
                    outputFile.WriteLine("                Log.LogInformation($\"{JsonHelper.WriteJson(dto)}\");");
                }
                outputFile.WriteLine("                throw;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");

                CreatePostUpdateMany(outputFile, "Post");
            }
        }

        private void CreatePut(StreamWriter outputFile)
        {
            if (Entity.Visibility != "view" &&
                Entity.Visibility != "custom")
            {
                outputFile.WriteLine("");
                outputFile.Write($"        partial void BeforePut(ref bool result, ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool updateRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write($"        partial void PutOverride(ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool updateRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write($"        partial void AfterPut(ref bool result, ref {Entity.Name} dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction, ref bool updateRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        /// Put Method");
                outputFile.WriteLine("        /// </summary>");
                foreach (var p in Entity.PrimaryKeyList())
                {
                    outputFile.WriteLine($"        /// <param name=\"{p.Name.CamelCase()}\"></param>");
                }
                outputFile.WriteLine("        /// <param name=\"dto\"></param>");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                    outputFile.WriteLine("        /// <param name=\"updateRelatedRecords\"></param>");
                }

                outputFile.Write($"        public async Task<{Entity.Name}> PutAsync({Entity.PrimaryKeysWithTypes()}, {Entity.Name} dto");

                if (Entity.HasDataset)
                {
                    outputFile.Write(",IDbTransaction transaction = null, bool updateRelatedRecords = true");
                }
                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");
                outputFile.WriteLine("            if (dto == null)");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                throw new ApiRestException(HttpStatusCode.BadRequest, \"The Dto is null.\");");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("");
                outputFile.WriteLine($"            if ({Entity.PrimaryKeysValidation("dto")})");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                throw new ApiRestException(");
                outputFile.WriteLine("                HttpStatusCode.NotAcceptable,");
                outputFile.WriteLine("                \"Id does not match the Dto Id.\");");
                outputFile.WriteLine("            }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");

                outputFile.WriteLine("                bool result = true;");
                outputFile.WriteLine("");
                outputFile.WriteLine("                // BeforePut is an optional method that is called BEFORE we actually do the DB Create");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                BeforePut(ref result, ref dto");                
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans, ref updateRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.WriteLine("");
                outputFile.WriteLine("                List<string> results;");
                outputFile.WriteLine("                if (!dto.IsValid(out results))");
                outputFile.WriteLine("                {");
                outputFile.WriteLine("                    throw new ApiRestException(HttpStatusCode.NotAcceptable,  string.Join(\", \", results));");
                outputFile.WriteLine("                }");


                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");
                outputFile.WriteLine("");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine($"                if (ReflectionHelper<{Entity.Name}Service>.GetMethod(\"PutOverride\", true) == null)");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine("                    dto = await UpdateAsync(dto, trans);");

                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("                else");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine("                    PutOverride(ref dto, ref trans, ref updateRelatedRecords);");
                    outputFile.WriteLine("                }");
                }
                else
                {
                    outputFile.WriteLine("             PutOverride(ref dto);");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("                if (dto == null)");
                outputFile.WriteLine("                {");
                outputFile.WriteLine("                    throw new ApiServiceException(100, \"Record Not Updated properly\");");
                outputFile.WriteLine("                }");

                if (Entity.Relationships.Any(e => e.Cardinality == "OneToMany"))
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                if (updateRelatedRecords)");
                    outputFile.WriteLine("                {");

                    //todo if
                    IEnumerable<Entity> relatedElements = EntityMap.Entities.Where(
                        e =>
                            Entity.Relationships.Where(o => o.Cardinality == "OneToMany")
                                .Select(s => s.RelatedEntity)
                                .Contains(e.Name));

                    IList<string> relationsWaitFor = new List<string>();
                    foreach (Entity t in relatedElements)
                    {
                        if (t.Visibility != "public")
                        {
                            continue;
                        }

                        var parentRelationship = Entity.Relationships.First(e => e.RelatedEntity == t.Name);
                        var name = t.Properties.First(e => e.PrimaryKey).Name;
                        var dbName = t.Properties.First(e => e.PrimaryKey).DbName;
                        var type = t.Properties.First(e => e.PrimaryKey).EntityType();
                        string propertyName = parentRelationship.PropertyName;
                        bool isPropertyString = Entity.Properties.First(e => e.Name == propertyName).EntityType() == "string";

                        relationsWaitFor.Add(t.PluralName.CamelCase());
                        outputFile.WriteLine($"                    if (dto.{parentRelationship.PluralName} != null)");
                        outputFile.WriteLine("                    {");
                        
                        outputFile.Write($"                        String filter = $\"{Entity.Properties.FirstOrDefault(e => e.Name == Entity.Relationships.First(r => r.RelatedEntity == t.Name).RelatedProperty)?.DbName} = " + "{" + $"dto.{propertyName}");
                        if (isPropertyString)
                        {
                            outputFile.Write(".SqlQuoteString()");
                        }
                        outputFile.Write("}");
                        outputFile.Write($"\";{Environment.NewLine}");

                        outputFile.WriteLine("");
                        outputFile.Write($"                        ICollection<{type}> {t.Name.CamelCase()}Ids = dto.{parentRelationship.PluralName}.Where(e => ");
                        outputFile.Write(type == "string" ? $"!string.IsNullOrEmpty(e.{name}))" : $"e.{name} > 0)");
                        outputFile.Write($".Select(C => C.{name}).ToList();{Environment.NewLine}");


                        outputFile.WriteLine($"                        if ({t.Name.CamelCase()}Ids.Any())");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine($"                            filter += $\" and {dbName} NOT IN(" + "{string.Join(\", \", " + $"{t.Name.CamelCase()}Ids)" + "})\";");
                        outputFile.WriteLine("                        }");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"                        await {t.Name}Service.DeleteAsync(new QueryOptions()");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine("                            Filter = filter");
                        outputFile.WriteLine("                        }, trans);");
                        outputFile.WriteLine("");
                        outputFile.Write($"                        var dtos = dto.{parentRelationship.PluralName}.Where(e => ");
                        outputFile.Write(type.ToLower() == "string" ? $"!string.IsNullOrEmpty(e.{name}));{Environment.NewLine}" : $"e.{name} > 0);{Environment.NewLine}");
                        outputFile.WriteLine("                        if (dtos.Any())");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine($"                           await {t.Name}Service.PutAsync(dtos, trans);");
                        outputFile.WriteLine("                        }");
                        outputFile.WriteLine("");

                        outputFile.Write($"                        dtos = dto.{parentRelationship.PluralName}.Where(e => ");
                        outputFile.Write(type.ToLower() == "string" ? $"string.IsNullOrEmpty(e.{name}));{Environment.NewLine}" : $"e.{name} < 1);{Environment.NewLine}");
                        outputFile.WriteLine("                        if (dtos.Any())");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine($"                           await {t.Name}Service.PostAsync(dtos, trans);");
                        outputFile.WriteLine("                        }");
                        outputFile.WriteLine("                    }");
                        outputFile.WriteLine("");
                    }
                    outputFile.WriteLine("            }");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("                // AfterPut is an optional method that is called AFTER we actually do the DB Update");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                AfterPut(ref result, ref dto");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans, ref updateRelatedRecords");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return null;");
                outputFile.WriteLine("                }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return dto;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                    outputFile.WriteLine("                Log.LogError($\"Could not put " + Entity.Name + " - {e.Message}{Environment.NewLine}{e.StackTrace}\");");
                    outputFile.WriteLine("                Log.LogInformation($\"{JsonHelper.WriteJson(dto)}\");");
                }
                outputFile.WriteLine("                throw e;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");

                CreatePostUpdateMany(outputFile, "Put");
            }
        }

        private void CreatePostUpdateMany(StreamWriter outputFile, string command)
        {
            outputFile.WriteLine("");
            outputFile.WriteLine("");
            outputFile.WriteLine("        /// <summary>");
            outputFile.WriteLine("        /// ");
            outputFile.WriteLine("        /// </summary>");
            outputFile.WriteLine("        /// <param name=\"dtos\"></param>");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                if (command == "Post")
                {
                    outputFile.WriteLine("        /// <param name=\"createRelatedRecords\"></param>");
                }
                else
                {
                    outputFile.WriteLine("        /// <param name=\"updateRelatedRecords\"></param>");
                }
            }

            outputFile.Write($"        public async Task<IEnumerable<{Entity.Name}>> ");
            outputFile.Write($"{command}Async(IEnumerable<{Entity.Name}> dtos");

            if (Entity.HasDataset)
            {
                outputFile.Write(", IDbTransaction transaction = null, ");
                outputFile.Write(command == "Post" ? "bool createRelatedRecords = true" : "bool updateRelatedRecords = true");
            }
            outputFile.Write($"){Environment.NewLine}");
            outputFile.Write("        {");
            outputFile.WriteLine("");
            outputFile.WriteLine("            if(dtos == null || !dtos.Any())");
            outputFile.WriteLine("            {");
            outputFile.WriteLine("                throw new ApiRestException(HttpStatusCode.BadRequest, \"The Dto list is empty.\");");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
            }

            outputFile.WriteLine($"            IList<{Entity.Name}> results = new List<{Entity.Name}>();");
            outputFile.WriteLine($"            {Entity.Name} result;");
            outputFile.WriteLine("");
            outputFile.WriteLine("            try");
            outputFile.WriteLine("            {");
            outputFile.WriteLine($"                foreach({Entity.Name} dto in dtos)");
            outputFile.WriteLine("                 {");
            outputFile.Write($"                     result = await {command}Async(" + (command == "Post" ? string.Empty : Entity.PrimaryKeysFromDto() + ", ") + "dto");

            if (Entity.HasDataset)
            {
                outputFile.Write(", trans, ");
                outputFile.Write(command == "Post" ? "createRelatedRecords" : "updateRelatedRecords");
            }
            outputFile.Write($");{Environment.NewLine}");
            outputFile.WriteLine("                     if (result == null)");
            outputFile.WriteLine("                     {");
            outputFile.WriteLine("                         throw new ApiServiceException(100, \"Record Not Updated properly\");");
            outputFile.WriteLine("                     }");
            outputFile.WriteLine("                     results.Add(result);");
            outputFile.WriteLine("                 }");

            if (Entity.HasDataset)
            {
                outputFile.WriteLine("");
                outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
            }

            outputFile.WriteLine("");
            outputFile.WriteLine("                return results;");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("            catch(Exception e)");
            outputFile.WriteLine("            {");
            if (Entity.HasDataset)
            {
                outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
            }
            outputFile.WriteLine("                throw e;");
            outputFile.WriteLine("            }");
            outputFile.WriteLine("        }");
        }

        private void CreateDelete(StreamWriter outputFile)
        {
            if (Entity.Visibility != "view" &&
                Entity.Visibility != "custom")
            {
                outputFile.WriteLine("");
                outputFile.Write("        partial void BeforeDelete(ref bool result, ref QueryOptions options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write("        partial void DeleteOverride(ref bool result, ref QueryOptions options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");
                }
                outputFile.Write($");{Environment.NewLine}");

                outputFile.Write("        partial void AfterDelete(ref bool result, ref QueryOptions options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref IDbTransaction transaction");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        /// Delete Method");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine("        /// <param name=\"options\"></param>");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("        /// <param name=\"transaction\"></param>");
                }
                outputFile.Write("        public override async Task<bool> DeleteAsync(QueryOptions options");

                if (Entity.HasDataset)
                {
                    outputFile.Write(",IDbTransaction transaction = null");
                }
                outputFile.Write($"){Environment.NewLine}");

                outputFile.WriteLine("        {");
                outputFile.WriteLine("            if (string.IsNullOrEmpty(options?.Filter))");
                outputFile.WriteLine("            {");
                outputFile.WriteLine("                return false;");
                outputFile.WriteLine("            }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("            bool handleTransaction = transaction == null;");
                    outputFile.WriteLine("            IDbTransaction trans = transaction ?? BeginTransaction();");
                    outputFile.WriteLine("");
                }

                outputFile.WriteLine("            try");
                outputFile.WriteLine("            {");

                outputFile.WriteLine("                bool result = true;");
                outputFile.WriteLine("");
                outputFile.WriteLine("                // BeforeDelete is an optional method that is called BEFORE we actually do the DB Delete");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                BeforeDelete(ref result, ref options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return false;");
                outputFile.WriteLine("                }");
                outputFile.WriteLine("");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine($"                if (ReflectionHelper<{Entity.Name}Service>.GetMethod(\"DeleteOverride\", true) == null)");
                    outputFile.WriteLine("                {");
                    if (Entity.Relationships.Any(e => e.Cardinality == "OneToMany"))
                    {
                        outputFile.WriteLine(
                          "                    IEnumerable<string> deletedIds = await GetIdListForDelete(options, trans);");
                        outputFile.WriteLine("");
                        outputFile.WriteLine("                    if (deletedIds!= null && deletedIds.Any())");
                        outputFile.WriteLine("                    {");

                        List<string> delete = new List<string>();
                        foreach (Relationship rel in Entity.Relationships)
                        {
                            if (rel.Cardinality == "OneToMany")
                            {
                                outputFile.WriteLine(
                                  $"                        QueryOptions {rel.RelatedEntity.CamelCase()}Options = new QueryOptions");
                                outputFile.WriteLine("                        {");
                                Property p = Entity.Properties.First(e => e.Name == rel.PropertyName);
                                if (p.EntityType() == "string")
                                {
                                    outputFile.WriteLine(
                                      $"                           Filter = \"{p.DbName} IN (\" + String.Join(\", \", deletedIds.Select(x => String.Format(\"'{0}'\", x))) +\")\"");
                                }
                                else
                                {
                                    outputFile.WriteLine($"                           Filter = $\"{p.DbName} IN (" +
                                                         "{string.Join(\", \", deletedIds)})\"");
                                }

                                outputFile.WriteLine("                        };");
                                outputFile.WriteLine("");
                                outputFile.WriteLine(
                                  $"                        bool {rel.RelatedEntity.CamelCase()} = await {rel.RelatedEntity}Service.DeleteAsync(" +
                                  $"{rel.RelatedEntity.CamelCase()}Options, trans); ");
                                outputFile.WriteLine("");
                                delete.Add(rel.RelatedEntity.CamelCase());
                            }
                        }

                        if (delete.Any())
                        {                              
                            outputFile.WriteLine($"                        if(!{string.Join(" || !", delete)})");
                            outputFile.WriteLine("                        {");
                            outputFile.WriteLine("                            RollbackTransaction(handleTransaction, trans);");
                            outputFile.WriteLine("                            return false;");
                            outputFile.WriteLine("                        }");
                        }
                        outputFile.WriteLine("");
                        outputFile.WriteLine("                        if(!await base.DeleteAsync(options, trans))");
                        outputFile.WriteLine("                        {");
                        outputFile.WriteLine("                            RollbackTransaction(handleTransaction, trans);");
                        outputFile.WriteLine("                            return false;");
                        outputFile.WriteLine("                        }");
                        outputFile.WriteLine("                    }");
                    }
                    else
                    {
                        outputFile.WriteLine("                    if(!await base.DeleteAsync(options, trans))");
                        outputFile.WriteLine("                    {");
                        outputFile.WriteLine("                        RollbackTransaction(handleTransaction, trans);");
                        outputFile.WriteLine("                        return false;");
                        outputFile.WriteLine("                    }");
                    }
                   
                    outputFile.WriteLine("                }");
                    outputFile.WriteLine("                else");
                    outputFile.WriteLine("                {");
                    outputFile.WriteLine("                    DeleteOverride(ref result, ref options, ref trans);");
                    outputFile.WriteLine("                }");
                }
                else
                {
                    outputFile.WriteLine("                DeleteOverride(ref result, ref options);");
                }

                outputFile.WriteLine("");
                outputFile.WriteLine("                // AfterDelete is an optional method that is called AFTER we actually do the DB Delete");
                outputFile.WriteLine("                // If it fails (whatever that means in this context), it should throw the appropriate Exception to be passed up the stack");
                outputFile.Write("                AfterDelete(ref result, ref options");
                if (Entity.HasDataset)
                {
                    outputFile.Write(", ref trans");
                }
                outputFile.Write($");{Environment.NewLine}");
                outputFile.WriteLine("");
                outputFile.WriteLine("                if(!result)");
                outputFile.WriteLine("                {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                    RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                    return false;");
                outputFile.WriteLine("                }");

                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("                CommitTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("");
                outputFile.WriteLine("                return result;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("            catch(Exception e)");
                outputFile.WriteLine("            {");
                if (Entity.HasDataset)
                {
                    outputFile.WriteLine("                RollbackTransaction(handleTransaction, trans);");
                }
                outputFile.WriteLine("                throw e;");
                outputFile.WriteLine("            }");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("        #endregion CommandService");
            }
        }
    }
}