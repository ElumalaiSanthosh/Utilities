﻿using System.IO;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ControllerOdataExtensionWriter : WriterBase, IWriter
    {
        internal ControllerOdataExtensionWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return "OdataExtensions.generated.cs";
        }

        public override string GetProjectPath()
        {
            return !string.IsNullOrEmpty(SubDir) ? Path.Combine(SubDir, Path.Combine("Extensions", "Generated")) : Path.Combine("Extensions", "Generated");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;
        
        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {   
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using Microsoft.AspNet.OData.Builder;");
                outputFile.WriteLine("using Microsoft.AspNetCore.Builder;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using System.Diagnostics.CodeAnalysis;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Extensions");
                outputFile.WriteLine("{");
                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// Registers the Odata Entities");
                outputFile.WriteLine("    /// </summary>");
                outputFile.WriteLine("    public static partial class OdataExtensions");
                outputFile.WriteLine("    {");
                
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        ///");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine("        [ExcludeFromCodeCoverage]");
                outputFile.WriteLine("        public static ODataConventionModelBuilder RegisterOdataEntities(this IApplicationBuilder app)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("            var builder = GetEdmModel(app.ApplicationServices);");

                foreach (var entity in EntityMap.Entities)
                {
                    if (entity.Visibility == "dto" || entity.Visibility == "internal" || !entity.HasCommand("get"))
                    {
                        continue;
                    }

                    outputFile.WriteLine($"            builder.EntitySet<{entity.Name}>(nameof({entity.Name}));");
                }
                outputFile.WriteLine("            return builder;");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine("        [ExcludeFromCodeCoverage]");
                outputFile.WriteLine("        private static ODataConventionModelBuilder GetEdmModel(IServiceProvider serviceProvider)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("            var builder = new ODataConventionModelBuilder(serviceProvider);");
                outputFile.WriteLine("            return builder;");
                outputFile.WriteLine("        } ");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
