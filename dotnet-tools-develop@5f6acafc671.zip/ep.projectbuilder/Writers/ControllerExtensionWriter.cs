﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ControllerExtensionWriter : WriterBase, IWriter
    {
        internal ControllerExtensionWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return "ServiceExtensions.generated.cs";
        }

        public override string GetProjectPath()
        {
            return !string.IsNullOrEmpty(SubDir) ? Path.Combine(SubDir, Path.Combine("Extensions", "Generated")) : Path.Combine("Extensions", "Generated");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Controllers;
        
        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {   
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using ApiService.DataStore;");
                outputFile.WriteLine("using ApiService.Repositories;");
                outputFile.WriteLine("using ApiService.Services;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Web.Services;");
                outputFile.WriteLine("using Microsoft.Extensions.DependencyInjection;");
                outputFile.WriteLine("using System.Diagnostics.CodeAnalysis;");

                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Web.Extensions");
                outputFile.WriteLine("{");
                outputFile.WriteLine("    /// <summary>");
                outputFile.WriteLine("    /// Registers the generated services");
                outputFile.WriteLine("    /// </summary>");
                
                outputFile.WriteLine("    public static partial class ServiceExtensions");
                outputFile.WriteLine("    {");
                
                outputFile.WriteLine("        /// <summary>");
                outputFile.WriteLine("        ///");
                outputFile.WriteLine("        /// </summary>");
                outputFile.WriteLine("        [ExcludeFromCodeCoverage]");
                outputFile.WriteLine("        public static void RegisterGeneratedServices(this IServiceCollection services)");
                outputFile.WriteLine("        {");

                foreach (var entity in EntityMap.Entities)
                {
                    if (entity.Visibility == "dto")
                    {
                        continue;
                    }

                    outputFile.WriteLine($"            services.AddTransient<I{entity.Name}Service, {entity.Name}Service>();");
                }
                
                outputFile.WriteLine("        }");
                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
