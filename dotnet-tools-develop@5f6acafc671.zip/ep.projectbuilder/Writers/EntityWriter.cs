﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class EntityWriter : WriterBase, IWriter
    {
        internal EntityWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetSubPath()
        {
            return string.Empty;
        }

        public override string GetFileName()
        {
            return ($"{Entity.Name}Entity.generated.cs");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Entities;

        public void Create(ref bool firstPass)
        {
            List<Property> properties = Entity.Properties;

            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Linq;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using ApiService.Commons.Models.Entities;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Models.Entities");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine($"    public partial class {Entity.Name}Entity : EntityBase<{Entity.Name}>");
                outputFile.WriteLine("    {");
                outputFile.WriteLine($"        public {Entity.Name}Entity() : base()");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine($"        public {Entity.Name}Entity({Entity.Name} dataObject) : base(dataObject)");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine($"        public {Entity.Name}Entity({GetMethodParameterNamesFromProperties(EntityMap, Entity.Properties, Entity.Relationships)}) : base(new {Entity.Name}({GetMethodParameterNamesFromProperties(EntityMap, Entity.Properties, Entity.Relationships, true)}))");
                outputFile.WriteLine("        {");
                outputFile.WriteLine("        }");

                if (Entity.HasPrimaryKey())
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        public override int GetHashCode()");
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            // The HashCode is used in other cases besides equality comparisons,");
                    outputFile.WriteLine("            // so it makes sense for it to be stable even as other fields within");
                    outputFile.WriteLine("            // the object change.");
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"            return {Entity.CreateHashCodes()};");
                    outputFile.WriteLine("        }");
                }

                outputFile.WriteLine($"        public {Entity.Name} EntityDto => BaseDto as {Entity.Name};");

                foreach (Property property in properties)
                {
                    outputFile.WriteLine("");

                    if (property.AllowNull && !property.EntityType().Equals("string") &&
                        !property.EntityType().Equals("byte[]"))
                    {
                        outputFile.WriteLine($"        public {property.EntityType()}? {property.Name}");
                    }
                    else
                    {
                        outputFile.WriteLine($"        public {property.EntityType()} {property.Name}");
                    }
                    outputFile.WriteLine("        {");
                    outputFile.WriteLine("            get { return EntityDto." + property.Name + "; }");

                    if (Entity.Visibility == "public")
                    {
                        outputFile.WriteLine("");
                        outputFile.WriteLine("            set");
                        outputFile.WriteLine("            {");
                        outputFile.WriteLine($"                if (EntityDto.{property.Name} == value)");
                        outputFile.WriteLine("                    return;");
                        outputFile.WriteLine("");
                        outputFile.WriteLine($"                EntityDto.{property.Name} = value;");
                        outputFile.WriteLine("                IsDirty = true;");
                        outputFile.WriteLine("            }");
                    }
                    outputFile.WriteLine("        }");
                }

                if (Entity.Relationships != null && Entity.Relationships.Any())
                {
                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(e => e.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                        {
                            continue;
                        }
                        outputFile.WriteLine("");

                        if (rel.Cardinality == "OneToMany")
                        {
                            outputFile.WriteLine($"        public List<{rel.RelatedEntity}Entity> {rel.PluralName}");
                            outputFile.WriteLine("        {");
                            outputFile.WriteLine("            get { return EntityDto." + rel.PluralName +
                                                 "?.Select(i => new " + rel.RelatedEntity + "Entity(i)).ToList(); }");
                            if (Entity.Visibility == "public")
                            {
                                outputFile.WriteLine("");
                                outputFile.WriteLine("            set");
                                outputFile.WriteLine("            {");
                                outputFile.WriteLine(
                                    $"                EntityDto.{rel.PluralName} = value?.Select(i => i.EntityDto).ToList();");
                                outputFile.WriteLine("                IsDirty = true;");
                                outputFile.WriteLine("            }");
                            }
                            outputFile.WriteLine("        }");
                        }
                        else
                        {
                            outputFile.WriteLine($"        public {rel.RelatedEntity}Entity {rel.Name} ");
                            outputFile.WriteLine("        {");
                            outputFile.WriteLine("             get");
                            outputFile.WriteLine("             {");
                            outputFile.WriteLine($"               return new {rel.RelatedEntity}Entity(EntityDto.{rel.Name});");
                            outputFile.WriteLine("             }");

                            if (Entity.Visibility == "public")
                            {
                                outputFile.WriteLine("");
                                outputFile.WriteLine("         set");
                                outputFile.WriteLine("         {");
                                outputFile.WriteLine($"            EntityDto.{rel.Name} = value.EntityDto;");
                                outputFile.WriteLine("             IsDirty = true;");
                                outputFile.WriteLine("         }");
                            }
                            outputFile.WriteLine("        }");
                        }
                    }
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }
    }
}
