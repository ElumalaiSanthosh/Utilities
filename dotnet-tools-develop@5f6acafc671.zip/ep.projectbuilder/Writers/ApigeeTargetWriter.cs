﻿using System.IO;
using ProjectBuilder.Models;

namespace ProjectBuilder.Writers
{
    public class ApigeeTargetWriter : WriterBase
    {

        internal ApigeeTargetWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return ($"");
        }

        public override WriterTypes GetWriterType() => WriterTypes.Flow;

        public override string GetProjectPath()
        {
            return @"apiproxy\targets";
        }

        public override bool VerifyVisibility()
        {
            return true;
        }

        public void Create(ref bool firstPass)
        {
            bool exists = Directory.Exists(Path.Combine(EntityDir, "apiproxy", "targets"));

            if (!exists) Directory.CreateDirectory(Path.Combine(EntityDir, "apiproxy", "targets"));

            Develop();
        }

        public void Develop()
        {
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(EntityDir, GetProjectPath(), "default.xml")))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
                outputFile.WriteLine("<TargetEndpoint name=\"default\">");
                outputFile.WriteLine("    <Description/>");
                outputFile.WriteLine("    <FaultRules/>");
                outputFile.WriteLine("    <PreFlow name=\"PreFlow\">");
                outputFile.WriteLine("        <Request/>");
                outputFile.WriteLine("        <Response>");
                outputFile.WriteLine("            <Step>");
                outputFile.WriteLine("                <Name>add-cors</Name>");
                outputFile.WriteLine("            </Step>");
                outputFile.WriteLine("        </Response>");
                outputFile.WriteLine("    </PreFlow>");
                outputFile.WriteLine("    <PostFlow name=\"PostFlow\">");
                outputFile.WriteLine("        <Request/>");
                outputFile.WriteLine("        <Response/>");
                outputFile.WriteLine("    </PostFlow>");
                outputFile.WriteLine("    <Flows/>");
                outputFile.WriteLine("    <HTTPTargetConnection>");
                outputFile.WriteLine("        <Properties/>");
                outputFile.WriteLine($"        <URL>http://{EntityMap.Target}/{EntityMap.Namespace}</URL>");
                outputFile.WriteLine("    </HTTPTargetConnection>");
                outputFile.WriteLine("</TargetEndpoint>");
            }
        }
    }
}
