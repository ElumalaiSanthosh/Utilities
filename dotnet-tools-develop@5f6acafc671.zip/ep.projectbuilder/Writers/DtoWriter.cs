﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class DtoWriter : WriterBase, IWriter
    {
        internal DtoWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetSubPath()
        {
            return string.Empty;
        }

        public override string GetFileName()
        {
            return $"{Entity.Name}.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Dtos;

        public void Create(ref bool firstPass)
        {
            List<Property> properties = Entity.Properties;

            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.ComponentModel.DataAnnotations;");
                outputFile.WriteLine("using System.ComponentModel.DataAnnotations.Schema;");
                outputFile.WriteLine("using ApiService.Commons.DBAttributes;");
                outputFile.WriteLine("using ApiService.Commons.Models.Dtos;");
                outputFile.WriteLine("using Newtonsoft.Json;");
                outputFile.WriteLine("using System.Xml.Serialization;");
                outputFile.WriteLine("using System.Runtime.Serialization;");
                outputFile.WriteLine("using Swashbuckle.AspNetCore.Annotations;");
                
                outputFile.WriteLine("");
                outputFile.WriteLine("namespace " + EntityMap.Namespace + ".Models.Dtos");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                if (!string.IsNullOrEmpty(Entity.JsonName))
                {
                    outputFile.WriteLine($"    [JsonObject(\"{Entity.JsonName}\")]");
                }

                //outputFile.WriteLine($"    [XmlType (Namespace = \"{EntityMap.Namespace}\")]");
                outputFile.WriteLine($"    [XmlRoot (\"{Entity.Name}\")]");
                outputFile.WriteLine("    [DataContract]");

                    
                if (!string.IsNullOrEmpty(Entity.Table))
                {
                    outputFile.WriteLine($"    [Table (\"{Entity.Table}\", Schema=\"{Entity.Schema}\")]");
                }
                outputFile.WriteLine($"    public partial class {Entity.Name} : DtoBase<{Entity.Name}>");
                outputFile.WriteLine("    {");
                outputFile.WriteLine($"        public {Entity.Name}()");
                outputFile.WriteLine("        {");

                foreach (Property p in Entity.Properties)
                {
                    if (p.NullValue != null && p.EntityType() != "Guid")
                    {
                        outputFile.Write($"            {p.Name} = ");
                        if (p.EntityType() == "string")
                        {
                            outputFile.Write($"\"{p.NullValue}\";");
                        }
                        else if (p.EntityType() == "bool")
                        {
                            outputFile.Write(p.NullValue == "0" ? "false;" : "true;");
                        }
                        else if (p.EntityType() == "DateTime")
                        {
                            outputFile.Write($"DateTime.ParseExact(\"{p.NullValue}\", \"yyyy-MM-dd HH:mm:ss.fff\", System.Globalization.CultureInfo.InvariantCulture);");
                        }
                        else
                        {
                            outputFile.Write($"{p.NullValue};");
                        }
                        outputFile.Write(Environment.NewLine);
                    }
                }

                outputFile.WriteLine("        }");
                outputFile.WriteLine("");
                outputFile.WriteLine($"        public {Entity.Name}({GetMethodParameterNamesFromProperties(EntityMap, Entity.Properties, Entity.Relationships)}) : this()");
                outputFile.WriteLine("        {");

                foreach (Property p in Entity.Properties)
                {
                    outputFile.WriteLine($"            {p.Name} = {p.Name.CamelCase()};");
                }

                foreach (Relationship r in Entity.Relationships)
                {
                    if (EntityMap.Entities.First(entity => entity.Name == r.RelatedEntity).Visibility == "internal")
                    {
                        continue;
                    }

                    if (r.Cardinality == "OneToMany")
                    {
                        outputFile.WriteLine($"            {r.PluralName} = {r.RelatedEntity.CamelCase()};");
                    }
                    //else
                    //{
                    //    outputFile.WriteLine($"            {r.Name} = {r.Name.CamelCase()};");
                    //}

                }
                outputFile.WriteLine("        }");

                foreach (Property property in properties)
                {
                    outputFile.WriteLine("");
                    outputFile.WriteLine(WriteAttribute(property));
                    if (property.AllowNull && !property.EntityType().Equals("string") &&
                        !property.EntityType().Equals("byte[]"))
                    {
                        outputFile.WriteLine($"        public {property.EntityType()}? {property.Name} " +
                                             "{ get; set; }");
                    }
                    else
                    {
                        outputFile.WriteLine($"        public {property.EntityType()} {property.Name} " +
                                             "{ get; set; }");
                    }
                }

                if (Entity.Relationships != null && Entity.Relationships.Any())
                {
                    foreach (Relationship rel in Entity.Relationships)
                    {
                        if (EntityMap.Entities.First(entity => entity.Name == rel.RelatedEntity).Visibility == "internal" || rel.Cardinality == "OneToOne")
                        {
                            continue;
                        }

                        outputFile.WriteLine("");
                        outputFile.WriteLine($"        [ForeignTable(\"{rel.RelatedEntity}\", typeof({rel.RelatedEntity}), \"{rel.RelatedProperty}\")]");

                        outputFile.Write("        [JsonProperty(");

                        if (!string.IsNullOrEmpty(rel.JsonName))
                        {
                            outputFile.Write($"PropertyName = \"{rel.JsonName}\", ");
                        }

                        outputFile.Write($"NullValueHandling = NullValueHandling.Ignore)]{Environment.NewLine}");

                        if (rel.Cardinality == "OneToMany")
                        {
                            outputFile.WriteLine($"        [XmlArray(\"{rel.PluralName}\")]");
                            outputFile.WriteLine($"        [XmlArrayItem(\"{rel.Name}\"), XmlArrayItem(\"{rel.RelatedEntity}Dto\", Type = typeof({rel.RelatedEntity}))]{Environment.NewLine}");
                            outputFile.WriteLine($"        public List<{rel.RelatedEntity}> {rel.PluralName} " + "{ get; set; }");
                        }
                        else
                        {
                            outputFile.WriteLine($"        [XmlElement]{Environment.NewLine}");
                            outputFile.WriteLine($"        public {rel.RelatedEntity} {rel.Name} " + "{ get; set; }");
                        }
                    }
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");
            }
        }

        private static string WriteAttribute(Property column)
        {
            StringBuilder att = new StringBuilder();

            if (column.PrimaryKey)
            {
                att.Append($"        [Key]{Environment.NewLine}");
            }

            if (column.IsDbGenerated)
            {
                att.Append($"        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]{Environment.NewLine}");
            }

            att.Append($"        [Display(Name = \"{column.Name}:\")]{Environment.NewLine}");

            att.Append($"        [Column (\"{column.DbName}\", TypeName = \"{column.EntityType()}\")]{Environment.NewLine}");
            att.Append($"        [DataMember(Name = \"{column.DbName}\")]{Environment.NewLine}");

            if (column.EntityType() == "string")
            {

                att.Append($"        [StringLength({column.Size}, ");

                if (!column.AllowNull)
                {
                    att.Append($"MinimumLength = 1, ");
                }

                att.Append($"ErrorMessage = \"{column.Name} cannot be longer than {column.Size} characters.\")]{Environment.NewLine}");
            }

            if (!column.AllowNull)
            {
                att.Append("        [Required");
                if (column.EntityType() == "string")
                {
                    att.Append($"(AllowEmptyStrings = false, ErrorMessage = \"{column.Name} cannot be blank.\")");
                }
                att.Append($"]{Environment.NewLine}");
            }

            if (column.AllowNull || !string.IsNullOrEmpty(column.DbName) || !string.IsNullOrEmpty(column.JsonName))
            {
                att.Append("        [JsonProperty(");

                if (!string.IsNullOrEmpty(column.DbName) || !string.IsNullOrEmpty(column.JsonName))
                {
                    att.Append(!string.IsNullOrEmpty(column.JsonName)
                        ? $"PropertyName = \"{column.JsonName}\""
                        : $"PropertyName = \"{column.DbName}\"");

                    if (column.AllowNull)
                    {
                        att.Append(", ");
                    }
                }

                if (column.AllowNull)
                {
                    att.Append("NullValueHandling = NullValueHandling.Ignore");
                }

                att.Append($")]{Environment.NewLine}");
            }

            att.Append(column.AllowNull
                ? $"        [XmlElement(IsNullable = true)]{Environment.NewLine}"
                : $"        [XmlElement(IsNullable = false)]{Environment.NewLine}");

            if (!string.IsNullOrEmpty(column.Description))
            {
                att.Append($"        [SwaggerSchema(\"{column.Description.Trim()}\")]{Environment.NewLine}");
            }

            return att.ToString();
        }
    }
}
