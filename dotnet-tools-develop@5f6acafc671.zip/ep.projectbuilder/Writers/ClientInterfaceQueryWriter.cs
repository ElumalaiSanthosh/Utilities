﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ProjectBuilder.Models;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Writers
{
    public class ClientInterfaceQueryWriter : WriterBase, IWriter
    {
        internal ClientInterfaceQueryWriter(ModelsMap entityMap, Entity entity, string entityDir, string subDir) : base(entityMap, entity, entityDir, subDir)
        {
        }

        public override string GetFileName()
        {
            return $"I{Entity.Name}QueryClient.generated.cs";
        }

        public override WriterTypes GetWriterType() => WriterTypes.Clients;

        public override bool VerifyVisibility()
        {
            if (Entity.Visibility == "internal" ||
                Entity.Visibility == "dto")
            {
                return false;
            }

            return true;
        }

        public void Create(ref bool firstPass)
        {
            if (!File.Exists(GetFilePath()))
            {
                Directory.CreateDirectory(GetFilePath());
            }

            using (StreamWriter outputFile = new StreamWriter(GetFilePathAndName()))
            {
                WriteHeader(outputFile, GetFileName());
                outputFile.WriteLine("using ApiService.Commons.DataStore;");
                outputFile.WriteLine("using System.Collections.Generic;");
                outputFile.WriteLine("using System.Threading.Tasks;");
                outputFile.WriteLine("using ApiService.Commons.Clients;");
                outputFile.WriteLine($"using {EntityMap.Namespace}.Models.Dtos;");
                outputFile.WriteLine("using ApiService.Commons.Rest;");
                outputFile.WriteLine("using System.Net;");
                outputFile.WriteLine("using System;");
                outputFile.WriteLine("");
                outputFile.WriteLine($"namespace {EntityMap.Namespace}.Clients");
                outputFile.WriteLine("{");
                outputFile.WriteLine("");

                outputFile.WriteLine($"    public partial interface I{EntityMap.Namespace}Client");
                outputFile.WriteLine("    {");
                if (firstPass)
                {
                    outputFile.WriteLine("        Task<RequestResponse<T>> GetRequestResponseAsync<T>(string resource, ApiRestVerbs method = ApiRestVerbs.Get, HttpStatusCode successStatus = HttpStatusCode.OK, List<object> bodyObjects = null, IList<string> urlSegments = null, IDictionary<string, string> queryParams = null, IDictionary<string, string> headers = null, int timeout = 0);");
                    outputFile.WriteLine("");
                    outputFile.WriteLine("        Task<RequestResponse<PageResults<T>>> GetOdataPagedRequestResponseAsync<T>(string resource, IList<string> urlSegments = null, QueryOptions options = null, IEnumerable<string> columns = null, IDictionary<string, string> queryParams = null, IDictionary<string, string> headers = null, int timeout = 0);");
                    outputFile.WriteLine("");
                }

                if (Entity.HasCommand("get") && Entity.HasPrimaryKey())
                {
                    outputFile.WriteLine("        #region Query");
                    outputFile.Write($"        Task<RequestResponse<{Entity.Name}>> Get{Entity.Name}Async({Entity.PrimaryKeysWithTypes()}");

                    if (Entity.HasDataset && Entity.HasOneToMany())
                    {
                        outputFile.Write(", bool shouldReturnRelatedRecords = false");
                    }

                    outputFile.Write($", int timeout = 0);{Environment.NewLine}");

                    IEnumerable<Relationship> relationships = Entity.Relationships.Where(e => e.Cardinality == "OneToOne");
                    if (relationships.Any())
                    {
                        foreach (var r in relationships)
                        {
                            outputFile.WriteLine("");
                            outputFile.WriteLine("        /// <summary>");
                            outputFile.WriteLine($"        /// Get Method for Relationship {r.RelatedEntity}");
                            outputFile.WriteLine("        /// </summary>");
                            outputFile.WriteLine($"        /// <param name=\"{r.PropertyName.CamelCase()}\"></param>");
                            outputFile.WriteLine("        /// <param name=\"columns\"></param>");
                            outputFile.WriteLine("        /// <param name=\"timeout\"></param>");
                            outputFile.WriteLine($"        Task<RequestResponse<List<{Entity.Name}>>> GetMany{Entity.PluralName}By{r.PropertyName}Async({r.RelationshipWithType(Entity)}, int timeout = 0);");
                        }
                    }

                    if (Entity.UniqueKeys.Any())
                    {
                        foreach (var key in Entity.UniqueKeys)
                        {
                            List<string> props = key.Properties.Split(",").ToList();
                            outputFile.WriteLine("");
                            outputFile.WriteLine("        /// <summary>");
                            outputFile.WriteLine($"        /// Get Method for {key.Name}");
                            outputFile.WriteLine("        /// </summary>");
                            foreach (var p in props)
                            {
                                outputFile.WriteLine($"        /// <param name=\"{p.CamelCase()}\"></param>");
                            }
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.WriteLine("        /// <param name=\"shouldReturnRelatedRecords\"></param>");
                            }
                            
                            outputFile.WriteLine("        /// <param name=\"timeout\"></param>");
                            outputFile.Write($"        Task<RequestResponse<{Entity.Name}>> Get{Entity.Name}By{props.UniqueName()}Async({props.UniqueKeysWithTypes(Entity)}");
                            if (Entity.HasDataset && Entity.HasOneToMany())
                            {
                                outputFile.Write(", bool shouldReturnRelatedRecords = false");
                            }

                            outputFile.Write($", int timeout = 0);{Environment.NewLine}");
                        }
                    }
                
                    outputFile.WriteLine("");
                    outputFile.WriteLine($"        Task<RequestResponse<PageResults<{Entity.Name}>>> GetMany{Entity.PluralName}Async(IList<string> urlParams = null, QueryOptions options = null, IList<string> columns = null, int timeout = 0);");
                    outputFile.WriteLine("        #endregion Query");
                }

                outputFile.WriteLine("    }");
                outputFile.WriteLine("}");

                firstPass = false;
            }
        }
    }
}
