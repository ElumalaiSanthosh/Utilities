﻿using System.Collections.Generic;
using System.Linq;
using ProjectBuilder.Models;

namespace ProjectBuilder.Extensions
{
    public static class EntityExtensions
    {
        public static string PrimaryKeysWhere(this Entity entity)
        {
            List<string> list = new List<string>();

            IList<Property> properties = entity.Properties.Where(e => e.PrimaryKey).ToList();

            foreach (Property p in properties)
            {
                string where = "\"" + p.DbName + " eq \" + " + p.Name.CamelCase();

                if (p.EntityType() == "string" || p.EntityType() == "Guid")
                {
                    if (p.EntityType() == "Guid")
                    {
                        where += ".ToString()";
                    }

                    where += ".SqlQuoteString()";
                }

                list.Add(where);
            }
            return string.Join(" + \" AND \" + ", list);
        }

        public static string RelationshipKeysWhere(this Relationship r, Entity entity)
        {
            var property = entity.Properties.FirstOrDefault(e => e.Name == r.PropertyName);

            string where = "\"" + property?.DbName + " eq \" + " + r.PropertyName.CamelCase();


            if (r.Type.GetEntityType() == "string" || r.Type.GetEntityType() == "Guid")
            {
                if(r.Type.GetEntityType() == "Guid")
                {
                    where += ".ToString()";
                }

                where += ".SqlQuoteString()";
            }

            return where;
        }

        public static string PrimaryKeysValidation(this Entity entity, string dto)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(dto + "." + property.Name + (property.EntityType() == "string" ? ".Trim()" : "") + " != " + property.Name.CamelCase() + (property.EntityType() == "string" ? ".Trim()" : ""));
                }
            }
            return string.Join(" || ", keys);
        }

        public static string PrimaryKeysForApigee(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(property.Name.CamelCase());
                }
            }
            return string.Join("-", keys);
        }

        public static string PrimaryKeysForRoute(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add("{" + property.Name.CamelCase() + "}");
                }
            }
            return string.Join("/", keys);
        }

        public static string PrimaryKeysForCache(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(property.Name.CamelCase() + "-{ " +property.Name.CamelCase() + " }");
                }
            }
            return string.Join(".", keys);
        }

        public static string PrimaryKeysForDeleteCache(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(property.Name.CamelCase() + "-{ " + entity.Name.CamelCase() + "." + property.Name + " }");
                }
            }
            return string.Join(".", keys);
        }

        public static string PrimaryKeysWithTypes(this Entity entity, bool includeType = true)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    if (includeType)
                    {
                        keys.Add(property.EntityType() + " " + property.Name.CamelCase());
                        continue;
                    }
                    keys.Add(property.Name.CamelCase());
                }
            }
            return string.Join(", ", keys);
        }

        public static string PrimaryKeysForMoq(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add($"It.IsAny<{property.EntityType()}>()");
                }
            }
            return string.Join(", ", keys);
        }

        public static string PrimaryKeysFromDto(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add("dto." + property.Name);
                }
            }
            return string.Join(", ", keys);
        }

        public static string PrimaryKeysForLocation(this Entity entity)
        {
            if (entity.PrimaryKeyList() == null || !entity.PrimaryKeyList().Any()) return null;

            if (entity.PrimaryKeyList().Count == 1) return "result." + entity.PrimaryKeyList().First().Name;

            foreach (var p in entity.PrimaryKeyList())
            {

            }

            return "Need to code loop above";
        }

        public static string RelationshipWithType(this Relationship r, Entity entity)
        {
            Property p = entity.Properties.First(e => e.Name == r.PropertyName);
            return p.EntityType() + " " + r.PropertyName.CamelCase();
        }

        public static string RelationshipTarget(this string s)
        {
            return s.ToUpper().EndsWith("ID") ? s.Substring(0, s.Length - 2).ToLower() : s.ToLower();
        }

        public static string RelationshipValuesForTest(this Relationship r, Entity entity)
        {
            Property p = entity.Properties.First(e => e.Name == r.PropertyName);

            if (p.EntityType() != "Guid")
            {
                return p.EntityType() == "string" ? $"\"{entity.Name}\"" : "1";
            }

            return PropertyExtension.TestValue(p);
        }

        public static string UniqueKeyTarget(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {  
                keys.Add(s.ToLower());
                keys.Add("{" + s.CamelCase() + "}");
            }
            return string.Join("/", keys);
        }

        public static string UniqueKeyCache(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {                
                keys.Add($"{s.ToLower()}.{s.CamelCase()}-" + "{" + s.CamelCase() + "}");
            }
            return string.Join(".", keys);
        }

        public static string UniqueKeyDeleteCache(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {
                keys.Add($"{s.CamelCase()}-" + "{" + entity.Name.CamelCase() + "." + s + "}");
            }
            return string.Join(".", keys);
        }
        
        public static string UniqueName(this List<string> props)
        {
            string name = "";
            foreach (var s in props)
            {
                //name += s.ToUpper().EndsWith("ID") ? s.Substring(0, s.Length - 2) : s;
                name += s;
            }

            return name;
        }

        public static string UniqueKeys(this List<string> props)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {
                keys.Add(s.CamelCase());
            }
            return string.Join(", ", keys);
        }

        public static string UniqueKeysWithTypes(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {
                Property p = entity.Properties.First(e => e.Name == s);
                if (p != null)
                {
                    keys.Add(p.EntityType() + " " + p.Name.CamelCase());
                }
            }
            return string.Join(", ", keys);
        }

        public static string UniqueKeysForQuery(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {

                Property p = entity.Properties.First(e => e.Name == s);
                if (p != null)
                {
                    var name = p.Name;
                    //var key = $"\"{(name.ToUpper().EndsWith("ID") ? name.Substring(0, name.Length - 2).ToLower() : name.ToLower())}\", {p.Name.CamelCase()}";
                    var key = $"\"{name.ToLower()}\", {p.Name.CamelCase()}";

                    if (p.EntityType() != "string")
                    {
                        key += ".ToString()";
                    }

                    keys.Add(key);
                }
            }
            return string.Join(", ", keys);
        }


        public static string UniqueKeysWhere(this List<string> props, Entity entity)
        {
            List<string> list = new List<string>();
            foreach (string s in props)
            {
                Property p = entity.Properties.First(e => e.Name == s);
                if (p != null)
                {
                    string where = "\"" + p.DbName + " eq \" + " + p.Name.CamelCase();

                    if (p.EntityType() == "string" || p.EntityType() == "Guid")
                    {
                        if (p.EntityType() == "Guid")
                        {
                            where += ".ToString()";
                        }

                        where += ".SqlQuoteString()";
                    }

                    list.Add(where);
                }
            }
            return string.Join(" + \" AND \" + ", list);
        }

        public static string GetUniqueKeyValuesForTest(this List<string> props, Entity entity)
        {
            List<string> list = new List<string>();
            foreach (string s in props)
            {
                Property p = entity.Properties.First(e => e.Name == s);
                if (p != null)
                {
                    if(p.EntityType().GetEntityType() != "Guid")
                    {
                        list.Add(p.EntityType().GetEntityType() == "string" ? $"\"{entity.Name}\"" : "1");
                        continue;
                    }
                    
                    list.Add(PropertyExtension.TestValue(p));
                }
            }

            return string.Join(",", list);
        }

        public static string PrimaryKeysWithRefTypes(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add("ref " + property.EntityType() + " " + property.Name.CamelCase());
                }
            }
            return string.Join(", ", keys);
        }

        public static string PrimaryKeysRef(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(property.Name.CamelCase());
                }
            }
            return "ref " + string.Join(", ref ", keys);
        }

        public static string PrimaryKeys(this Entity entity, bool convertToString = true)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    string key = property.Name.CamelCase();

                    if (convertToString)
                    {
                        key += property.EntityType() == "string" ? ".Trim()" : ".ToString()";
                    }

                    keys.Add(key);
                }
            }
            return string.Join(",", keys);
        }

        public static string PrimaryKeyValuesForFilterTest(this Entity entity, bool convertToString = true)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add($"{property.Name} eq {(property.EntityType() == "string" ? entity.Name.SqlQuoteString() : property.TestValue())}");
                }
            }

            return string.Join(" AND ", keys);
        }

        public static string PrimaryKeyValuesForTest(this Entity entity, bool convertToString = true)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    if (property.EntityType() != "Guid")
                    {
                        keys.Add(property.EntityType() == "string" ? $"\"{entity.Name}\"" : "1");
                        continue;
                    }

                    keys.Add(PropertyExtension.TestValue(property));
                }
            }

            return string.Join(",", keys);
        }

        public static string CheckPrimaryKeysNull(this Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    if (property.EntityType() == "string")
                    {
                        keys.Add($"string.IsNullOrEmpty({property.Name.CamelCase()})");
                    }
                    else
                    {
                        keys.Add(property.Name.CamelCase() + " < 1");
                    }
                }
            }
            return string.Join(" || ", keys);
        }


        public static string CheckUniqueKeysNull(this List<string> props, Entity entity)
        {
            List<string> keys = new List<string>();
            foreach (string s in props)
            {
                Property p = entity.Properties.First(e => e.Name == s);
                if (p != null)
                {
                    if (p.EntityType() == "string")
                    {
                        keys.Add($"string.IsNullOrEmpty({p.Name.CamelCase()})");
                    }
                    else
                    {
                        keys.Add(p.Name.CamelCase() + " < 1");
                    }
                }
            }
            return string.Join(" || ", keys);
        }



        public static string PropertyNameForTest(this Entity entity)
        {
            IList<string> s = new List<string>();
            foreach (Property p in entity.Properties)
            {
                s.Add(p.Name);
            }
            return string.Join(", ", s);
        }

        public static bool HasChildren(this Entity entity)
        {
            return entity?.Relationships.Count > 0;
        }

        public static bool HasOneToMany(this Entity entity)
        {
            return entity?.Relationships.Where(e => e.Cardinality == "OneToMany").ToList().Count > 0;
        }

        public static bool HasManyToOne(this Entity entity)
        {
            return entity?.Relationships.Where(e => e.Cardinality == "ManyToOne").ToList().Count > 0;
        }

        public static bool HasPrimaryKey(this Entity entity)
        {
            return PrimaryKeyCount(entity) > 0;
        }

        public static int PrimaryKeyCount(this Entity entity)
        {
            return PrimaryKeyList(entity).Count;
        }

        public static List<Property> PrimaryKeyList(this Entity entity)
        {
            List<Property> keys = new List<Property>();
            foreach (Property property in entity.Properties)
            {
                if (property.PrimaryKey)
                {
                    keys.Add(property);
                }
            }
            return keys;
        }

        public static string CreateHashCodes(this Entity entity)
        {
            List<string> result = new List<string>();

            foreach (Property prop in entity.Properties)
            {
                if (prop.PrimaryKey)
                    result.Add(string.Format("this.{0}.GetHashCode()", prop.Name));
            }
            return string.Join(" ^ ", result);
        }

        public static string CreateHashCodesForAssert(this Entity entity)
        {
            List<string> result = new List<string>();

            foreach (Property prop in entity.Properties)
            {
                if (prop.PrimaryKey)
                    result.Add(string.Format("entity.{0}.GetHashCode()", prop.Name));
            }
            return string.Join(" ^ ", result);
        }

        public static bool HasCommand(this Entity entity, string s)
        {
            Command c = entity.Commands?.Where(e => e.Name == s).FirstOrDefault();
            return c != null;
        }

        public static bool HasCommandElement(this Entity entity)
        {
            Command c = entity.Commands?.Where(e => e.Name == "create").FirstOrDefault();
            Command u = entity.Commands?.Where(e => e.Name == "update").FirstOrDefault();
            Command d = entity.Commands?.Where(e => e.Name == "delete").FirstOrDefault();

            return c != null || d != null || u != null;
        }

        public static bool HasGetElement(this Entity entity)
        {
            Command c = entity.Commands?.Where(e => e.Name == "get").FirstOrDefault();

            return c != null;
        }

        public static bool ExcludeTest(this Entity entity, string s)
        {
            if (entity.ExcludeTests == null || !entity.ExcludeTests.Any())
            {
                return false;
            }

            foreach (ExcludeTest c in entity.ExcludeTests)
            {
                if (c.Name == s)
                {
                    return true;
                }
            }
            return false;
        }

        public static string RelationshipsForConstructor(this Entity entity)
        {
            List<string> constructor = new List<string>();

            foreach (Relationship r in entity.Relationships)
            {
                if (r.Cardinality == "OneToMany" || r.Cardinality == "ManyToOne")
                {
                    constructor.Add($"I{r.RelatedEntity}Service {r.RelatedEntity.CamelCase()}Service");
                }
            }

            return string.Join(", ", constructor);
        }

        public static string RelationshipsForBuild(this Entity entity)
        {
            List<string> constructor = new List<string>();

            foreach (Relationship r in entity.Relationships)
            {
                constructor.Add($"{r.RelatedEntity}Service.Object");
            }
            return string.Join(", ", constructor);
        }

        public static string RelationshipValueTest(this Relationship r, Entity entity)
        {
            Property p = entity.Properties.First(e => e.Name == r.PropertyName);
            return p.EntityType() == "string" ? $"\"{entity.Name}\"" : "1";
        }

        public static string GetEntityType(this string type)
        {
            switch (type.ToUpper())
            {
                case "DOUBLE":
                    return "double";
                case "CHAR":
                    return "string";
                case "NVARCHAR":
                    return "string";
                case "VARCHAR":
                    return "string";
                case "SMALLINT":
                    return "short";
                case "SMALLDATETIME":
                    return "DateTime";
                case "DATETIME":
                    return "DateTime";
                case "FLOAT":
                    return "decimal";
                case "IMAGE":
                    return "byte[]";
                case "INT":
                    return "int";
                case "INT32":
                    return "int";
                case "INT64":
                    return "long";
                case "BOOL":
                    return "bool";
                case "BIT":
                    return "bool";
                case "DECIMAL":
                    return "decimal";
                case "GUID":
                case "UUID":
                case "UNIQUEIDENTIFIER":
                    return "Guid";

                default:
                    return "string";
            }
        }
    }
}
