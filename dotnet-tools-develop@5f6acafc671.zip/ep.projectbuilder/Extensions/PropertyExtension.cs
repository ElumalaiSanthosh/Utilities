﻿using ProjectBuilder.Models;

namespace ProjectBuilder.Extensions
{
    public static class PropertyExtension
    {
        public static string GetPropertyWithValueForTest(this Property p)
        {
            return $"{p.Name} = {p.TestValue()}";
        }

        public static string TestValue(this Property p)
        {
            if (p.EntityType() == "double")
            {
                return "1.99";
            }
            if (p.EntityType() == "short" || p.EntityType() == "int" || p.EntityType() == "long")
            {
                return "1";
            }
            if (p.EntityType() == "bool")
            {
                return "true";
            }
            if (p.EntityType() == "DateTime")
            {
                return "new DateTime(1971,04,20)";
            }
            if (p.EntityType() == "decimal")
            {
                return "1.99m";
            }
            if (p.EntityType() == "Guid")
            {
                return "new Guid(\"00000000-0000-0000-0000-000000000001\")";
            }

            //if string or unrecognized
            if (p.Size > 0  && p.Size < p.Name.Length)
            {
                return $"\"{p.Name.Substring(0, p.Size)}\"";
            }

            return $"\"{p.Name}\"";
        }

        public static string TestValue2(this Property p)
        {
            if (p.EntityType() == "double")
            {
                return "2.99";
            }
            if (p.EntityType() == "short" || p.EntityType() == "int" || p.EntityType() == "long")
            {
                return "2";
            }
            if (p.EntityType() == "bool")
            {
                return "false";
            }
            if (p.EntityType() == "DateTime")
            {
                return "new DateTime(1976,10,08)";
            }
            if (p.EntityType() == "decimal")
            {
                return "2.99m";
            }
            if (p.EntityType() == "Guid")
            {
                return "new Guid(\"00000000-0000-0000-0000-000000000002\")";
            }

            //if string or unrecognized
            if (p.Size > 0 && p.Size < p.Name.Length)
            {
                return $"\"{p.Name.Substring(0, p.Size)}\"";
            }

            return $"\"{p.Name}\"";
        }
    }
}
