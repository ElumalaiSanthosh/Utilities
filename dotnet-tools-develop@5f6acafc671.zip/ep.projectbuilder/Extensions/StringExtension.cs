﻿using System;
using System.Linq;

namespace ProjectBuilder.Extensions
{
    public static class StringExtension
    {
        public static string SqlQuoteString(this string quote)
        {
            return ($"'{quote.Replace("'", "''")}'");
        }

        public static string CamelCase(this string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            char[] a = s.ToCharArray();
            a[0] = char.ToLower(a[0]);

            return new string(a);
        }

        public static string FirstCharToUpper(this string input)
        {
            switch (input)
            {
                case null: throw new ArgumentNullException(nameof(input));
                case "": throw new ArgumentException($"{nameof(input)} cannot be empty", nameof(input));
                default: return input.First().ToString().ToUpper() + input.Substring(1);
            }
        }

        public static string FriendlyCase(this string s)
        {
            string output = string.Empty;
            bool lastUpper = true;

            foreach (char letter in s)
            {
                if (char.IsUpper(letter) && output.Length > 0 && !lastUpper)
                {
                    output += "-" + letter;
                    lastUpper = true;
                }
                else
                {
                    output += letter;

                    if (!char.IsUpper(letter))
                    {
                        lastUpper = false;
                    }
                }
            }

            return output;
        }
    }
}
