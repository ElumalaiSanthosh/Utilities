﻿using System;
using EntityBuilder.Controllers;
using ProjectBuilder.Models;

namespace ProjectBuilder.Controllers
{
    public class ControllerFactory
    {
        private BuilderData Data { get; }


        public ControllerFactory(BuilderData data)
        {
            Data = data;
        }

        internal IController GetController()
        {
            if (Data.Type == ProjectBuilderType.Dtos.ToString())
            {
                return new DtoController(Data);
            }
            if (Data.Type == ProjectBuilderType.Services.ToString())
            {
                return new ServiceController(Data);
            }
            if (Data.Type == ProjectBuilderType.Controllers.ToString())
            {
                return new ControllerController(Data);
            }
            if (Data.Type == ProjectBuilderType.Tests.ToString())
            {
              return new TestController(Data);
            }

            throw new ArgumentException("Type not supported.");
        }
    }
}