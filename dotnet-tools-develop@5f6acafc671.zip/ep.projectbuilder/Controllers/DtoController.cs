﻿using ProjectBuilder.Models;
using ProjectBuilder.Writers;
using System.Linq;
using ProjectBuilder.Extensions;

namespace ProjectBuilder.Controllers
{
    public class DtoController : ControllerBase, IController
    {
        private const string ModelsSubDir = @"Models";
        private const string ClientsSubDir = @"Clients";

        internal DtoController(BuilderData data) : base(data)
        {
        }

        public void Create()
        {
            Clean();
            bool firstPass = true;

            foreach (Entity entity in Data.ModelsMap.Entities)
            {
                Build(new DtoWriter(Data.ModelsMap, entity, Data.OutPath, ModelsSubDir), ref firstPass);
                Build(new EntityWriter(Data.ModelsMap, entity, Data.OutPath, ModelsSubDir), ref firstPass);

                if (entity.Commands != null && entity.Commands.Any())
                {
                    if (entity.Visibility == "dto" || entity.Visibility == "internal")
                    {
                        continue;
                    }

                    Build(new ClientQueryWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                    Build(new ClientInterfaceQueryWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                    if (entity.Visibility == "public" && entity.HasCommandElement())
                    {
                        Build(new ClientCommandWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                        Build(new ClientInterfaceCommandWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                    }
                }
            }
        }

        public void Clean()
        {
            CleanPath("Dtos", ModelsSubDir);
            CleanPath("Clients");
            CleanPath("Entities", ModelsSubDir);
        }
    }
}
