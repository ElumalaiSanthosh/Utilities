﻿using ProjectBuilder.Models;
using ProjectBuilder.Writers;

namespace ProjectBuilder.Controllers
{
    public class ServiceController : ControllerBase, IController
    {
        internal ServiceController(BuilderData data) : base(data)
        {
        }

        public void Create()
        {
            Clean();
            bool firstPass = true;

            foreach (Entity entity in Data.ModelsMap.Entities)
            {
                if (entity.Visibility == "dto")
                {
                    continue;
                }

                Build(new ServiceWriterQuery(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                Build(new ServiceWriterCommand(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                Build(new ServiceInterfaceQueryWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                if (entity.Visibility != "readonly" && entity.Visibility != "view")
                {
                    Build(new ServiceInterfaceCommandWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }
            }
        }

        public void Clean()
        {
            CleanPath(Data.Type);
        }
    }
}
