﻿using System.Linq;
using ProjectBuilder.Controllers;
using ProjectBuilder.Extensions;
using ProjectBuilder.Models;
using ProjectBuilder.Writers.TestCases;

namespace EntityBuilder.Controllers
{
    public class TestController : ControllerBase, IController
    {
        private const string ModelsSubDir = @"Models";

        internal TestController(BuilderData data) : base(data)
        {
        }

        public void Create()
        {
            Clean();
            bool firstPass = true;

            foreach (Entity entity in Data.ModelsMap.Entities)
            {
                Build(new DtoTestWriter(Data.ModelsMap, entity, Data.OutPath, ModelsSubDir), ref firstPass);
                Build(new EntityTestWriter(Data.ModelsMap, entity, Data.OutPath, ModelsSubDir), ref firstPass);

                if (entity.Commands != null && entity.Commands.Any())
                {
                    if (entity.Visibility == "dto" || entity.Visibility == "internal")
                    {
                        continue;
                    }

                    Build(new ClientTestWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }
                
                if (firstPass)
                {
                    Build(new HealthControllerTestWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }

                if (entity.Visibility != "internal" && entity.HasGetElement())
                {
                    Build(new ControllerQueryTestWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }

                if (entity.Visibility == "public" && entity.HasCommandElement())
                {
                    Build(new ControllerCommandTestWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }

                //Build(new ComponentTestWriter(Data.ProjectName, Data.EntityMap, entity, Data.OutPath, Data.SubDir), ref firstPass);

                //if (firstPass)
                //{
                //  Build(new ComponentBaseTestWriter(Data.ProjectName, Data.EntityMap, entity, Data.OutPath, Data.SubDir), ref firstPass);
                //}

                firstPass = false;
            }
        }

        public void Clean()
        {
            CleanPath("Dtos", ModelsSubDir);
            CleanPath("Clients");
            CleanPath("Entities", ModelsSubDir);
            CleanPath("Controllers");
            CleanPath("Components");
        }
    }
}
