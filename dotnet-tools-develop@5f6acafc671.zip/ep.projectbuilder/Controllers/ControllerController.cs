﻿using ProjectBuilder.Extensions;
using ProjectBuilder.Models;
using ProjectBuilder.Writers;
using System.Linq;

namespace ProjectBuilder.Controllers
{
    public class ControllerController : ControllerBase, IController
    {
        internal ControllerController(BuilderData data) : base(data)
        {
        }

        public void Create()
        {
            Clean();
            bool firstPass = true;
            
            foreach (Entity entity in Data.ModelsMap.Entities)
            {
                if (firstPass)
                {
                    Build(new HealthControllerWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);

                    if (Data.ModelsMap.Entities.Any(e => e.Visibility != "dto" && e.Visibility != "internal"))
                    {
                        Build(new ControllerExtensionWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                        Build(new ControllerOdataExtensionWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);                        
                    }
                }

                if (entity.Visibility != "internal" && entity.HasGetElement())
                {
                    Build(new ControllerQueryWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }

                if (entity.Visibility == "public" && entity.HasCommandElement())
                {
                    Build(new ControllerCommandWriter(Data.ModelsMap, entity, Data.OutPath, null), ref firstPass);
                }

                firstPass = false;
            }
        }

        public void Clean()
        {
            CleanPath(Data.Type);
        }
    }
}
