﻿using System.IO;
using ProjectBuilder.Models;
using ProjectBuilder.Writers;

namespace ProjectBuilder.Controllers
{
    public class ControllerBase
    {
        internal BuilderData Data { get; }

        internal ControllerBase(BuilderData data)
        {
            Data = data;
        }

        internal void CleanPath(string entityType, string subDir = "")
        {
            string projectPath = Path.Combine(string.IsNullOrEmpty(subDir) ? "": subDir, Path.Combine(entityType, "Generated")) ;

            string filePath = Path.Combine(Data.OutPath, projectPath);

            if (!Directory.Exists(filePath))
            {
                return;
            }
            
            DirectoryInfo di = new DirectoryInfo(filePath);

            foreach (FileInfo file in di.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in di.GetDirectories())
            {
                dir.Delete(true);
            }
        }

        internal void Build(IWriter writer, ref bool firstPass)
        {
            if (writer.GetEntity().Properties == null)
            {
                return;
            }

            if (!writer.VerifyVisibility())
            {
                return;
            }

            writer.Create(ref firstPass);
        }
    }
}
