﻿namespace ProjectBuilder.Controllers
{
    internal interface IController
    {
        void Create();

        void Clean();
    }
}
