﻿using ProjectBuilder.Controllers;
using ProjectBuilder.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace microsoft.projectbuilder
{
    class Program
    {
        private const string CreatedFileName = "created.log";

        static void Main(string[] args)
        {
            if (args != null && args.Length == 4)
            {
                Console.WriteLine("Running ProjectBuilder:");
                //todo parse type
                var xmlFiles = args[1].Contains(";") ? args[1].Split(';') : new[] { args[1] };
                XmlSerializer ser = new XmlSerializer(typeof(ModelsMap));
                ModelsMap modelsMap = null;

                string creatorFile = Path.Combine(".", $"{args[3]}_{CreatedFileName}");
                List<CreatedFile> newFileDates = new List<CreatedFile>();

                foreach (string file in xmlFiles)
                {
                    CreatedFile fileNew = new CreatedFile
                    {
                        Name = file.Substring(file.LastIndexOf("\\") + 1, file.Length - (file.LastIndexOf("\\") + 1)),
                        ModifiedTime = File.GetLastWriteTime(file),
                        BuilderVersion = Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion
                    };
                    newFileDates.Add(fileNew);
                }

                if (File.Exists(creatorFile))
                {
                    var doc = XElement.Load(creatorFile);
                    IEnumerable<CreatedFile> existingFileDate = (from s in doc.Descendants("CreatedFile")
                                                                 select new CreatedFile()
                                                                 {
                                                                     Name = (string)s.Attribute("Name"),
                                                                     ModifiedTime = (DateTime)s.Attribute("ModifiedTime"),
                                                                     BuilderVersion = (string)s.Attribute("BuilderVersion"),
                                                                 });

                    if (existingFileDate != null && existingFileDate.Any())
                    {
                        bool exit = true;
                        foreach (string file in xmlFiles)
                        {
                            string fileName = file.Substring(file.LastIndexOf("\\") + 1, file.Length - (file.LastIndexOf("\\") + 1));
                            var oldFile = existingFileDate.First(e => e.Name == fileName);
                            var newFile = newFileDates.First(e => e.Name == fileName);

                            if (oldFile == null)
                            {
                                Console.WriteLine($"Never created Files:{fileName}");
                                exit = false;
                                break;
                            }

                            if (newFile.ModifiedTime > oldFile.ModifiedTime)
                            {
                                Console.WriteLine($"Newer Version of .xml:{fileName}");
                                exit = false;
                                break;
                            }

                            if (string.IsNullOrEmpty(newFile.BuilderVersion) || string.IsNullOrEmpty(oldFile.BuilderVersion))
                            {
                                Console.WriteLine($"No Version for Builder:{fileName}");
                                exit = false;
                                break;
                            }

                            var newVersion = new Version(newFile.BuilderVersion);
                            var oldVersion = new Version(oldFile.BuilderVersion);

                            if (newVersion > oldVersion)
                            {
                                Console.WriteLine($"Newer Version of dotnet-projectbuilder.");
                                exit = false;
                                break;
                            }

                        }

                        if (exit)
                        {
                            Console.WriteLine("Already up to date!");
                            Environment.Exit(0);
                        }
                    }
                }

                foreach (string file in xmlFiles)
                {
                    string filename = Path.Combine(file);

                    ModelsMap temp = ser.Deserialize(new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.Read)) as ModelsMap;

                    if (modelsMap == null)
                    {
                        modelsMap = temp;
                        continue;
                    }

                    if (temp == null)
                    {
                        continue;
                    }

                    if (temp.Entities != null)
                    {
                        modelsMap.Entities.AddRange(temp.Entities);
                    }

                    if (!string.IsNullOrEmpty(temp.Scope))
                    {
                        modelsMap.Scope += $",{temp.Scope}";
                    }
                }

                if (modelsMap != null)
                {
                    modelsMap.Namespace = args[0];

                    BuilderData data = new BuilderData
                    {
                        OutPath = args[2],
                        Type = args[3],
                        ModelsMap = modelsMap
                    };
                    new ControllerFactory(data).GetController().Create();
                }

                var xml = new XElement("XmlFiles", newFileDates.Select(x => new XElement("CreatedFile",
                                                       new XAttribute("Name", x.Name),
                                                       new XAttribute("ModifiedTime", x.ModifiedTime),
                                                       new XAttribute("BuilderVersion", x.BuilderVersion))));

                xml.Save(creatorFile);
            }
            else
            {
                var versionString = Assembly.GetEntryAssembly()
                                        .GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                                        .InformationalVersion
                                        .ToString();

                Console.WriteLine($"projectbuilder v{versionString}");
                Console.WriteLine("-------------");
                Console.WriteLine("\nUsage:");
                Console.WriteLine("  projectbuilder <DefaultNameSpace> <XmlPath> <OutPath> <Type>");
                return;
            }
        }
    }
}
