﻿using PluralizationService;
using PluralizationService.English;
using System.Globalization;

namespace DbXml.Util
{
  public class PluralizationServiceInstance : IPluralizer
  {
    private static readonly IPluralizationApi Api;
    private static readonly CultureInfo CultureInfo;

    static PluralizationServiceInstance()
    {
      CultureInfo = new CultureInfo("en-US");
      var builder = new PluralizationApiBuilder();
      builder.AddEnglishProvider();

      Api = builder.Build();      
    }

    public string Pluralize(string name)
    {
      return Api.Pluralize(name, CultureInfo) ?? name;
    }

    public string Singularize(string name)
    {
      return Api.Singularize(name, CultureInfo) ?? name;
    }

    public bool IsPlural(string name)
    {
      return Api.IsPlural(name, CultureInfo);
    }

    public bool IsSingular(string name)
    {
      return Api.IsSingular(name, CultureInfo);
    }
  }
}
