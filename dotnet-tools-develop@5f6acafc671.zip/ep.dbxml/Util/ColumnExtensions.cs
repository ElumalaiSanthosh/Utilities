﻿using System;

namespace DbXml.Util
{
  public static class ColumnExtensions
    {
        //public static string FriendlyCaseT(this string s)
        //{
        //    string output = string.Empty;
        //    bool lastUpper = true;

        //    foreach (char letter in s)
        //    {
        //        if (char.IsUpper(letter) && output.Length > 0 && !lastUpper)
        //        {
        //            output += " " + letter;
        //            lastUpper = true;
        //        }
        //        else
        //        {
        //            output += letter;

        //            if (!char.IsUpper(letter))
        //            {
        //                lastUpper = false;
        //            }
        //        }
        //    }

        //    return output;
        //}
    }
}
