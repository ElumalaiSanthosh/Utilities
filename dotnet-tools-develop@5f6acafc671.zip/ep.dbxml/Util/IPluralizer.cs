﻿namespace DbXml.Util
{
  public interface IPluralizer
  {
    string Pluralize(string name);
    string Singularize(string name);
    bool IsPlural(string name);
    bool IsSingular(string name);
  }
}
