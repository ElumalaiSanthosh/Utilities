﻿using System;
using System.Linq;

namespace DbXml.Util
{
    public static class StringExtension
    {
        public static string Pluralize(this string value)
        {
            if (value.Contains("_"))
            {
                var s = value.Split("_");
                int i = s.Length - 1;
                s[i] = GetPluralName(s[i]);
                return string.Join("_", s);
            }
            
            return GetPluralName(value);
        }

        private static string GetPluralName(String value)
        {
            PluralizationServiceInstance ps = new PluralizationServiceInstance();
            string test = ps.Pluralize(value);

            if (ps.IsSingular(value))
                return ps.Pluralize(value);

            return value;
        }
        public static string FriendlyCase(this string inupt)
        {
            var frags = inupt.Split('_');
            for (int i = 0; i < frags.Length; i++)
            {
                frags[i] = frags[i].First().ToString().ToUpper() + frags[i].Substring(1);
            }
            return string.Join(string.Empty, frags);
        }

        //public static string FriendlyCase(this string input)
        //{
        //    switch (input)
        //    {
        //        case null: throw new ArgumentNullException(nameof(input));
        //        case "": throw new ArgumentException($"{nameof(input)} cannot be empty", nameof(input));
        //        default: return input.First().ToString().ToUpper() + input.Substring(1);
        //    }
        //}
    }
}
