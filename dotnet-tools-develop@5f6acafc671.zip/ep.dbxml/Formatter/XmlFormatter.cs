﻿using System.Collections.Generic;
using System.Text;
using System.Linq;
using DbXml.Util;
using DbXml.Entities;

namespace DbXml.Formatter
{
    public static class XmlFormatter
    {
        public static string FormatXml(this DataTable table)
        {
            StringBuilder s = new StringBuilder();

            s.Append($"\t<Entity Name=\"{table.Name}\" PluralName=\"{table.Name.Pluralize()}\" Table=\"{table.DbName}\" Schema=\"{table.Schema}\" Visibility=\"{table.Visibility}\" HasDataset=\"true\">\r\n");

            if (table.Columns != null && table.Columns.Count > 0)
            {
                foreach (DataColumn column in table.Columns)
                {
                    s.Append(column.Format());
                }
            }

            if (table.ForeignTables != null && table.ForeignTables.Count > 0)
            {
                foreach (KeyValuePair<string, Relation> t in table.ForeignTables)
                {
                    if (table.PrimaryKey != null && table.PrimaryKey.Count > 0)
                    {
                        foreach (DataColumn k in table.PrimaryKey)
                        {
                            s.Append("\t\t<Relationship Name=\"" + t.Value.FriendlyName + "\" JsonName=\"" + t.Value.JsonName + "\" PluralName=\"" + t.Value.PluralName + "\" RelatedEntity=\"" + t.Value.FriendlyName + "\" RelatedProperty=\"" + t.Value.RelatedProperty + "\" PropertyName=\"" + k.Name + "\" Type=\"" + k.EntityType() + "\" Cardinality=\"OneToMany\" LazyLoad=\"true\" />\r\n");
                        }
                    }
                }
            }

            if (table.OneToOneTables != null && table.OneToOneTables.Count > 0)
            {
                foreach (KeyValuePair<string, string> t in table.OneToOneTables)
                {
                    if (table.PrimaryKey != null && table.PrimaryKey.Count > 0)
                    {
                        DataColumn k = table.Columns.Where(e => e.Name == t.Value).ToList().First();
                        s.Append("\t\t<Relationship Name=\"" + t.Key + "\" RelatedEntity=\"" + t.Key + "\" RelatedProperty=\"" + k.Name+ "\" PropertyName=\"" + t.Value + "\" Type=\"" + k.EntityType() + "\" Cardinality=\"OneToOne\" LazyLoad=\"true\" />\r\n");                        
                    }
                }
            }

            if (table.UniqueKeys != null && table.UniqueKeys.Count > 0)
            {
                foreach (KeyValuePair<string, string> t in table.UniqueKeys)
                {
                    s.Append("\t\t<UniqueKey Name=\"" + t.Key + "\" Properties=\"" + t.Value + "\" />\r\n");
                }
            }

            if (table.Commands != null && table.Commands.Any())
            {
                foreach (string command in table.Commands)
                {
                    s.Append("\t\t<Command Name=\"" + command + "\" />\r\n");
                }
            }

            s.Append("\t</Entity>");

            return s.ToString();
        }

        public static string Format(this DataColumn column)
        {
            string s = "\t\t<Property Name=\"" + column.Name + "\" Type=\"" + column.EntityType() + "\" DbName=\"" + column.DbName;

            if (column.MaxLength > 0)
            {
                s += "\" Size=\"" + column.MaxLength;
            }

            if (!column.PrimaryKey && column.DefaultValue != null && column.DefaultValue.Length > 0)
            {
                s += "\" NullValue=\"" + column.DefaultValue;
            }

            if (column.PrimaryKey)
            {
                s += "\" PrimaryKey=\"" + column.PrimaryKey.ToString().ToLower();
            }

            if (column.IsDbGenerated)
            {
                s += "\" IsDbGenerated=\"" + column.IsDbGenerated.ToString().ToLower();
            }
            
            return s + "\" AllowNull=\"" + column.Nullable.ToString().ToLower() + "\" Ordinal=\"" + column.Ordinal + "\" />\r\n";
        }
    }
}
