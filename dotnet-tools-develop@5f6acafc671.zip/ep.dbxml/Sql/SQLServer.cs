﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Data.SqlClient;
using DbXml.Util;
using DbXml.Entities;

namespace DbXml.Sql
{
    class SqlServer
    {
        public static List<DataTable> GetTables(string connectionString, string databaseName)
        {
            //string connectionString = "Server=" + server + ";Database=" + databaseName + ";Trusted_Connection=true";

            List<DataTable> listTables = null;

            using (var conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand command = new SqlCommand("SELECT COLUMNS.TABLE_NAME, ORDINAL_POSITION, COLUMN_NAME, IS_NULLABLE,DATA_TYPE, " +
                                                    "CHARACTER_MAXIMUM_LENGTH, COLUMN_DEFAULT, " +
                                                    "COLUMNPROPERTY(object_id(COLUMNS.TABLE_NAME), COLUMN_NAME, 'IsIdentity'), " +
                                                    "TABLES.TABLE_SCHEMA, (CASE INFORMATION_SCHEMA.TABLES.TABLE_TYPE WHEN 'VIEW' THEN 'readonly' " +
                                                    "ELSE sEXP.value END) AS Visibility " +
                                                    "FROM " + databaseName + ".INFORMATION_SCHEMA.COLUMNS " +
                                                    "JOIN " + databaseName + ".INFORMATION_SCHEMA.TABLES ON (COLUMNS.TABLE_NAME = TABLES.TABLE_NAME)" +
                                                    "LEFT JOIN sys.extended_properties AS sEXP ON(sEXP.major_id = OBJECT_ID(TABLES.TABLE_NAME) " +
                                                    "AND sEXP.name = 'MS_Description') " +
                                                    "WHERE TABLES.TABLE_NAME <> 'sysdiagrams' " +
                                                    "ORDER BY TABLE_NAME, ORDINAL_POSITION", conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        string lastTable = "";
                        DataTable table = null;
                        List<string> keys = null;

                        while (reader.Read())
                        {
                            if (!lastTable.Equals(reader.GetString(0).Trim()))
                            {
                                if (!reader.IsDBNull(9) && reader.GetString(9).Contains("system"))
                                {
                                    continue;
                                }

                                if (listTables == null)
                                {
                                    listTables = new List<DataTable>();
                                }
                                else
                                {
                                    listTables.Add(table);
                                }

                                lastTable = reader.GetString(0).Trim();
                                ICollection<string> _Commands;

                                table = new DataTable
                                {
                                    DbName = reader.GetString(0),
                                    Schema = reader.GetString(8),
                                    Visibility = reader.IsDBNull(9) ? GetVisibility("public", out _Commands) : GetVisibility(reader.GetString(9), out _Commands),
                                    Commands = _Commands,
                                    ForeignTables = GetOneToManyTables(reader.GetString(0), connectionString),
                                    OneToOneTables = GetOneToOneTables(reader.GetString(0), connectionString),
                                    UniqueKeys = getUniqueKey(reader.GetString(0), connectionString)
                                };
                                keys = getPrimaryKey(table.DbName, connectionString);
                            }

                            var column = new DataColumn
                            {
                                Ordinal = reader.GetInt32(1),
                                DbName = reader.GetString(2),
                                Nullable = reader.GetString(3).Equals("YES"),
                                DatabaseType = reader.GetString(4),
                                MaxLength = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
                                DefaultValue = reader.IsDBNull(6) ? null : fixDefaultValue(reader.GetString(6)),
                                IsDbGenerated = reader.GetInt32(7) != 0
                            };


                            if (keys != null && keys.Contains(column.DbName))
                            {
                                if (column.IsDbGenerated) table.Identity = column.IsDbGenerated;
                                column.PrimaryKey = true;
                                table.PrimaryKey.Add(column);
                            }

                            table?.Columns.Add(column);
                        }

                        if (listTables == null)
                        {
                            listTables = new List<DataTable>();
                        }

                        listTables.Add(table);
                    }
                }
            }
            return (listTables);
        }

        static List<string> getPrimaryKey(string tableName, string connectionString)
        {
            List<string> listKeys = null;

            using (var conn = new SqlConnection(connectionString))
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("SELECT Col.COLUMN_NAME from ");
                sql.Append("INFORMATION_SCHEMA.TABLE_CONSTRAINTS Tab, ");
                sql.Append("INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE Col ");
                sql.Append("WHERE ");
                sql.Append("Col.Constraint_Name = Tab.Constraint_Name ");
                sql.Append("AND Col.Table_Name = Tab.Table_Name ");
                sql.Append("AND Constraint_Type = 'PRIMARY KEY' ");
                sql.Append("AND Col.Table_Name = '" + tableName + "'");

                conn.Open();
                SqlCommand command = new SqlCommand(sql.ToString(), conn);

                /* Get the rows and display on the screen! 
                 * This section of the code has the basic code
                 * that will display the content from the Database Table
                 * on the screen using an SqlDataReader. */

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        listKeys = new List<string>();
                        while (reader.Read())
                        {
                            listKeys.Add(reader.GetString(0));
                        }
                    }
                }
            }

            return (listKeys);
        }

        static IDictionary<string, string> getUniqueKey(string tableName, string connectionString)
        {
            IDictionary<string, string> uniqueKeys = null;

            using (var conn = new SqlConnection(connectionString))
            {
                StringBuilder sql = new StringBuilder();

                sql.Append("SELECT TC.Constraint_Name, CC.Column_Name ");
                sql.Append("FROM information_schema.table_constraints TC ");
                sql.Append("INNER JOIN information_schema.constraint_column_usage CC on TC.Constraint_Name = CC.Constraint_Name ");
                sql.Append("WHERE ");
                sql.Append("TC.constraint_type = 'Unique' ");
                sql.Append("AND TC.TABLE_NAME = '" + tableName + "' ");
                sql.Append("order by TC.Constraint_Name ");

                conn.Open();
                SqlCommand command = new SqlCommand(sql.ToString(), conn);

                /* Get the rows and display on the screen! 
                 * This section of the code has the basic code
                 * that will display the content from the Database Table
                 * on the screen using an SqlDataReader. */
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        string lastTable = string.Empty;
                        uniqueKeys = new Dictionary<string, string>();

                        while (reader.Read())
                        {
                            if (string.IsNullOrEmpty(lastTable) ||
                                lastTable != reader.GetString(0))
                            {
                                lastTable = reader.GetString(0);
                                uniqueKeys.Add(reader.GetString(0), reader.GetString(1));
                            }
                            else
                            {
                                uniqueKeys[reader.GetString(0)] += "," + reader.GetString(1);
                            }
                        }
                    }
                }
            }

            return (uniqueKeys);
        }

        static IDictionary<string, Relation> GetOneToManyTables(string tableName, string connectionString)
        {
            IDictionary<string, Relation> foreignTables = null;

            using (var conn = new SqlConnection(connectionString))
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("SELECT ");
                sql.Append("DISTINCT(FK.TABLE_NAME), CU.COLUMN_NAME ");
                sql.Append("FROM ");
                sql.Append("INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS C ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS FK ");
                sql.Append("ON C.CONSTRAINT_NAME = FK.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS PK ");
                sql.Append("ON C.UNIQUE_CONSTRAINT_NAME = PK.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE CU ");
                sql.Append("ON C.CONSTRAINT_NAME = CU.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN ( ");
                sql.Append("SELECT ");
                sql.Append("i1.TABLE_NAME, ");
                sql.Append("i2.COLUMN_NAME ");
                sql.Append("FROM ");
                sql.Append("INFORMATION_SCHEMA.TABLE_CONSTRAINTS i1 ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE i2 ");
                sql.Append("ON i1.CONSTRAINT_NAME = i2.CONSTRAINT_NAME ");
                sql.Append("WHERE ");
                sql.Append("i1.CONSTRAINT_TYPE = 'PRIMARY KEY' ");
                sql.Append(") PT ");
                sql.Append("ON PT.TABLE_NAME = PK.TABLE_NAME ");
                sql.Append("WHERE PK.TABLE_NAME = '" + tableName + "'");

                Debug.WriteLine(sql.ToString());
                conn.Open();
                SqlCommand command = new SqlCommand(sql.ToString(), conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        foreignTables = new Dictionary<string, Relation>();
                        while (reader.Read())
                        {
                            if (!reader.GetString(0).Equals(tableName) && !foreignTables.ContainsKey(reader.GetString(0).FriendlyCase()))
                            {
                                Relation r = new Relation(reader.GetString(0), reader.GetString(1).FriendlyCase());                                
                                foreignTables.Add(r.FriendlyName, r);
                            }
                        }
                    }
                }
            }

            return (foreignTables);
        }

        static IDictionary<string, string> GetOneToOneTables(string tableName, string connectionString)
        {
            IDictionary<string, string> oneToOne = null;

            using (var conn = new SqlConnection(connectionString))
            {
                StringBuilder sql = new StringBuilder();
                sql.Append("SELECT ");
                sql.Append("DISTINCT(PK.TABLE_NAME), CU.COLUMN_NAME ");
                sql.Append("FROM ");
                sql.Append("INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS C ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS FK ");
                sql.Append("ON C.CONSTRAINT_NAME = FK.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.TABLE_CONSTRAINTS PK ");
                sql.Append("ON C.UNIQUE_CONSTRAINT_NAME = PK.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE CU ");
                sql.Append("ON C.CONSTRAINT_NAME = CU.CONSTRAINT_NAME ");
                sql.Append("INNER JOIN ( ");
                sql.Append("SELECT ");
                sql.Append("i1.TABLE_NAME, ");
                sql.Append("i2.COLUMN_NAME ");
                sql.Append("FROM ");
                sql.Append("INFORMATION_SCHEMA.TABLE_CONSTRAINTS i1 ");
                sql.Append("INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE i2 ");
                sql.Append("ON i1.CONSTRAINT_NAME = i2.CONSTRAINT_NAME ");
                sql.Append("WHERE ");
                sql.Append("i1.CONSTRAINT_TYPE = 'PRIMARY KEY' ");
                sql.Append(") PT ");
                sql.Append("ON PT.TABLE_NAME = PK.TABLE_NAME ");
                sql.Append("WHERE FK.TABLE_NAME = '" + tableName + "'");

                Debug.WriteLine(sql.ToString());
                conn.Open();
                SqlCommand command = new SqlCommand(sql.ToString(), conn);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        oneToOne = new Dictionary<string, string>();
                        while (reader.Read())
                        {
                            if (!reader.GetString(0).Equals(tableName) && !oneToOne.ContainsKey(reader.GetString(0).FriendlyCase()))
                            {
                                oneToOne.Add(reader.GetString(0).FriendlyCase(), reader.GetString(1).FriendlyCase());
                            }
                        }
                    }
                }
            }

            return (oneToOne);
        }

        static string GetVisibility(string s, out ICollection<string> commands)
        {
            IList<string> result = new List<string>();

            if (s.Contains("internal"))
            {
                commands = null;
                return "internal";
            }

            if (s.Contains("getmany") || s.Contains("get") || s == "public")
            {
                result.Add("get");
            }

            if (!s.Contains("readonly"))
            {
                if (s.Contains("delete") || s == "public")
                {
                    result.Add("delete");
                }
                if (s.Contains("create") || s == "public")
                {
                    result.Add("create");
                }
                if (s.Contains("update") || s == "public")
                {
                    result.Add("update");
                }
            }

            commands = result;
            return s.Contains("public") ? "public" : "readonly";
        }

        static string fixDefaultValue(string s)
        {
            s = s.Replace("'", "");
            s = s.Replace("(", "");
            s = s.Replace(")", "");

            return s;
        }
    }
}
