﻿using System.Collections.Generic;
using DbXml.Entities;
using DbXml.Util;
using Npgsql;

namespace DbXml.Sql
{
    class PostgresSql
    {
        public static List<DataTable> GetTables(string connectionString, string databaseName, string schema)
        {   
            List<DataTable> listTables = null;

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                // quite complex sql statement
                string sql = $"SELECT table_name, ordinal_position, column_name, is_nullable, data_type, character_maximum_length, column_default, is_identity, table_schema, is_updatable FROM information_schema.columns WHERE table_schema = '{schema}' ORDER BY table_name, ordinal_position";

                // Define a query
                NpgsqlCommand command = new NpgsqlCommand(sql, conn);

                // Execute the query and obtain a result set
                using (NpgsqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        string lastTable = "";
                        DataTable table = null;
                        List<string> keys = null;

                        while (reader.Read())
                        {
                            if (!lastTable.Equals(reader.GetString(0).Trim()))
                            {
                                //if (!reader.IsDBNull(9) && reader.GetString(9).Contains("system"))
                                //{
                                //    continue;
                                //}

                                if (listTables == null)
                                {
                                    listTables = new List<DataTable>();
                                }
                                else
                                {
                                    listTables.Add(table);
                                }

                                lastTable = reader.GetString(0).Trim();

                                table = new DataTable
                                {
                                    DbName = reader.GetString(0),
                                    Schema = reader.GetString(8),
                                    Visibility = GetVisibility(reader.GetString(9).Equals("YES") ? "public" : "readonly", out var commands),//reader.IsDBNull(9) ? GetVisibility("public", out _Commands) : GetVisibility(reader.GetBoolean(9) ? "public" : "readonly", out _Commands),
                                    Commands = commands,
                                    ForeignTables = GetOneToManyTables(schema, reader.GetString(0), connectionString),
                                    OneToOneTables = GetOneToOneTables(schema, reader.GetString(0), connectionString),
                                    UniqueKeys = GetUniqueKey(reader.GetString(0), connectionString)
                                };
                                keys = GetPrimaryKey(schema, table.DbName, connectionString);
                            }

                            string defaultValue = reader.IsDBNull(6) ? null : FixDefaultValue(reader.GetString(6));

                            var column = new DataColumn
                            {
                                Ordinal = reader.GetInt32(1),
                                DbName = reader.GetString(2),
                                Nullable = reader.GetString(3).Equals("YES"),
                                DatabaseType = ConvertDbType(reader.GetString(4)),
                                MaxLength = reader.IsDBNull(5) ? 0 : reader.GetInt32(5),
                                DefaultValue = defaultValue,
                                IsDbGenerated = reader.GetString(7).Equals("YES") || !string.IsNullOrEmpty(defaultValue) && defaultValue.StartsWith("uuid")
                            };

                            if (keys != null && keys.Contains(column.DbName))
                            {
                                if (column.IsDbGenerated) table.Identity = column.IsDbGenerated;
                                {
                                    column.PrimaryKey = true;
                                }

                                table.PrimaryKey.Add(column);
                            }

                            table?.Columns.Add(column);
                        }

                        if (listTables == null)
                        {
                            listTables = new List<DataTable>();
                        }

                        listTables.Add(table);
                    }
                }

                conn.Close();
            }

            return listTables;
        }

        private static string ConvertDbType(string dbType)
        {
            switch (dbType)
            {
                case "character":
                    return ("CHAR");
                case "integer":
                    return ("INT");
                case "timestamp without time zone":
                    return ("DATETIME");
                case "character varying":
                    return ("VARCHAR");
                case "boolean":
                    return ("BIT");
                case "numeric":
                    return ("DECIMAL");
                case "bigint":
                    return "INT64";
                case "uuid":
                    return "UNIQUEIDENTIFIER";
                default:
                    return (dbType);
            }
        }

        private static List<string> GetPrimaryKey(string schema, string tableName, string connectionString)
        {
            List<string> listKeys = null;

            string sql = $"SELECT a.attname FROM pg_index i JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey) WHERE  i.indrelid = '{schema}.{tableName}'::regclass AND i.indisprimary";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                using (NpgsqlDataReader reader = new NpgsqlCommand(sql, conn).ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        listKeys = new List<string>();
                        while (reader.Read())
                        {
                            listKeys.Add(reader.GetString(0));
                        }
                    }
                }
            }

            return listKeys;
        }

        private static IDictionary<string, Relation> GetOneToManyTables(string schema, string tableName, string connectionString)
        {
            IDictionary<string, Relation> foreignTables = null;
            string sql = @"SELECT
                tc.table_name,
                ccu.column_name AS foreign_column_name,
                tc.constraint_type
                FROM information_schema.table_constraints AS tc
                JOIN information_schema.key_column_usage AS kcu
                ON tc.constraint_name = kcu.constraint_name
                AND tc.table_schema = kcu.table_schema
                JOIN information_schema.constraint_column_usage AS ccu
                ON ccu.constraint_name = tc.constraint_name
                AND ccu.table_schema = tc.table_schema
                WHERE tc.table_schema = '" + schema + "' AND tc.constraint_type = 'FOREIGN KEY' AND ccu.table_name = '" + tableName + "';";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                using (NpgsqlDataReader reader = new NpgsqlCommand(sql, conn).ExecuteReader())
                {
                    {
                        if (reader.HasRows)
                        {
                            foreignTables = new Dictionary<string, Relation>();
                            while (reader.Read())
                            {
                                if (!reader.GetString(0).Equals(tableName) &&
                                    !foreignTables.ContainsKey(reader.GetString(0).FriendlyCase()))
                                {
                                    Relation r = new Relation(reader.GetString(0), reader.GetString(1).FriendlyCase());
                                    foreignTables.Add(r.FriendlyName, r);

                                    //foreignTables.Add(reader.GetString(0).FriendlyCase(), reader.GetString(1).FriendlyCase());
                                }
                            }
                        }
                    }
                }

                return foreignTables;
            }
        }

        private static IDictionary<string, string> GetOneToOneTables(string schema, string tableName, string connectionString)
        {
            IDictionary<string, string> oneToOne = null;

            string sql = @"SELECT
                                ccu.table_name AS foreign_table_name,
                                kcu.column_name
                            FROM 
                                information_schema.table_constraints AS tc 
                                JOIN information_schema.key_column_usage AS kcu
                                  ON tc.constraint_name = kcu.constraint_name
                                  AND tc.table_schema = kcu.table_schema
                                JOIN information_schema.constraint_column_usage AS ccu
                                  ON ccu.constraint_name = tc.constraint_name
                                  AND ccu.table_schema = tc.table_schema
                            WHERE tc.table_schema = '"+ schema + "' AND tc.constraint_type = 'FOREIGN KEY' AND tc.table_name='" + tableName + "'";

            using (NpgsqlConnection conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                /* Get the rows and display on the screen! 
                 * This section of the code has the basic code
                 * that will display the content from the Database Table
                 * on the screen using an SqlDataReader. */

                using (NpgsqlDataReader reader = new NpgsqlCommand(sql, conn).ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        oneToOne = new Dictionary<string, string>();
                        while (reader.Read())
                        {
                            if (!reader.GetString(0).Equals(tableName) && !oneToOne.ContainsKey(reader.GetString(0).FriendlyCase()))
                            {
                                oneToOne.Add(reader.GetString(0).FriendlyCase(), reader.GetString(1).FriendlyCase());
                            }
                        }
                    }
                }
            }

            return oneToOne;
        }

        private static IDictionary<string, string> GetUniqueKey(string tableName, string connectionString)
        {
            return null;
        }

        private static string GetVisibility(string s, out ICollection<string> commands)
        {
            IList<string> result = new List<string>();

            if (s.Contains("internal"))
            {
                commands = null;
                return ("internal");
            }

            if (s.Contains("getmany") || s.Contains("get") || s == "public")
            {
                result.Add("get");
            }

            if (!s.Contains("readonly"))
            {
                if (s.Contains("delete") || s == "public")
                {
                    result.Add("delete");
                }
                if (s.Contains("create") || s == "public")
                {
                    result.Add("create");
                }
                if (s.Contains("update") || s == "public")
                {
                    result.Add("update");
                }
            }

            commands = result;
            return s.Contains("public") ? "public" : "readonly";
        }

        private static string FixDefaultValue(string s)
        {
            s = s.Replace("'", "");
            s = s.Replace("(", "");
            s = s.Replace(")", "");

            return s;
        }
    }
}
