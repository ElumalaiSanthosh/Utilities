﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using DbXml.Formatter;
using DbXml.Sql;

namespace DbXml
{
    class Program
    {
        internal static string server = "(Local)";
        internal static string databaseName = "org";
        internal static string fileName = "C:\\temp\\" + databaseName + ".xml";
        internal static string scope = "TestScope";

        static void Generate()
        {
            //string connectionString = "Server=" + server + ";Database=" + databaseName + ";Trusted_Connection=true";
            //List<DataTable> tables = SqlServer.GetTables(connectionString, databaseName);

            string connectionString = $"Server={"127.0.0.1"};Port={"5432"};User Id={"vistaua"};Password={"test"};Database={databaseName};";
            //string connectionString = $"Server={"smartpo-pos-dev.c9qfyosg3dv8.us-west-2.rds.amazonaws.com"};Port={"5432"};User Id={"vistaua"};Password={"test"};Database={databaseName};";
            //string connectionString = $"Host={"db-pa-dev1.adc-np.ep.com"};Port={"5432"};Username={"patxs_write"};Password={"o4mNaKrLDyyX"};Database={databaseName};";
            List<string> schemas = new List<string> { "pals" };

            List<DataTable> tables = new List<DataTable>();
            foreach (string s in schemas)
            {
                tables.AddRange(PostgresSql.GetTables(connectionString, databaseName, s));
            }

            using (StreamWriter outputFile = new StreamWriter(fileName))
            {
                outputFile.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                outputFile.WriteLine("<ModelsMap Version=\"1\" Scope=\"" + scope + "\">");

                foreach (DataTable table in tables)
                {
                    outputFile.WriteLine(table.FormatXml());
                }

                outputFile.WriteLine("</ModelsMap>");
            }
        }

        static void Main(string[] args)
        {
            if (args == null || args.Length < 4)
            {
                var versionString = Assembly.GetEntryAssembly()
                                        .GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                                        .InformationalVersion
                                        .ToString();

                Console.WriteLine($"dotnet-dbxml v{versionString}");
                Console.WriteLine("-------------");
                Console.WriteLine("\nUsage:");
                Console.WriteLine("  dotnet-dbxml <DefaultNameSpace> <XmlPath> <OutPath> <Type>");
                return;
            }

            server = args[0];
            databaseName = args[1];
            fileName = args[2];
            scope = args[3];

            Generate();
        }
    }
}
