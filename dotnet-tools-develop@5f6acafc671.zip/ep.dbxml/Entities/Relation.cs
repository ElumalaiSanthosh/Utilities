﻿using DbXml.Util;
using System;
using System.Collections.Generic;
using System.Text;

namespace DbXml.Entities
{
    public class Relation
    {
        public Relation(string tableName, string relatedProperty)
        {
            TableName = tableName;
            RelatedProperty = relatedProperty;
        }

        public string TableName { get; }

        public string RelatedProperty { get; }

        public string JsonName
        {
            get
            {
                return TableName.Pluralize();
            }
        }

        public string PluralName
        {
            get
            {
                return FriendlyName.Pluralize();
            }
        }

        public string FriendlyName
        {
            get
            {
                return TableName.FriendlyCase();
            }
        }
    }
}
