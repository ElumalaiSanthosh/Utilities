﻿using System.Collections.Generic;
using DbXml.Entities;
using DbXml.Util;

namespace DbXml
{
    public class DataTable
    {
        public DataTable()
        {
            PrimaryKey = new HashSet<DataColumn>();
            Columns = new HashSet<DataColumn>();
        }

        public bool Identity { set; get; }

        public string Name => DbName.FriendlyCase();

        public string DbName { set; get; }

        public string Schema { set; get; }

        public ICollection<DataColumn> PrimaryKey { set; get; }

        public ICollection<DataColumn> Columns { set; get; }

        public IDictionary<string, Relation> ForeignTables { set; get; }

        public IDictionary<string, string> OneToOneTables { set; get; }

        public IDictionary<string, string> UniqueKeys { set; get; }

        public ICollection<string> Commands { set; get; }

        public string FriendlyName => PropertyName.FriendlyCase();

        public string PropertyName => Name.Replace("_","");

        public string Visibility { get; set; }
    }
}
