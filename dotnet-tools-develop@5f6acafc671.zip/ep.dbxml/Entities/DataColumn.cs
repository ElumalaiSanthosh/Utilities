﻿using DbXml.Util;

namespace DbXml
{
  public class DataColumn
    {
        public int Ordinal { set; get; }

        public string Name => DbName.FriendlyCase();

        public string DbName { set; get; }

        public bool Nullable { set; get; }

        public int MaxLength { set; get; }

        public string DefaultValue { set; get; }

        public bool IsDbGenerated { set; get; }

        public bool PrimaryKey { set; get; }

        public string DatabaseType { set; get; }
         
        public string ConvertDbType()
        {
            switch(DatabaseType.ToLower())
            {
                case "char":
                    return ("Char");
                case "int":
                    return ("Int");
                case "smallint":
                    return ("SmallInt");
                case "datetime":
                    return ("DateTime");
                case "date":
                    return ("DateTime");
                case "image":
                    return ("Image");                    
                case "nvarchar":
                    return ("NVarChar");
                case "varchar":
                    return ("VarChar");                
                case "smalldatetime":
                    return ("DateTime");
                case "float":
                    return ("Float");
                case "decimal":
                    return ("Decimal");
                case "uniqueidentifier":
                case "uuid":
                    return ("uniqueidentifier");
                default:
                    return (DatabaseType);
            }           
        }

        public string EntityType()
        {   
            switch (ConvertDbType().ToUpper())
            {                
                case "CHAR":
                    return ("string");
                case "NVARCHAR":
                    return ("string");
                case "VARCHAR":
                    return ("string");
                case "SMALLINT":
                    return ("Int16");
                case "SMALLDATETIME":
                    return ("DateTime");
                case "DATETIME":
                    return ("DateTime");
                case "FLOAT":
                    return ("double");
                case "IMAGE":
                    return ("byte[]");
                case "INT":
                    return ("Int32");
                case "INT64":
                    return ("Int64");
                case "BIT":
                    return ("bool");
                case "DECIMAL":
                    return ("decimal");
                case "UNIQUEIDENTIFIER":
                    return ("Guid");
                default:
                    return ("string");
            }
        }
    }
}
