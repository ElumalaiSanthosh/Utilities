﻿using ApiService.Commons.CacheService;
using ApiService.Commons.Events;
using ApiService.Commons.Rest;
using ApiService.Repositories;

using LedgerService.Models.Dtos;
using LedgerService.Models.Enumerations;
using LedgerService.Web.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Data;

namespace LedgerService.Services.Tests
{

    [TestClass]
    public partial class GlTransactionServiceTests
    {
        Mock<IDbTransaction> transaction;
        GlTransactionService service;
        Mock<GlTransaction> mockDto;
        [TestInitialize]
        public void Setup()
        {
            transaction = new Mock<IDbTransaction>();
            service = new GlTransactionService(new Mock<IConfiguration>().Object, new Mock<IServiceProvider>().Object,
                new Mock<IRepository<GlTransaction>>().Object, new Mock<IApiCache>().Object, new Mock<IProducerWrapper>().Object);
            mockDto = new Mock<GlTransaction>();
            mockDto.SetupAllProperties();
        }

        #region Validate JE Recurring type
        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Recurring End Date is a Mandatory Field")]
        public void ValidateJERecurringTypeDto_NullEndDate()
        {
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            mockDto.Object.RecurrenceEndDate = null;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Recurring End Date is a Mandatory Field")]
        public void ValidateJERecurringTypeDto_DefaultEndDate()
        {
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            mockDto.Object.RecurrenceEndDate = default(DateTime);
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Recurring Start Date is a Mandatory Field")]
        public void ValidateJERecurringTypeDto_NullStartDate()
        {
            mockDto.Object.RecurrenceEndDate = DateTime.Now;
            mockDto.Object.RecurrenceStartDate = null;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Recurring Start Date is a Mandatory Field")]
        public void ValidateJERecurringTypeDto_DefaultStartDate()
        {
            mockDto.Object.RecurrenceEndDate = DateTime.Now;
            mockDto.Object.RecurrenceStartDate = default(DateTime);
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid Recurring Type")]
        public void ValidateJERecurringTypeDto_InValidType()
        {
            mockDto.Object.RecurrenceType = "XXXXXX";
            mockDto.Object.RecurrenceEndDate = DateTime.Now.AddDays(2);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid recurring date range")]
        public void ValidateJERecurringTypeDto_InValidDaily()
        {
            mockDto.Object.RecurrenceType = RecurringType.Daily.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Now;
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        public void ValidateJERecurringTypeDto_ValidDaily()
        {
            mockDto.Object.RecurrenceType = RecurringType.Daily.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddDays(2);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid recurring date range")]
        public void ValidateJERecurringTypeDto_InValidWeekly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Weekly.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Now.AddDays(5);
            mockDto.Object.RecurrenceStartDate = DateTime.Today;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        public void ValidateJERecurringTypeDto_ValidWeekly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Weekly.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddDays(14);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        //[TestMethod]
        public void ValidateJERecurringTypeDto_ValidMonthly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Monthly.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(5);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);

            //More difference is more than 1 year
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(55);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);

            //Same Year
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(1);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid recurring date range")]
        public void ValidateJERecurringTypeDto_InValidMonthly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Monthly.ToString();
            mockDto.Object.RecurrenceStartDate = new DateTime(2019, 8, 27);
            mockDto.Object.RecurrenceEndDate = mockDto.Object.RecurrenceStartDate.Value.AddDays(29);
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        //[TestMethod]
        public void ValidateJERecurringTypeDto_ValidQuarterly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Quarterly.ToString();
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(6);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);

            //More difference is more than 1 year
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(54);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);

            //Same Year
            mockDto.Object.RecurrenceEndDate = DateTime.Today.AddMonths(3);
            mockDto.Object.RecurrenceStartDate = DateTime.Now;
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid recurring date range")]
        public void ValidateJERecurringTypeDto_InValidQuarterly()
        {
            mockDto.Object.RecurrenceType = RecurringType.Quarterly.ToString();
            mockDto.Object.RecurrenceStartDate = new DateTime(2019, 8, 27);
            mockDto.Object.RecurrenceEndDate = mockDto.Object.RecurrenceStartDate.Value.AddMonths(2);
            service.ValidateJERecurringTypeDto(mockDto.Object);
        }
        #endregion

        #region Validate JE Dto
        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid Subsystem Type")]
        public void ValidateDto_JE_InvalidSubsystemType()
        {
            mockDto.Object.SubsystemType = "XXXX";
            service.ValidateDto(mockDto.Object, transaction.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Invalid JE Transaction Type")]
        public void ValidateDto_JE_InvaldTransactionType()
        {
            mockDto.Object.SubsystemType = "JE";
            mockDto.Object.GlTransactionType = "XXXX";
            service.ValidateDto(mockDto.Object, transaction.Object);
        }

        [TestMethod]
        [ExpectedException(typeof(ApiRestException), "Reversal date is a Mandatory Field")]
        public void ValidateDto_JE_InvaldReversalDate()
        {
            mockDto.Object.SubsystemType = "JE";
            mockDto.Object.GlTransactionType = TransactionType.REVERSING.ToString();
            mockDto.Object.ReversalDate = null;
            service.ValidateDto(mockDto.Object, transaction.Object);
        }

        [TestMethod]
        public void ValidateDto_JE_ValidDto()
        {
            mockDto.Object.SubsystemType = "JE";
            mockDto.Object.GlTransactionType = "standard";
            mockDto.Object.ReversalDate = null;
            Assert.IsTrue(service.ValidateDto(mockDto.Object, transaction.Object));
        }
        #endregion
    }
}
