﻿using ApiService.Commons.CacheService;
using ApiService.Commons.DataStore;
using ApiService.Commons.Rest;
using ApiService.Repositories;
using ApiService.Web;
using LedgerService.Models.Dtos;
using LedgerService.Web.Controllers;
using LedgerService.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Tests.Services
{
    [TestClass]
    public partial class BatchCommandService
    {
        IBatchService service;
        Mock<Batch> mockDto;
        Mock<IRepository<Batch>> repositoryProvider;
        Mock<IConfiguration> config;
        BatchesController controller;

        [TestInitialize]
        public void Setup()
        {
            config = new Mock<IConfiguration>();
            repositoryProvider = new Mock<IRepository<Batch>>();
            service = new BatchService(new Mock<IConfiguration>().Object, new Mock<IServiceProvider>().Object, repositoryProvider.Object, null, null);
            var apiCacheService = new Mock<IApiCache>();
            controller = new BatchesController(config.Object, service, apiCacheService.Object);
            mockDto = new Mock<Batch>();
            mockDto.SetupAllProperties();
            List<string> resultOut = new List<string>();
            mockDto.Setup(x => x.IsValid(out resultOut)).Returns(true);
        }

        [TestMethod]
        public void BeforePost_EmptyName()
        {
            mockDto.Object.Name = string.Empty;
            var result = controller.PostAsync(mockDto.Object);
            var noResult = result.Result as NotAcceptableObjectResult;
            Assert.AreEqual(((ApiRestExceptionDto)noResult.Value).Message, "Batch Name is a Mandatory Field.");
        }

        [TestMethod]
        public void BeforePost_WithEmptySpaceName()
        {
            mockDto.Object.Name = "      ";
            var result = controller.PostAsync(mockDto.Object);
            var noResult = result.Result as NotAcceptableObjectResult;
            Assert.AreEqual(((ApiRestExceptionDto)noResult.Value).Message, "Batch Name is a Mandatory Field.");
        }

        [TestMethod]
        public void BeforePost_LongerName()
        {
            mockDto.Object.Name = "Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name Invalid Name";
            var result = controller.PostAsync(mockDto.Object);
            var noResult = result.Result as NotAcceptableObjectResult;
            Assert.AreEqual(((ApiRestExceptionDto)noResult.Value).Message, "Batch Name cannot be longer than 50 characters.");
        }

        [TestMethod]
        public void BeforePost_NameExist()
        {
            var lookupTask = Task<Batch>.Factory.StartNew(() => new Batch());
            repositoryProvider.SetupSequence(x => x.ReadAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);
            mockDto.Object.Name = "Name Exist";
            mockDto.Object.BatchId = 10;
            var result = controller.PostAsync(mockDto.Object);
            Assert.AreEqual(((ObjectResult)result.Result).Value, "Batch Name \"" + mockDto.Object.Name + "\" already exists.");
        }

        [TestMethod]
        public void BeforePost_MaxBatch()
        {
            List<Batch> batchList = new List<Batch>();
            for (int i = 1; i < 16; i++)
                batchList.Add(new Batch());
            var lookupTask = Task<QueryResults<Batch>>.Factory.StartNew(() => new QueryResults<Batch>() { Items = batchList });
            repositoryProvider.SetupSequence(x => x.ReadManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);
            mockDto.Object.Name = "Test Name";
            var result = controller.PostAsync(mockDto.Object);
            var noResult = result.Result as NotAcceptableObjectResult;
            Assert.AreEqual(((ApiRestExceptionDto)noResult.Value).Message, "Maximum 15 Batches can create for single User.");
        }

        [TestMethod]
        public void BeforePost_NoModuleSelection()
        {
            var lookupTask = Task<Batch>.Factory.StartNew(() => new Batch());
            var lookupTaskNull = Task<Batch>.Factory.StartNew(() => null);
            repositoryProvider.SetupSequence(x => x.ReadAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTaskNull).Returns(lookupTask);
            mockDto.Object.Name = "Test Name";
            mockDto.Object.BatchId = 1;
            var result = controller.PostAsync(mockDto.Object);
            var noResult = result.Result as NotAcceptableObjectResult;
            Assert.AreEqual(((ApiRestExceptionDto)noResult.Value).Message, "Must have at least one module selected.");
        }

        [TestMethod]
        public void BeforePost_SetDefault()
        {
            var lookupTask = Task<Batch>.Factory.StartNew(() => new Batch());
            var lookupTaskNull = Task<Batch>.Factory.StartNew(() => null);
            var lookupTaskMany = Task<QueryResults<Batch>>.Factory.StartNew(() => new QueryResults<Batch>() { Items = new List<Batch> { new Batch() } });
            repositoryProvider.SetupSequence(x => x.ReadAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTaskNull).Returns(lookupTask);
            repositoryProvider.Setup(x => x.ReadManyAsync(It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTaskMany);
            repositoryProvider.Setup(x => x.UpdateAsync(It.IsAny<Batch>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);
            mockDto.Object.Name = "Test Name";
            mockDto.Object.IsDefault = true;
            mockDto.Object.BatchId = 1;
            mockDto.Object.AllowCreditCard = true;
            var result = controller.PostAsync(mockDto.Object);
            Assert.AreEqual(result.Status, TaskStatus.RanToCompletion);
        }
    }
}
