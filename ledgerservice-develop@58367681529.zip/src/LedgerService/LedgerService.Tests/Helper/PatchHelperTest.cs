﻿using LedgerService.Tests;
using LedgerService.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace LedgerService.Helper.Tests
{
    [TestClass]
    public class PatchHelperTest
    {
        [TestInitialize]
        public void SetUp()
        {
            string rootpath = TestHelper.GetRootPath();
            Startup.ApplicationRootDirectory = rootpath.Substring(0, rootpath.Length - 5) + "Web";
        }

        [TestMethod]
        public void GetStatementTest()
        {
            Dictionary<string, object> tagValuePairs = new Dictionary<string, object>();
            tagValuePairs.Add("PostState", "POSTED");
            tagValuePairs.Add("PostDate", DateTime.Now);
            string filter = "gl_transaction_id in (1,2,3,4)";
            string s = PatchHelper.GetStatement("GlTransaction", tagValuePairs, filter);
            Assert.IsNotNull(s);
        }
    }
}
