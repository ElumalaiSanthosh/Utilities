﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LedgerService.Tests
{
    public static class TestHelper
    {
        public static string GetRootPath()
        {
            return Environment.CurrentDirectory.GetRootPath();
        }
        private static string GetRootPath(this string path)
        {
            if (path.EndsWith(".Tests"))
                return path;
            else
            {
                return GetRootPath(Directory.GetParent(path).FullName);
            }
        }
    }
}
