using System;
using System.Data;
using System.Net;
using ApiService.Commons.DataStore;
using System.Threading.Tasks;
using ApiService.Commons.Rest;
using LedgerService.Models.Dtos;
using LedgerService.Web.Controllers;
using LedgerService.Web.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNet.OData;
using Microsoft.AspNet.OData.Builder;
using Microsoft.AspNet.OData.Extensions;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNet.OData.Query.Validators;
using Microsoft.OData.UriParser;
using Microsoft.Extensions.Configuration;
using ApiService.Repositories;
using ApiService.Commons.CacheService;

namespace LedgerService.Controller.Tests
{
    public partial class GlTransactionsControllerTests
    {
        Mock<IDbTransaction> mockDBContext;
        Mock<IConfiguration> config;
        Mock<IServiceProvider> serviceProviderObj;
        Mock<IRepository<GlTransaction>> repoObj;
        Mock<IGlTransactionService> glServiceObj;
        Mock<ODataQueryOptions<GlTransaction>> mockOData;

        public GlTransactionsControllerTests()
        {
            mockDBContext = new Mock<IDbTransaction>();
            config = new Mock<IConfiguration>();
            serviceProviderObj = new Mock<IServiceProvider>();
            repoObj = new Mock<IRepository<GlTransaction>>();
            glServiceObj = new Mock<IGlTransactionService>();
            mockOData = new Mock<ODataQueryOptions<GlTransaction>>();
        }
        [TestMethod]
        public async Task GetUnpostedByLedgerCompanyIdTest()
        {
            var config = new Mock<IConfiguration>();
            var service = new Mock<IGlTransactionService>();
            var apiCacheService = new Mock<IApiCache>();
            GlTransactionsController controller = new GlTransactionsController(config.Object, service.Object,apiCacheService.Object);

            var lookupTask = Task<QueryResults<GlTransaction>>.Factory.StartNew(() => new QueryResults<GlTransaction>());
            service.Setup(d => d.GetUnPostedJournals(It.IsAny<Guid>(),It.IsAny<QueryOptions>(),It.IsAny<IDbTransaction>())).Returns(lookupTask);
            lookupTask.Wait();

            var collection = new ServiceCollection();
            collection.AddOData();
            collection.AddODataQueryFilter();
            collection.AddTransient<ODataUriResolver>();
            collection.AddTransient<ODataQueryValidator>();
            collection.AddTransient<TopQueryValidator>();
            collection.AddTransient<FilterQueryValidator>();
            collection.AddTransient<SkipQueryValidator>();
            collection.AddTransient<OrderByQueryValidator>();
            var provider = collection.BuildServiceProvider();

            var routeBuilder = new RouteBuilder(Mock.Of<IApplicationBuilder>(x => x.ApplicationServices == provider));
            routeBuilder.EnableDependencyInjection();
            var modelBuilder = new ODataConventionModelBuilder(provider);
            modelBuilder.EntitySet<GlTransaction>("GlTransaction");
            var model = modelBuilder.GetEdmModel();

            var uri = new Uri("http://localhost/api/GlTransaction/1?$select=Id");

            DefaultHttpContext httpContext = new DefaultHttpContext
            {
                RequestServices = provider
            };

            var context = new ODataQueryContext(model, typeof(GlTransaction), new Microsoft.AspNet.OData.Routing.ODataPath());
            var options = new ODataQueryOptions<GlTransaction>(context, httpContext.Request);
            var result = await (controller.GetUnpostedByLedgerCompanyId(Guid.NewGuid(), options));
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
            lookupTask = Task<QueryResults<GlTransaction>>.Factory.StartNew(() => throw new ApiRestException(HttpStatusCode.NoContent, "No Content"));
            service.Setup(d => d.GetUnPostedJournals(It.IsAny<Guid>(), It.IsAny<QueryOptions>(),It.IsAny<IDbTransaction>())).Returns(lookupTask);
            result = await (controller.GetUnpostedByLedgerCompanyId(Guid.NewGuid(), options));
            var noResult = result as NoContentResult;
            Assert.IsNotNull(noResult);
            Assert.AreEqual(204, noResult.StatusCode);
            lookupTask = Task<QueryResults<GlTransaction>>.Factory.StartNew(() => null);
            service.Setup(d => d.GetUnPostedJournals(It.IsAny<Guid>(), It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);
            result = await (controller.GetUnpostedByLedgerCompanyId(Guid.NewGuid(), options));
            noResult = result as NoContentResult;
            Assert.IsNotNull(noResult);
            Assert.AreEqual(204, noResult.StatusCode);
        }

        [TestMethod]
        public async Task GetUnpostedJEExistsTest()
        {
            var config = new Mock<IConfiguration>();
            var service = new Mock<IGlTransactionService>();
            var apiCacheService = new Mock<IApiCache>();
            GlTransactionsController controller = new GlTransactionsController(config.Object, service.Object,apiCacheService.Object);
            var lookupTask = Task<QueryResults<GlTransaction>>.Factory.StartNew(() => new QueryResults<GlTransaction>());
            service.Setup(d => d.GetUnPostedJournals(It.IsAny<Guid>(), It.IsAny<QueryOptions>(), It.IsAny<IDbTransaction>())).Returns(lookupTask);
            lookupTask.Wait();
            var result = await (controller.GetUnpostedByCompanyExternalId(Guid.NewGuid()));
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
          
        }

    }
}
