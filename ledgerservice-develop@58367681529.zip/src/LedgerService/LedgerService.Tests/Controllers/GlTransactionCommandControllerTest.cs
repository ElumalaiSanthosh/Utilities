using ApiService.Commons.CacheService;
using LedgerService.Web.Controllers;
using LedgerService.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LedgerService.Controller.Tests
{
    public partial class GlTransactionsControllerTests
    {

        [TestMethod]
        public async Task DeleteManyAsyncTest()
        {
            var service = new Mock<IGlTransactionService>();
            var apiCacheService = new Mock<IApiCache>();
            var config = new Mock<IConfiguration>();
            GlTransactionsController controller = new GlTransactionsController(config.Object, service.Object, apiCacheService.Object);
            var lookupTask = Task<bool>.Factory.StartNew(() => true);
            service.Setup(d => d.DeleteManyAsync(It.IsAny<string>(), null)).Returns(lookupTask);
            lookupTask.Wait();
            var result = await (controller.DeleteManyAsync("1,2,3"));
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
        }

    }
}
