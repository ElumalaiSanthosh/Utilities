set search_path=ledgerservice,public;

alter table batch
add column if not exists company_uuid uuid,
add column if not exists user_uuid uuid,
add column if not exists retain_batch boolean,
add column if not exists shared_batch boolean,
add column if not exists is_default boolean,
add column if not exists allow_journals boolean,
add column if not exists allow_payables boolean,
add column if not exists allow_receivables boolean,
add column if not exists allow_pettycash boolean,
add column if not exists allow_creditcard boolean;