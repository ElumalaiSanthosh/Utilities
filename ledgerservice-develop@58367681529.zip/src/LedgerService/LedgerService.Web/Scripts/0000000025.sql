set search_path=ledgerservice,public;

DELETE FROM ledgerservice.gl_transaction_type 
		WHERE gl_transaction_type = 'CREDIT MEMO' AND  subsystem_type = 'AP' AND is_system_only = false;