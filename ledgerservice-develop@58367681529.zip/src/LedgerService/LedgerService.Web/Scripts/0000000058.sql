﻿
SET search_path=ledgerservice,PUBLIC;


ALTER TABLE ledgerservice.payment ADD COLUMN IF NOT EXISTS payee_name character varying(150);

INSERT INTO ledgerservice.gl_transaction_type 
            (gl_transaction_type, 
             subsystem_type, 
             is_system_only)
             SELECT 'Petty Cash','PP',false WHERE NOT EXISTS (
SELECT 1 FROM ledgerservice.gl_transaction_type WHERE gl_transaction_type='Petty Cash' AND subsystem_type='PP');

