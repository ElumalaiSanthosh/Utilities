SET search_path=ledgerservice,public;

ALTER TABLE gl_transaction_detail ADD COLUMN parent_line_number int;




