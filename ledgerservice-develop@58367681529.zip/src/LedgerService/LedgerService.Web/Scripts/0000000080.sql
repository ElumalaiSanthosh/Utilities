﻿
SET search_path=ledgerservice,public;

DROP VIEW IF EXISTS v_bankactivities; 

CREATE
	OR REPLACE VIEW v_bankactivities AS

(SELECT gl.gl_transaction_id
	,gl.external_id
	,gl.subsystem_type
	,gl.gl_transaction_type
	,gl.document_number
	,''::TEXT AS vendor_uuid
	,gl.document_date
	,gl.post_state
	,gl.document_amount
	,lc.company_uuid
	,CASE 
		WHEN sign(det.amount) = '-1'::NUMERIC
			THEN abs(det.amount)
		ELSE NULL::NUMERIC
		END AS debit
	,CASE 
		WHEN sign(det.amount) = 1::NUMERIC
			THEN det.amount
		ELSE NULL::NUMERIC
		END AS credit
	,''::TEXT AS bank_uuid
	,0 AS ar_gl_transaction_id
	,0 AS post_payment_gl_transaction_id
	,ga.detail_id_code
	,'Journal Entry'::TEXT AS transaction_type
	,CASE 
		WHEN gl.post_state::TEXT = 'VOIDED'::TEXT
			THEN (
					SELECT document_date
					FROM gl_transaction
					WHERE gl_transaction_id = gl.reference_gl_transaction_id
					)::CHARACTER VARYING
		ELSE NULL::CHARACTER VARYING
		END AS void_date
	,'ADJUSTMENTS'::TEXT AS bank_activity_type
	,gl.description
	,br.statement_date
	,br.finalized
	,br.bank_reconciliation_id
FROM gl_transaction gl
LEFT JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
LEFT JOIN gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
LEFT JOIN gl_account ga ON ga.gl_account_id = det.gl_account_id
LEFT JOIN bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
LEFT JOIN bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
WHERE gl.subsystem_type::TEXT = 'JE'::TEXT
	AND (
		gl.post_state::TEXT = 'POSTED'::TEXT
		OR gl.post_state::TEXT = 'VOIDED'::TEXT
		OR gl.post_state::TEXT = 'REVERSED'::TEXT
		)
	AND ga.detail_id_code IS NOT NULL

UNION ALL

SELECT gl.gl_transaction_id
	,gl.external_id
	,gl.subsystem_type
	,gl.gl_transaction_type
	,gl.document_number
	,pi.vendor_uuid::CHARACTER VARYING AS vendor_uuid
	,gl.document_date
	,gl.post_state
	,gl.document_amount
	,lc.company_uuid
	,CASE 
		WHEN sign(gl.document_amount) = 1::NUMERIC
			THEN gl.document_amount
		ELSE NULL::NUMERIC
		END AS debit
	,CASE 
		WHEN sign(gl.document_amount) = '-1'::NUMERIC
			THEN abs(gl.document_amount)
		ELSE NULL::NUMERIC
		END AS credit
	,lb.bank_uuid::CHARACTER VARYING AS bank_uuid
	,0 AS ar_gl_transaction_id
	,payment.post_payment_gl_transaction_id
	,''::TEXT AS detail_id_code
	,payment.payment_type AS transaction_type
	,CASE 
		WHEN gl.post_state::TEXT = 'VOIDED'::TEXT
			THEN (
					SELECT document_date
					FROM gl_transaction
					WHERE gl_transaction_id = gl.reference_gl_transaction_id
					)::CHARACTER VARYING
		ELSE NULL::CHARACTER VARYING
		END AS void_date
	,'PAYMENTS'::TEXT AS bank_activity_type
	,gl.description
	,br.statement_date
	,br.finalized
	,br.bank_reconciliation_id
FROM gl_transaction gl
LEFT JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
LEFT JOIN payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
LEFT JOIN gl_transaction_payment gtp ON gtp.payment_info_id = pi.payment_info_id
LEFT JOIN payment payment ON payment.payment_id = gtp.payment_id
LEFT JOIN bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
LEFT JOIN bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
LEFT JOIN ledger_bank lb ON lb.ledger_bank_id = payment.ledger_bank_id
WHERE gl.subsystem_type::TEXT = 'PP'::TEXT
	AND (
		gl.post_state::TEXT = 'POSTED'::TEXT
		OR gl.post_state::TEXT = 'VOIDED'::TEXT
		)
	AND gl.gl_transaction_type::TEXT = 'PAYMENTS'::TEXT
	OR gl.gl_transaction_type::TEXT = 'Petty Cash'::TEXT

UNION ALL

SELECT gl.gl_transaction_id
	,gl.external_id
	,gl.subsystem_type
	,gl.gl_transaction_type
	,gl.document_number
	,''::TEXT AS vendor_uuid
	,gl.document_date
	,gl.post_state
	,gl.document_amount
	,lc.company_uuid
	,CASE 
		WHEN sign(gl.document_amount) = '-1'::INTEGER::NUMERIC
			THEN abs(gl.document_amount)
		ELSE NULL::NUMERIC
		END AS debit
	,CASE 
		WHEN sign(gl.document_amount) = 1::NUMERIC
			THEN gl.document_amount
		ELSE NULL::NUMERIC
		END AS credit
	,lb.bank_uuid::CHARACTER VARYING AS bank_uuid
	,0 AS ar_gl_transaction_id
	,0 AS post_payment_gl_transaction_id
	,''::TEXT AS detail_id_code
	,CASE 
		WHEN pi.sending_bank_id IS NOT NULL
			THEN 'Bank Transfer'::TEXT
		ELSE 'Deposit'::TEXT
		END AS transaction_type
	,CASE 
		WHEN gl.post_state::TEXT = 'VOIDED'::TEXT
			THEN (
					SELECT document_date
					FROM gl_transaction
					WHERE gl_transaction_id = gl.reference_gl_transaction_id
					)::CHARACTER VARYING
		ELSE NULL::CHARACTER VARYING
		END AS void_date
	,'DEPOSITS'::TEXT AS bank_activity_type
	,gl.description
	,br.statement_date
	,br.finalized
	,br.bank_reconciliation_id
FROM gl_transaction gl
LEFT JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
LEFT JOIN payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
LEFT JOIN ledger_bank lb ON lb.ledger_bank_id = pi.ledger_bank_id
LEFT JOIN ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
LEFT JOIN bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
LEFT JOIN bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
WHERE gl.subsystem_type::TEXT = 'DE'::TEXT
	AND (
		gl.post_state::TEXT = 'POSTED'::TEXT
		OR gl.post_state::TEXT = 'VOIDED'::TEXT
		)

UNION ALL

SELECT gl.gl_transaction_id
	,gl.external_id
	,gl.subsystem_type
	,gl.gl_transaction_type
	,gl.document_number
	,''::TEXT AS vendor_uuid
	,gl.document_date
	,gl.post_state
	,gl.document_amount
	,lc.company_uuid
	,CASE 
		WHEN sign(gl.document_amount) = 1::NUMERIC
			THEN gl.document_amount
		ELSE NULL::NUMERIC
		END AS debit
	,CASE 
		WHEN sign(gl.document_amount) = '-1'::NUMERIC
			THEN abs(gl.document_amount)
		ELSE NULL::NUMERIC
		END AS credit
	,lbs.bank_uuid::CHARACTER VARYING AS bank_uuid
	,0 AS ar_gl_transaction_id
	,0 AS post_payment_gl_transaction_id
	,''::TEXT AS detail_id_code
	,'Bank Transfer'::TEXT AS transaction_type
	,CASE 
		WHEN gl.post_state::TEXT = 'VOIDED'::TEXT
			THEN (
					SELECT document_date
					FROM gl_transaction
					WHERE gl_transaction_id = gl.reference_gl_transaction_id
					)::CHARACTER VARYING
		ELSE NULL::CHARACTER VARYING
		END AS void_date
	,'DEPOSITS'::TEXT AS bank_activity_type
	,gl.description
	,br.statement_date
	,br.finalized
	,br.bank_reconciliation_id
FROM gl_transaction gl
LEFT JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
LEFT JOIN payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
LEFT JOIN ledger_bank lb ON lb.ledger_bank_id = pi.ledger_bank_id
LEFT JOIN ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
LEFT JOIN bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
LEFT JOIN bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
WHERE gl.subsystem_type::TEXT = 'DE'::TEXT
	AND (
		gl.post_state::TEXT = 'POSTED'::TEXT
		OR gl.post_state::TEXT = 'VOIDED'::TEXT
		)
	AND pi.sending_bank_id IS NOT NULL);

