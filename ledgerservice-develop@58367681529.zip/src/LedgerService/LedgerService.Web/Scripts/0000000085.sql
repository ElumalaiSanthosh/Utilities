SET search_path=ledgerservice,public;

DROP VIEW IF EXISTS v_linetransactiondetails;

CREATE VIEW v_linetransactiondetails AS
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.ledger_company_id,
    gl.batch_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.transaction_number,
    gl.created_ts,
    gl.document_number,
    gl.document_date,
    gl.description AS gl_description,
    gl.post_date,
    gl.post_state,
    gl.reversal_date,
    gl.reference_gl_transaction_id,
    gl.recurrence_type,
    gl.recurrence_start_date,
    gl.recurrence_end_date,
    gl.thirteenth_period,
    gl.created_by_user,
    gl.last_modified_user,
    gl.has_errors,
    gl.is_ar_startup,
    lc.company_uuid,
    lp.project_uuid,
    det.gl_transaction_detail_id,
    det.line_number,
    det.amount,
    det.reference_gl_transaction_id AS ref_gl_transaction_id_gl_account_details,
    COALESCE(det.description, gl.description) AS detail_description,
    det.ca_tax_credit_id,
    lv.vendor_uuid AS detail_vendor_uuid,
    gla.gl_account_id,
    gla.ledger_coa_id,
    gla.ledger_project_id,
    gla.company_division_id_code,
    gla.company_subaccount_id_code,
    gla.detail_id_code,
    gla.memo_freefield1,
    gla.memo_freefield2,
    gla.is_system_generated,
    lcoa.coa_uuid,
	rl.record_lock_id
   FROM gl_transaction gl
     LEFT JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledger_vendor lv ON lv.ledger_vendor_id = det.ledger_vendor_id
     LEFT JOIN gl_account gla ON gla.gl_account_id = det.gl_account_id
     LEFT JOIN ledger_project lp ON lp.ledger_project_id = gla.ledger_project_id
     LEFT JOIN ledger_coa lcoa ON lcoa.ledger_coa_id = gla.ledger_coa_id
	 LEFT JOIN record_lock rl ON gl.gl_transaction_id = rl.record_id and strpos(rl.record_name,'TRANSACTION')>0;