set search_path=ledgerservice,public;

ALTER TABLE gl_account
    ADD  COLUMN if not exists is_system_generated boolean DEFAULT false;


