set search_path=ledgerservice,public;

ALTER TABLE gl_transaction

add column if not exists has_errors boolean;

