set search_path=ledgerservice,public;

alter table gl_transaction_detail
DROP column if exists  item_memo_1,
DROP column if exists  item_memo_2;

alter table gl_account
add column if not exists  memo_freefield1 character varying(15),
add column if not exists  memo_freefield2 character varying(15);

DROP table gl_acct_memo;


