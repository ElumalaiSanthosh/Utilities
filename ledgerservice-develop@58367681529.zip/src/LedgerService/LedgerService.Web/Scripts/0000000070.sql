SET search_path=po,public;

CREATE TABLE IF NOT EXISTS db_properties
(
    db_properties_id SERIAL PRIMARY KEY,
    last_update timestamp,
    host_name character varying(255),
    script character varying(255)
);

DROP VIEW IF EXISTS v_po_line_transactions;

CREATE VIEW v_po_line_transactions AS(
SELECT po.purchase_order_id, 
po.external_id, 
po.company_id, 
po.vendor_id, 
po.po_number,
po.date,
po.due_date, 
po.description, 
po.total_amount, 
po.state, 
po.iso_currency_code, 
po.payment_check_deposit_check, 
po.payment_check_payment_check, 
po.payment_check_petty_cash, 
po.payment_check_credit_card, 
po.payment_check_will_bill, 
po.payment_check_additional_billing, 
po.payment_check_hold, 
po.created_by_user, 
po.last_modified_user, 
po.created_ts,
lc.company_uuid,
pod.purchase_order_detail_id, 
pod.original_amount, 
pod.amount, 
pod.description AS detail_description, 
pod.tax_credit_id,
poa.purchase_order_account_id, 
poa.coa_id,
poa.project_id, 
poa.company_division_id_code, 
poa.company_subaccount_id_code, 
poa.detail_id_code, 
poa.memo_freefield1, 
poa.memo_freefield2, 
poa.tax_code_id,
c.coa_uuid,
p.project_uuid
FROM purchase_order po
INNER JOIN company lc ON po.company_id=lc.company_id
INNER JOIN purchase_order_detail pod ON pod.purchase_order_id=po.purchase_order_id
INNER JOIN purchase_order_account poa ON poa.purchase_order_account_id=pod.purchase_order_account_id
INNER JOIN coa c ON c.coa_id = poa.coa_id
INNER JOIN project p ON p.project_id=poa.project_id
);
