
CREATE  TABLE IF NOT EXISTS po.company
(
    company_id BIGSERIAL PRIMARY KEY,
    company_uuid uuid NOT NULL
);
CREATE  TABLE IF NOT EXISTS po.vendor
(
    vendor_id BIGSERIAL PRIMARY KEY,
    vendor_uuid uuid NOT NULL
);
CREATE  TABLE IF NOT EXISTS po.state
(
     state character varying(30) PRIMARY KEY
);
CREATE  TABLE IF NOT EXISTS po.tax_credit
(
    tax_credit_id BIGSERIAL PRIMARY KEY,
    company_id bigint REFERENCES po.company(company_id),
	tax_credit character varying(50)
);
CREATE  TABLE IF NOT EXISTS po.project
(
	 project_id BIGSERIAL PRIMARY KEY,
    project_uuid uuid NOT NULL
);
CREATE  TABLE IF NOT EXISTS po.coa
(
	 coa_id BIGSERIAL PRIMARY KEY,
    coa_uuid uuid NOT NULL
);
 CREATE TABLE IF NOT EXISTS po.tax_form
(
    tax_form_id BIGSERIAL PRIMARY KEY,
    name character varying(50)
);
 CREATE TABLE po.tax_code
(
    tax_code_id BIGSERIAL PRIMARY KEY,
    tax_form_id bigint REFERENCES po.tax_form(tax_form_id),
    tax_code character varying(10)  
);
CREATE TABLE IF NOT EXISTS po.purchase_order
(
    purchase_order_id BIGSERIAL PRIMARY KEY,
    external_id uuid DEFAULT uuid_generate_v4(),
    company_id bigint REFERENCES po.company(company_id),
	vendor_id bigint REFERENCES po.vendor(vendor_id),	
    po_number character varying(30) COLLATE pg_catalog."default",
    date date,
	due_date date,
    description character varying(100)  ,
	total_amount numeric(16,6),
    state character varying(20) NOT NULL REFERENCES po.state(state),
	iso_currency_code character varying(3),
	payment_check_deposit_check boolean,
	payment_check_payment_check boolean,
	payment_check_petty_cash boolean,
	payment_check_credit_card boolean,
	payment_check_will_bill boolean,
	payment_check_additional_billing boolean,
	payment_check_hold boolean,	
    created_by_user uuid,
    last_modified_user uuid,
	created_ts timestamp with time zone NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS po.purchase_order_account
(
	 purchase_order_account_id BIGSERIAL PRIMARY KEY,
     coa_id bigint REFERENCES po.coa(coa_id),
	 project_id bigint REFERENCES po.project(project_id),
	 company_division_id_code character varying(15),
     company_subaccount_id_code character varying(15),
	 detail_id_code character varying(15),
	 memo_freefield1 character varying(15),
     memo_freefield2 character varying(15),
	 tax_code_id bigint REFERENCES po.tax_code(tax_code_id)
);
CREATE  TABLE IF NOT EXISTS po.purchase_order_detail
(
	 purchase_order_detail_id BIGSERIAL PRIMARY KEY,
     purchase_order_id bigint REFERENCES po.purchase_order(purchase_order_id),
     line_number int,
	 original_amount numeric(16,6),
	 amount numeric(16,6),
	 description  character varying(100), 	 
	 tax_credit_id BIGSERIAL REFERENCES po.tax_credit(tax_credit_id),
	 purchase_order_account_id bigint REFERENCES po.purchase_order_account(purchase_order_account_id)
);
INSERT INTO po.state
            (state) 
             SELECT 'OPEN'WHERE NOT EXISTS (
    SELECT 1 FROM po.state WHERE state='OPEN');
		
INSERT INTO po.state
            (state) 
             SELECT 'INCOMPLETE'WHERE NOT EXISTS (
    SELECT 1 FROM po.state WHERE state='INCOMPLETE');
 
INSERT INTO po.tax_form(name) VALUES ('1099');
 
INSERT INTO po.tax_code( tax_form_id, tax_code) VALUES 
((SELECT 1 FROM po.tax_form WHERE name='1099'),'01'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'02'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'03'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'04'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'06'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'07'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'14'),
((SELECT 1 FROM po.tax_form WHERE name='1099'),'16')