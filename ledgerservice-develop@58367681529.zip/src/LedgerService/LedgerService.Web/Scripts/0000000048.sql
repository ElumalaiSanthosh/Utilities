﻿set search_path=ledgerservice,public;

ALTER TABLE ledgerservice.payment_info DROP column if exists  payment_id;

