set search_path=ledgerservice,public;

INSERT INTO ledgerservice.gl_transaction_type(
	gl_transaction_type, subsystem_type, is_system_only) 
	 SELECT 'VOID', 'JE', false
WHERE NOT EXISTS (
    SELECT 1 FROM ledgerservice.gl_transaction_type WHERE gl_transaction_type='VOID'
);