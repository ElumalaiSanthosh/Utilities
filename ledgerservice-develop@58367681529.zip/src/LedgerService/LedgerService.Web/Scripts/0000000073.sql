﻿set search_path=ledgerservice,public;

ALTER TABLE ledgerservice.gl_transaction_detail 
    ADD COLUMN charge_date DATE;

INSERT INTO ledgerservice.subsystem_type(
	subsystem_type, description)
	VALUES ('CC', 'CreditCard');

INSERT INTO ledgerservice.gl_transaction_type(
	gl_transaction_type, subsystem_type, is_system_only)
	VALUES ('STANDARD', 'CC', false);
		


