set search_path=ledgerservice,public;

CREATE  TABLE ledgerservice.gl_transaction_payment
(
    gl_transaction_payment_id BIGSERIAL PRIMARY KEY,
    payment_info_id bigint NOT NULL references payment_info,
    payment_id bigint NOT NULL references payment
);


ALTER TABLE ledgerservice.payment    
    ADD COLUMN amount_paid numeric(16,6);

INSERT INTO ledgerservice.post_state(post_state)
 values
    ('PAID'),
    ('PARTIALLYPAID'),
    ('UNPAID');
