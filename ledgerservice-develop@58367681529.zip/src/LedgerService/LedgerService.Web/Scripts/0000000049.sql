﻿set search_path=ledgerservice,public;

ALTER TABLE payment_info  ADD COLUMN IF NOT EXISTS hold_payment BOOLEAN DEFAULT NULL


