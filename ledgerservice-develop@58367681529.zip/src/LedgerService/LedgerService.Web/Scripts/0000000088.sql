ALTER TABLE ledgerservice.payment ADD COLUMN amount_subject_to_tax numeric(16,6);
ALTER TABLE ledgerservice.payment ADD COLUMN discount_amount numeric(16,6);