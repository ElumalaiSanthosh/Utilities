DROP VIEW ledgerservice.v_payment_records;

ALTER TABLE ledgerservice.payment DROP COLUMN created_by_user;
ALTER TABLE ledgerservice.payment DROP COLUMN last_modified_user;

ALTER TABLE ledgerservice.payment ADD COLUMN ledger_user_created_id bigint;
ALTER TABLE ledgerservice.payment ADD COLUMN ledger_user_last_modified_id bigint;

CREATE TABLE ledger_user
(
    ledger_user_id BIGSERIAL PRIMARY KEY,
    user_uuid uuid NOT NULL
);

CREATE UNIQUE INDEX idx_unique_user_uuid
    ON ledgerservice.ledger_user USING btree
    (user_uuid)
    TABLESPACE pg_default;

ALTER TABLE ledgerservice.payment
    ADD CONSTRAINT payment_ledger_user_created_id_fkey FOREIGN KEY (ledger_user_created_id)
    REFERENCES ledgerservice.ledger_user (ledger_user_id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

ALTER TABLE ledgerservice.payment
    ADD CONSTRAINT payment_ledger_user_last_modified_id_fkey FOREIGN KEY (ledger_user_last_modified_id)
    REFERENCES ledgerservice.ledger_user (ledger_user_id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

CREATE VIEW ledgerservice.v_payment_records AS
 SELECT 
    payment_id,    
    payment_type,
    payment_number,    
    payment_date,
    check_memo,
    payment_ref,
    created_ts,
    uc.user_uuid as ledger_user_created_uuid,
    um.user_uuid as ledger_user_last_modified_uuid,
    post_payment_gl_transaction_id,
    amount,
    payee_name,
    posted_ts,
    amount_subject_to_tax,
    discount_amount,
 	lv.vendor_uuid,
	lb.bank_uuid    
   FROM ledgerservice.payment pm
     JOIN ledgerservice.ledger_vendor lv ON lv.ledger_vendor_id = pm.ledger_vendor_id
	 JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id
     LEFT JOIN ledgerservice.ledger_user uc ON uc.ledger_user_id = pm.ledger_user_created_id
     LEFT JOIN ledgerservice.ledger_user um ON um.ledger_user_id = pm.ledger_user_last_modified_id;