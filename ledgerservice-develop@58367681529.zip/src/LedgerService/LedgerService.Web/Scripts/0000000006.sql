set search_path=ledgerservice,public;

ALTER TABLE gl_account ALTER COLUMN ledger_coa_id DROP NOT NULL;
ALTER TABLE gl_account ALTER COLUMN ledger_project_id DROP NOT NULL;
ALTER TABLE gl_transaction_detail ALTER COLUMN ca_tax_credit_id DROP NOT NULL;
