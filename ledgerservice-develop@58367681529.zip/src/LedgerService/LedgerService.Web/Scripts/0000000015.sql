set search_path=ledgerservice,public;

alter table gl_transaction
add column if not exists void_date date;