set search_path=ledgerservice,public;

--insert 'REVERSED' post_state
INSERT INTO post_state  
SELECT 'REVERSED'
WHERE
NOT EXISTS (
    SELECT post_state FROM ledgerservice.post_state WHERE post_state = 'REVERSED'
);

--insert 'VOIDED' post_state
INSERT INTO post_state  
SELECT 'VOIDED'
WHERE
NOT EXISTS (
    SELECT post_state FROM ledgerservice.post_state WHERE post_state = 'VOIDED'
);

--update post_state for existing records
Update gl_transaction set post_state='VOIDED' where post_state='VOID';