﻿-- View: ledgerservice.v_bankactivities
DROP VIEW ledgerservice.v_bankactivities;

CREATE OR REPLACE VIEW ledgerservice.v_bankactivities
 AS
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.document_number,
    ''::text AS vendor_uuid,
    gl.document_date,
    gl.post_state,
    gl.document_amount,
    lc.company_uuid,
        CASE
            WHEN sign(det.amount) = '-1'::numeric THEN abs(det.amount)
            ELSE NULL::numeric
        END AS debit,
        CASE
            WHEN sign(det.amount) = 1::numeric THEN det.amount
            ELSE NULL::numeric
        END AS credit,
    ''::text AS bank_uuid,
    0 AS ar_gl_transaction_id,
    0 AS post_payment_gl_transaction_id,
    ga.detail_id_code,
    'Journal Entry'::text AS transaction_type,
        CASE
            WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
            ELSE NULL::character varying
        END AS void_date,
    'ADJUSTMENTS'::text AS bank_activity_type,
    gl.description,
    br.statement_date,
	br.finalized,
    br.bank_reconciliation_id
   FROM ledgerservice.gl_transaction gl
     LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.gl_account ga ON ga.gl_account_id = det.gl_account_id
     LEFT JOIN ledgerservice.bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
  WHERE gl.subsystem_type::text = 'JE'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text OR gl.post_state::text = 'REVERSED'::text) AND ga.detail_id_code IS NOT NULL
UNION ALL
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.document_number,
    pi.vendor_uuid::character varying AS vendor_uuid,
    gl.document_date,
    gl.post_state,
    gl.document_amount,
    lc.company_uuid,
        CASE
            WHEN sign(gl.document_amount) = 1::numeric THEN gl.document_amount
            ELSE NULL::numeric
        END AS debit,
        CASE
            WHEN sign(gl.document_amount) = '-1'::numeric THEN abs(gl.document_amount)
            ELSE NULL::numeric
        END AS credit,
    lb.bank_uuid::character varying AS bank_uuid,
    0 AS ar_gl_transaction_id,
    payment.post_payment_gl_transaction_id,
    ''::text AS detail_id_code,
    payment.payment_type AS transaction_type,
        CASE
            WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
            ELSE NULL::character varying
        END AS void_date,
    'PAYMENTS'::text AS bank_activity_type,
    gl.description,
    br.statement_date,
	br.finalized,
    br.bank_reconciliation_id
   FROM ledgerservice.gl_transaction gl
     LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
     LEFT JOIN ledgerservice.gl_transaction_payment gtp ON gtp.payment_info_id = pi.payment_info_id
     LEFT JOIN ledgerservice.payment payment ON payment.payment_id = gtp.payment_id
     LEFT JOIN ledgerservice.bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
     LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = payment.ledger_bank_id
  WHERE gl.subsystem_type::text = 'PP'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text) AND gl.gl_transaction_type::text = 'PAYMENTS'::text OR gl.gl_transaction_type::text = 'Petty Cash'::text
UNION ALL
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.document_number,
    ''::text AS vendor_uuid,
    gl.document_date,
    gl.post_state,
    gl.document_amount,
    lc.company_uuid,
        CASE
            WHEN sign(gl.document_amount) = '-1'::integer::numeric THEN abs(gl.document_amount)
            ELSE NULL::numeric
        END AS debit,
        CASE
            WHEN sign(gl.document_amount) = 1::numeric THEN gl.document_amount
            ELSE NULL::numeric
        END AS credit,
    lb.bank_uuid::character varying AS bank_uuid,
    0 AS ar_gl_transaction_id,
    0 AS post_payment_gl_transaction_id,
    ''::text AS detail_id_code,
        CASE
            WHEN pi.sending_bank_id IS NOT NULL THEN 'Bank Transfer'::text
            ELSE 'Deposit'::text
        END AS transaction_type,
        CASE
            WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
            ELSE NULL::character varying
        END AS void_date,
    'DEPOSITS'::text AS bank_activity_type,
    gl.description,
    br.statement_date,
	br.finalized,
    br.bank_reconciliation_id
   FROM ledgerservice.gl_transaction gl
     LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
     LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pi.ledger_bank_id
     LEFT JOIN ledgerservice.ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
     LEFT JOIN ledgerservice.bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
  WHERE gl.subsystem_type::text = 'DE'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text)
UNION ALL
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.document_number,
    ''::text AS vendor_uuid,
    gl.document_date,
    gl.post_state,
    gl.document_amount,
    lc.company_uuid,
        CASE
            WHEN sign(gl.document_amount) = 1::numeric THEN gl.document_amount
            ELSE NULL::numeric
        END AS debit,
        CASE
            WHEN sign(gl.document_amount) = '-1'::numeric THEN abs(gl.document_amount)
            ELSE NULL::numeric
        END AS credit,
    lbs.bank_uuid::character varying AS bank_uuid,
    0 AS ar_gl_transaction_id,
    0 AS post_payment_gl_transaction_id,
    ''::text AS detail_id_code,
    'Bank Transfer'::text AS transaction_type,
        CASE
            WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
            ELSE NULL::character varying
        END AS void_date,
    'DEPOSITS'::text AS bank_activity_type,
    gl.description,
    br.statement_date,
	br.finalized,
    br.bank_reconciliation_id
   FROM ledgerservice.gl_transaction gl
     LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
     LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pi.ledger_bank_id
     LEFT JOIN ledgerservice.ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
     LEFT JOIN ledgerservice.bank_reconciliation_clearing brc ON brc.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.bank_reconciliation br ON brc.bank_reconciliation_id = br.bank_reconciliation_id
  WHERE gl.subsystem_type::text = 'DE'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text) AND pi.sending_bank_id IS NOT NULL;

ALTER TABLE ledgerservice.v_bankactivities
    OWNER TO calgsv_write;

