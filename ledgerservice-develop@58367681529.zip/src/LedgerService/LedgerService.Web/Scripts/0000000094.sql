ALTER TABLE ledgerservice.payment ADD CONSTRAINT payment_ledger_vendor_id_fkey FOREIGN KEY (ledger_vendor_id)
        REFERENCES ledgerservice.ledger_vendor (ledger_vendor_id) MATCH SIMPLE
        ON UPDATE NO ACTION ON DELETE NO ACTION;

CREATE INDEX idx_payment_ledger_bank_id
    ON ledgerservice.payment USING btree
    (ledger_bank_id)
    TABLESPACE pg_default;	

CREATE INDEX idx_payment_ledger_vendor_id
    ON ledgerservice.payment USING btree
    (ledger_vendor_id)
    TABLESPACE pg_default;	

CREATE INDEX idx_payment_created_by
    ON ledgerservice.payment USING btree
    (ledger_user_created_id)
    TABLESPACE pg_default;

CREATE INDEX idx_payment_last_modified
    ON ledgerservice.payment USING btree
    (ledger_user_last_modified_id)
    TABLESPACE pg_default;

CREATE INDEX idx_payment_payment_type
    ON ledgerservice.payment USING btree
    (payment_type)
    TABLESPACE pg_default;
