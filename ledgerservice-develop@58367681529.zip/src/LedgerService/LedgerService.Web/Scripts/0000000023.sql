set search_path=ledgerservice,public;

INSERT INTO ledgerservice.post_state(post_state) 
	 SELECT 'VOID' WHERE NOT EXISTS (
    SELECT 1 FROM ledgerservice.post_state WHERE post_state='VOID');

UPDATE ledgerservice.gl_transaction SET  gl_transaction_type = 'STANDARD', post_state = 'VOID' WHERE gl_transaction_type = 'VOID';

DELETE FROM ledgerservice.gl_transaction_type 
		WHERE gl_transaction_type = 'VOID' AND  subsystem_type = 'JE' AND is_system_only = false;