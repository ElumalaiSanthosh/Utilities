set search_path=ledgerservice,public;

CREATE TABLE IF NOT EXISTS ledger_vendor(
	ledger_vendor_id bigserial primary key,
	vendor_uuid uuid not null
);

ALTER TABLE gl_transaction_detail ADD COLUMN IF NOT EXISTS ledger_vendor_id BIGINT NULL REFERENCES ledger_vendor;

ALTER TABLE gl_transaction_detail ADD COLUMN IF NOT EXISTS reference_gl_transaction_id BIGINT NULL REFERENCES gl_transaction;

ALTER TABLE payment_info ADD COLUMN IF NOT EXISTS ledger_bank_id BIGINT NULL REFERENCES ledger_bank;

ALTER TABLE payment_info ADD COLUMN IF NOT EXISTS sending_bank_id BIGINT NULL REFERENCES ledger_bank;

INSERT INTO subsystem_type 
            (subsystem_type, 
             description) 
             SELECT 'DE','Deposit Entry' WHERE NOT EXISTS (
SELECT 1 FROM subsystem_type WHERE subsystem_type='DE');

INSERT INTO gl_transaction_type 
            (gl_transaction_type, 
             subsystem_type, 
             is_system_only)
             SELECT 'STANDARD','DE',false WHERE NOT EXISTS (
SELECT 1 FROM gl_transaction_type WHERE gl_transaction_type='STANDARD' AND subsystem_type='DE');
