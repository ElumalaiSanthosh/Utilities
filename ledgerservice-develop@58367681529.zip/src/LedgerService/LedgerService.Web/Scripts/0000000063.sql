SET search_path=ledgerservice,public;

ALTER TABLE gl_transaction_detail
ADD COLUMN reference_gl_transaction_detail_id bigint REFERENCES gl_transaction_detail(gl_transaction_detail_id);




