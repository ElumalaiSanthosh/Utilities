﻿alter table ledgerservice.positive_pay_payment drop constraint positive_pay_payment_payment_id_fkey;
alter table ledgerservice.positive_pay_payment ADD constraint positive_pay_payment_payment_id_fkey FOREIGN KEY (payment_id)
        REFERENCES ledgerservice.payment (payment_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION;