﻿set search_path=ledgerservice,public;

-- View: ledgerservice.v_headertransactions

DROP VIEW ledgerservice.v_headertransactions;

CREATE OR REPLACE VIEW ledgerservice.v_headertransactions
 AS
SELECT 
    gl.gl_transaction_id,
    gl.external_id,
    gl.ledger_company_id,
    gl.ledger_project_id,
    gl.batch_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.transaction_number,
    gl.created_ts,
    gl.document_number,
    gl.document_date,
    gl.description,
    gl.post_date,
        CASE
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) IS NULL THEN 'UNPAID'::text
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) < gl.document_amount THEN 'PARTIALLYPAID'::text
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) >= gl.document_amount THEN 'PAID'::text
            ELSE gl.post_state::text
        END AS post_state,
    gl.reversal_date,
    gl.reference_gl_transaction_id,
    gl.recurrence_type,
    gl.recurrence_start_date,
    gl.recurrence_end_date,
    gl.thirteenth_period,
    gl.created_by_user,
    gl.last_modified_user,
    gl.has_errors,
    gl.document_amount,
    lc.company_uuid,
    b.name AS batch_name,
    b.company_uuid AS user_batch_company_uuid,
    b.user_uuid,
    b.retain_batch,
    b.shared_batch,
    b.is_default,
    b.allow_journals,
    b.allow_payables,
    b.allow_receivables,
    b.allow_pettycash,
    b.allow_creditcard,
    pi.payment_info_id,
    pi.reference_po,
    pi.vendor_uuid,
    pi.due_date,
    lb.bank_uuid,
    pm.payment_number,
    pm.payment_type,
    pm.payment_date,
    pm.payment_ref,
    pm.amount AS amount_paid,
    sum(det.amount) AS total_amount,
    pi.customer_uuid,
    pi.sales_rep_uuid,
        CASE
            WHEN count(DISTINCT ga.ledger_project_id) = 1 AND count(DISTINCT ga.company_division_id_code) = 1 THEN max(lp.project_uuid::character varying::text)
            WHEN count(DISTINCT ga.ledger_project_id) = 0 AND count(DISTINCT ga.company_division_id_code) > 0 THEN 'OVH'::text
            WHEN count(DISTINCT ga.ledger_project_id) > 0 AND count(DISTINCT ga.company_division_id_code) > 0 THEN 'Various'::text
            ELSE NULL::text
        END AS project,
    pm.post_payment_gl_transaction_id,
    lbr.bank_uuid AS receiving_bank,
    lbs.bank_uuid AS sending_bank,
    lpgl.project_uuid,
    pi.hold_payment
   FROM gl_transaction gl
     JOIN ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN gl_account ga ON ga.gl_account_id = det.gl_account_id
     LEFT JOIN ledger_project lp ON lp.ledger_project_id = ga.ledger_project_id
     LEFT JOIN ledger_project lpgl ON lpgl.ledger_project_id = gl.ledger_project_id
     LEFT JOIN batch b ON b.batch_id = gl.batch_id
     LEFT JOIN payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
     LEFT JOIN gl_transaction_payment gtp ON gtp.payment_info_id = pi.payment_info_id
     LEFT JOIN payment pm ON pm.payment_id = gtp.payment_id
     LEFT JOIN ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id
     LEFT JOIN ledger_bank lbr ON lbr.ledger_bank_id = pi.ledger_bank_id
     LEFT JOIN ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
  GROUP BY gl.gl_transaction_id, gl.external_id, gl.ledger_company_id, gl.ledger_project_id, gl.batch_id, gl.subsystem_type, gl.gl_transaction_type, gl.transaction_number, gl.created_ts, gl.document_number, gl.document_date, gl.description, gl.post_date, gl.post_state, gl.reversal_date, gl.reference_gl_transaction_id, gl.recurrence_type, gl.recurrence_start_date, gl.recurrence_end_date, gl.thirteenth_period, gl.created_by_user, gl.last_modified_user, gl.has_errors, lc.company_uuid, b.name, b.company_uuid, b.user_uuid, b.retain_batch, b.shared_batch, b.is_default, b.allow_journals, b.allow_payables, b.allow_receivables, b.allow_pettycash, b.allow_creditcard, pi.payment_info_id, pi.reference_po, pi.vendor_uuid, pi.due_date, gl.document_amount, lb.bank_uuid, pm.payment_number, pm.payment_type, pm.payment_date, pm.payment_ref, pi.customer_uuid, pi.sales_rep_uuid, pm.post_payment_gl_transaction_id, lbr.bank_uuid, lbs.bank_uuid, pm.amount, lpgl.project_uuid;

