﻿
ALTER TABLE po.purchase_order_detail ALTER COLUMN tax_credit_id DROP NOT NULL;

ALTER TABLE po.purchase_order_detail ALTER COLUMN tax_credit_id DROP DEFAULT;