﻿SET search_path=po,public;

ALTER TABLE purchase_order_detail ADD COLUMN IF NOT EXISTS parent_line_number int;
