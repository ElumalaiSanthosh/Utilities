set search_path=ledgerservice,public;

alter table gl_transaction
DROP column if exists  variance_amount;