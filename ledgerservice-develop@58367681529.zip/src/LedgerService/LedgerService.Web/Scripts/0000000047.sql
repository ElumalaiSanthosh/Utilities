﻿set search_path=ledgerservice,public;

ALTER TABLE ledgerservice.payment RENAME COLUMN amount_paid TO amount