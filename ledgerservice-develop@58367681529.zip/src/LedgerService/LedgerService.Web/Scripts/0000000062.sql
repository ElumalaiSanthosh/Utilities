
ALTER TABLE ledgerservice.bank_reconciliation ALTER COLUMN created_ts DROP NOT NULL;

ALTER TABLE ledgerservice.bank_reconciliation ALTER COLUMN  created_ts type timestamp with time zone;
   
ALTER TABLE ledgerservice.bank_reconciliation ALTER COLUMN modified_ts DROP NOT NULL;

ALTER TABLE ledgerservice.bank_reconciliation ALTER COLUMN  modified_ts type timestamp with time zone;