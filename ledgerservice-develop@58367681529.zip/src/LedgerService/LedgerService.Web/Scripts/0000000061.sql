set search_path=ledgerservice,public;

DROP VIEW po.v_pohistorydetails;


CREATE OR REPLACE VIEW po.v_pohistorydetails
 AS
 SELECT po.purchase_order_id,
    po.po_number,
    po.date,
    po.description,
    po.state,
    po.total_amount,
    sum(pod.original_amount) AS original_amount,
    pc.company_uuid,
    ve.vendor_id,
    ve.vendor_uuid,
        CASE
            WHEN count(DISTINCT poa.project_id) = 1 AND count(DISTINCT poa.company_division_id_code) = 1 THEN max(lp.project_uuid::character varying::text)
            WHEN count(DISTINCT poa.project_id) = 0 AND count(DISTINCT poa.company_division_id_code) > 0 THEN 'OVH'::text
            WHEN count(DISTINCT poa.project_id) > 0 AND count(DISTINCT poa.company_division_id_code) > 0 THEN 'Various'::text
            ELSE NULL::text
        END AS project,
		lp.project_uuid
   FROM po.purchase_order po
     JOIN po.company pc ON pc.company_id = po.company_id
     LEFT JOIN po.vendor ve ON ve.vendor_id = po.vendor_id
     LEFT JOIN po.purchase_order_detail pod ON pod.purchase_order_id = po.purchase_order_id
     LEFT JOIN po.purchase_order_account poa ON poa.purchase_order_account_id = pod.purchase_order_account_id
     LEFT JOIN po.project lp ON lp.project_id = poa.project_id
  GROUP BY po.purchase_order_id, po.po_number, po.date, po.description, po.state, po.total_amount, pc.company_uuid, ve.vendor_id, ve.vendor_uuid,lp.project_uuid;
