CREATE UNIQUE INDEX idx_unique_vendor_uuid
    ON ledgerservice.ledger_vendor USING btree
    (vendor_uuid)
    TABLESPACE pg_default;