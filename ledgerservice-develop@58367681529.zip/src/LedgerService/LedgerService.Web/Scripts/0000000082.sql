
SET search_path=ledgerservice, public;

ALTER TABLE bank_reconciliation_clearing
 ADD COLUMN  gl_transaction_detail_id bigint references gl_transaction_detail;


