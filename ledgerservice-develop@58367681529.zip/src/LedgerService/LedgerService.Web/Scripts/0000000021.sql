set search_path=ledgerservice,public;

ALTER TABLE gl_transaction
    ADD COLUMN IF NOT EXISTS iso_currency_code character varying(3);