CREATE OR REPLACE VIEW ledgerservice.v_payment_records AS
 SELECT 
    payment_id,    
    payment_type,
    payment_number,    
    payment_date,
    check_memo,
    payment_ref,
    created_ts,
    created_by_user,
    last_modified_user,
    post_payment_gl_transaction_id,
    amount,
    payee_name,
    posted_ts,
    amount_subject_to_tax,
    discount_amount,
 	lv.vendor_uuid,
	lb.bank_uuid    
   FROM ledgerservice.payment pm
     JOIN ledgerservice.ledger_vendor lv ON lv.ledger_vendor_id = pm.ledger_vendor_id
	 JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id