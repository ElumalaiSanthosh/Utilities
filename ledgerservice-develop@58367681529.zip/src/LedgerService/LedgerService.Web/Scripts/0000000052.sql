﻿set search_path=ledgerservice,public;

DROP VIEW ledgerservice.v_headertransactions;

CREATE OR REPLACE VIEW ledgerservice.v_headertransactions
 AS
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.ledger_company_id,
    gl.ledger_project_id,
    gl.batch_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.transaction_number,
    gl.created_ts,
    gl.document_number,
    gl.document_date,
    gl.description,
    gl.post_date,
        CASE
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM ledgerservice.payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM ledgerservice.gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) IS NULL THEN 'UNPAID'::text
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM ledgerservice.payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM ledgerservice.gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) < gl.document_amount THEN 'PARTIALLYPAID'::text
            WHEN gl.subsystem_type::text = 'AP'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM ledgerservice.payment
                      WHERE (payment.payment_id IN ( SELECT gtl.payment_id
                               FROM ledgerservice.gl_transaction_payment gtl
                              WHERE gtl.payment_info_id = pi.payment_info_id))) a)) >= gl.document_amount THEN 'PAID'::text
            WHEN gl.subsystem_type::text = 'AR'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT apgltd.amount AS amount_paid
                       FROM ledgerservice.gl_transaction_detail apgltd
                      WHERE apgltd.reference_gl_transaction_id = gl.gl_transaction_id) a)) < gl.document_amount THEN 'PARTIALLYPAID'::text
            WHEN gl.subsystem_type::text = 'AR'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT apgltd.amount AS amount_paid
                       FROM ledgerservice.gl_transaction_detail apgltd
                      WHERE apgltd.reference_gl_transaction_id = gl.gl_transaction_id) a)) IS NULL THEN 'UNPAID'::text
            WHEN gl.subsystem_type::text = 'AR'::text AND gl.post_state::text = 'POSTED'::text AND (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT apgltd.amount AS amount_paid
                       FROM ledgerservice.gl_transaction_detail apgltd
                      WHERE apgltd.reference_gl_transaction_id = gl.gl_transaction_id) a)) >= gl.document_amount THEN 'PAID'::text
            ELSE gl.post_state::text
        END AS post_state,
    gl.reversal_date,
    gl.reference_gl_transaction_id,
    gl.recurrence_type,
    gl.recurrence_start_date,
    gl.recurrence_end_date,
    gl.thirteenth_period,
    gl.created_by_user,
    gl.last_modified_user,
    gl.has_errors,
    gl.document_amount,
    lc.company_uuid,
    b.name AS batch_name,
    b.company_uuid AS user_batch_company_uuid,
    b.user_uuid,
    b.retain_batch,
    b.shared_batch,
    b.is_default,
    b.allow_journals,
    b.allow_payables,
    b.allow_receivables,
    b.allow_pettycash,
    b.allow_creditcard,
    pi.payment_info_id,
    pi.reference_po,
    pi.vendor_uuid,
    pi.due_date,
    ( SELECT lb.bank_uuid
           FROM ledgerservice.payment pm
             LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id
          WHERE (pm.payment_id IN ( SELECT bgtl.payment_id
                   FROM ledgerservice.gl_transaction_payment bgtl
                  WHERE bgtl.payment_info_id = pi.payment_info_id
                 LIMIT 1))) AS bank_uuid,
        CASE
            WHEN gl.subsystem_type::text = 'AP'::text THEN coalesce(gl.document_amount - (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT payment.amount AS amount_paid
                       FROM ledgerservice.payment
                      WHERE (payment.payment_id IN ( SELECT agtl.payment_id
                               FROM ledgerservice.gl_transaction_payment agtl
                              WHERE agtl.payment_info_id = pi.payment_info_id))) a)),gl.document_amount)
            WHEN gl.subsystem_type::text = 'AR'::text THEN coalesce(gl.document_amount - (( SELECT sum(a.amount_paid) AS sum
               FROM ( SELECT apgltd.amount AS amount_paid
                       FROM ledgerservice.gl_transaction_detail apgltd
                      WHERE apgltd.reference_gl_transaction_id = gl.gl_transaction_id) a)),gl.document_amount)
            ELSE NULL::numeric
        END AS balance_amount,
    ( SELECT string_agg(payment.post_payment_gl_transaction_id::text, ','::text) AS string_agg
           FROM ledgerservice.payment
          WHERE (payment.payment_id IN ( SELECT pgtl.payment_id
                   FROM ledgerservice.gl_transaction_payment pgtl
                  WHERE pgtl.payment_info_id = pi.payment_info_id))) AS payment_ids,
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_ref
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) > 1 THEN 'Various'::character varying
            ELSE NULL::character varying
        END AS payment_ref,
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_type
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) > 1 THEN 'Various'::character varying
            ELSE NULL::character varying
        END AS payment_type,
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_date
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            ELSE NULL::date
        END AS payment_date,
    ( SELECT max(payment.payment_date) AS max
           FROM ledgerservice.payment
          WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                   FROM ledgerservice.gl_transaction_payment pr_gtl
                  WHERE pr_gtl.payment_info_id = pi.payment_info_id))) AS last_payment_date,
    lbr.bank_uuid AS receiving_bank,
    sum(det.amount) AS total_amount,
    pi.customer_uuid,
    pi.sales_rep_uuid,
        CASE
            WHEN count(DISTINCT ga.ledger_project_id) = 1 AND count(DISTINCT ga.company_division_id_code) = 1 THEN max(lp.project_uuid::character varying::text)
            WHEN count(DISTINCT ga.ledger_project_id) = 0 AND count(DISTINCT ga.company_division_id_code) > 0 THEN 'OVH'::text
            WHEN count(DISTINCT ga.ledger_project_id) > 0 AND count(DISTINCT ga.company_division_id_code) > 0 THEN 'Various'::text
            ELSE NULL::text
        END AS project,
    lbs.bank_uuid AS sending_bank,
    lpgl.project_uuid,
    pi.hold_payment
   FROM ledgerservice.gl_transaction gl
     JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.gl_account ga ON ga.gl_account_id = det.gl_account_id
     LEFT JOIN ledgerservice.ledger_project lp ON lp.ledger_project_id = ga.ledger_project_id
     LEFT JOIN ledgerservice.ledger_project lpgl ON lpgl.ledger_project_id = gl.ledger_project_id
     LEFT JOIN ledgerservice.batch b ON b.batch_id = gl.batch_id
     LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
     LEFT JOIN ledgerservice.gl_transaction_payment gtp ON gtp.payment_info_id = pi.payment_info_id
     LEFT JOIN ledgerservice.ledger_bank lbr ON lbr.ledger_bank_id = pi.ledger_bank_id
     LEFT JOIN ledgerservice.ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
  GROUP BY gl.gl_transaction_id, gl.external_id, gl.ledger_company_id, gl.ledger_project_id, gl.batch_id, gl.subsystem_type, gl.gl_transaction_type, gl.transaction_number, gl.created_ts, gl.document_number, gl.document_date, gl.description, gl.post_date, gl.post_state, gl.reversal_date, gl.reference_gl_transaction_id, gl.recurrence_type, gl.recurrence_start_date, gl.recurrence_end_date, gl.thirteenth_period, gl.created_by_user, gl.last_modified_user, gl.has_errors, lc.company_uuid, b.name, b.company_uuid, b.user_uuid, b.retain_batch, b.shared_batch, b.is_default, b.allow_journals, b.allow_payables, b.allow_receivables, b.allow_pettycash, b.allow_creditcard, pi.payment_info_id, pi.reference_po, pi.vendor_uuid, pi.due_date, gl.document_amount, (( SELECT max(payment.payment_date) AS max
           FROM ledgerservice.payment
          WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                   FROM ledgerservice.gl_transaction_payment pr_gtl
                  WHERE pr_gtl.payment_info_id = pi.payment_info_id)))), pi.hold_payment, (( SELECT lb.bank_uuid
           FROM ledgerservice.payment pm
             LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id
          WHERE (pm.payment_id IN ( SELECT bgtl.payment_id
                   FROM ledgerservice.gl_transaction_payment bgtl
                  WHERE bgtl.payment_info_id = pi.payment_info_id
                 LIMIT 1)))), (
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_ref
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) > 1 THEN 'Various'::character varying
            ELSE NULL::character varying
        END), pi.customer_uuid, pi.sales_rep_uuid, lbr.bank_uuid, lbs.bank_uuid, lpgl.project_uuid, (
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_date
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            ELSE NULL::date
        END), (
        CASE
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) = 1 THEN ( SELECT payment.payment_type
               FROM ledgerservice.payment
              WHERE (payment.payment_id IN ( SELECT pr_gtl.payment_id
                       FROM ledgerservice.gl_transaction_payment pr_gtl
                      WHERE pr_gtl.payment_info_id = pi.payment_info_id
                     LIMIT 1)))
            WHEN (( SELECT count(pr_gtl.payment_id) AS count
               FROM ledgerservice.gl_transaction_payment pr_gtl
              WHERE pr_gtl.payment_info_id = pi.payment_info_id)) > 1 THEN 'Various'::character varying
            ELSE NULL::character varying
        END);
 


