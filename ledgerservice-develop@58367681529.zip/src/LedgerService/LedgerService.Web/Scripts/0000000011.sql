SET search_path=ledgerservice, PUBLIC; 
CREATE OR replace VIEW v_linetransactiondetails 
AS 
  (SELECT * 
   FROM   (SELECT gl.gl_transaction_id, 
                  gl.external_id, 
                  gl.ledger_company_id, 
                  gl.batch_id, 
                  gl.subsystem_type, 
                  gl.gl_transaction_type, 
                  gl.transaction_number, 
                  gl.entry_date, 
                  gl.document_number, 
                  gl.document_date, 
                  gl.description  AS gl_description, 
                  gl.post_date, 
                  gl.post_state, 
                  gl.reversal_date, 
                  gl.reference_gl_transaction_id, 
                  gl.recurrence_type, 
                  gl.recurrence_start_date, 
                  gl.recurrence_end_date, 
                  gl.thirteenth_period, 
                  gl.created_by_user, 
                  gl.last_modified_user, 
                  gl.has_errors, 
                  lc.company_uuid, 
                  lp.project_uuid, 
                  det.gl_transaction_detail_id, 
                  det.line_number, 
                  det.amount, 
                  det.description AS detail_description, 
                  det.ca_tax_credit_id, 
                  gla.gl_account_id, 
                  gla.ledger_coa_id, 
                  gla.ledger_project_id, 
                  gla.company_division_id_code, 
                  gla.company_subaccount_id_code, 
                  gla.detail_id_code, 
                  gla.memo_freefield1, 
                  gla.memo_freefield2 
           FROM   gl_transaction gl 
                  left join ledger_company lc 
                         ON lc.ledger_company_id = gl.ledger_company_id 
                  left join gl_transaction_detail det 
                         ON det.gl_transaction_id = gl.gl_transaction_id 
                  left join gl_account gla 
                         ON gla.gl_account_id = det.gl_account_id 
                  left join ledger_project lp 
                         ON lp.ledger_project_id = gl.ledger_project_id)AS 
          selectAll); 