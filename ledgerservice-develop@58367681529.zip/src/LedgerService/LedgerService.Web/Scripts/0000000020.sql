DROP VIEW IF EXISTS v_HeaderTransactions;
DROP VIEW IF EXISTS v_LineTransactionDetails;

ALTER TABLE gl_transaction ALTER COLUMN post_date TYPE date;
ALTER TABLE gl_transaction RENAME COLUMN entry_date TO created_ts;



CREATE OR REPLACE VIEW ledgerservice.v_headertransactions
 AS
 SELECT gl.gl_transaction_id,
    gl.external_id,
    gl.ledger_company_id,
    gl.ledger_project_id,
    gl.batch_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.transaction_number,
    gl.created_ts,
    gl.document_number,
    gl.document_date,
    gl.description,
    gl.post_date,
    gl.post_state,
    gl.reversal_date,
    gl.reference_gl_transaction_id,
    gl.recurrence_type,
    gl.recurrence_start_date,
    gl.recurrence_end_date,
    gl.thirteenth_period,
    gl.created_by_user,
    gl.last_modified_user,
    gl.has_errors,
	gl.document_amount,
    lc.company_uuid,
    b.name AS batch_name,
    b.company_uuid AS user_batch_company_uuid,
    b.user_uuid,
    b.retain_batch,
    b.shared_batch,
    b.is_default,
    b.allow_journals,
    b.allow_payables,
    b.allow_receivables,
    b.allow_pettycash,
    b.allow_creditcard,
	pi.payment_info_id,
    pi.reference_po,
    pi.vendor_uuid,
    pi.due_date,
    sum(det.amount) AS total_amount
   FROM ledgerservice.gl_transaction gl
     JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
     LEFT JOIN ledgerservice.gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
     LEFT JOIN ledgerservice.batch b ON b.batch_id = gl.batch_id
	 LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
  GROUP BY gl.gl_transaction_id, gl.external_id, gl.ledger_company_id, gl.ledger_project_id, gl.batch_id, gl.subsystem_type, gl.gl_transaction_type, gl.transaction_number, gl.created_ts, gl.document_number, gl.document_date, gl.description, gl.post_date, gl.post_state, gl.reversal_date, gl.reference_gl_transaction_id, gl.recurrence_type, gl.recurrence_start_date, gl.recurrence_end_date, gl.thirteenth_period, gl.created_by_user, gl.last_modified_user, gl.has_errors, lc.company_uuid, b.name, b.company_uuid, b.user_uuid, b.retain_batch, b.shared_batch, b.is_default, b.allow_journals, b.allow_payables, b.allow_receivables, b.allow_pettycash, b.allow_creditcard,pi.payment_info_id, pi.reference_po, pi.vendor_uuid, pi.due_date, gl.document_amount;


 CREATE OR REPLACE view v_LineTransactionDetails 
AS 
  (SELECT gl.gl_transaction_id, 
          gl.external_id, 
          gl.ledger_company_id, 
          gl.batch_id, 
          gl.subsystem_type, 
          gl.gl_transaction_type, 
          gl.transaction_number, 
          gl.created_ts, 
          gl.document_number, 
          gl.document_date, 
          gl.description  AS gl_description, 
          gl.post_date, 
          gl.post_state, 
          gl.reversal_date, 
          gl.reference_gl_transaction_id, 
          gl.recurrence_type, 
          gl.recurrence_start_date, 
          gl.recurrence_end_date, 
          gl.thirteenth_period, 
          gl.created_by_user, 
          gl.last_modified_user, 
          gl.has_errors, 
          lc.company_uuid, 
          lp.project_uuid, 
          det.gl_transaction_detail_id, 
          det.line_number, 
          det.amount, 
          coalesce(det.description,gl.description) AS detail_description, 
          det.ca_tax_credit_id, 
          gla.gl_account_id, 
          gla.ledger_coa_id, 
          gla.ledger_project_id, 
          gla.company_division_id_code, 
          gla.company_subaccount_id_code, 
          gla.detail_id_code, 
          gla.memo_freefield1, 
          gla.memo_freefield2 
   FROM   gl_transaction gl 
          LEFT JOIN ledger_company lc 
                 ON lc.ledger_company_id = gl.ledger_company_id 
          LEFT JOIN gl_transaction_detail det 
                 ON det.gl_transaction_id = gl.gl_transaction_id 
          LEFT JOIN gl_account gla 
                 ON gla.gl_account_id = det.gl_account_id 
          LEFT JOIN ledger_project lp 
                 ON lp.ledger_project_id = gl.ledger_project_id); 
