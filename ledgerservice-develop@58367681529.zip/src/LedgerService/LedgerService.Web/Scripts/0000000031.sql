set search_path=ledgerservice,public;

insert into subsystem_type (subsystem_type,description)
values ('AR','Accounts Receivable');

insert into gl_transaction_type(gl_transaction_type,subsystem_type,is_system_only)
values('STANDARD','AR',false);

alter table payment_info
add column if not exists customer_uuid uuid null,
add column if not exists sales_rep_uuid uuid null;

drop view v_headertransactions;

create or replace view v_headertransactions as
 select gl.gl_transaction_id,
    gl.external_id,
    gl.ledger_company_id,
    gl.ledger_project_id,
    gl.batch_id,
    gl.subsystem_type,
    gl.gl_transaction_type,
    gl.transaction_number,
    gl.created_ts,
    gl.document_number,
    gl.document_date,
    gl.description,
    gl.post_date,
    gl.post_state,
    gl.reversal_date,
    gl.reference_gl_transaction_id,
    gl.recurrence_type,
    gl.recurrence_start_date,
    gl.recurrence_end_date,
    gl.thirteenth_period,
    gl.created_by_user,
    gl.last_modified_user,
    gl.has_errors,
    gl.document_amount,
    lc.company_uuid,
    b.name AS batch_name,
    b.company_uuid AS user_batch_company_uuid,
    b.user_uuid,
    b.retain_batch,
    b.shared_batch,
    b.is_default,
    b.allow_journals,
    b.allow_payables,
    b.allow_receivables,
    b.allow_pettycash,
    b.allow_creditcard,
    pi.payment_info_id,
    pi.reference_po,
    pi.vendor_uuid,
    pi.due_date,
    lb.bank_uuid,
    pm.payment_number,
    pm.payment_type,
    pm.payment_date,
    pm.payment_ref,
    sum(det.amount) AS total_amount,
	pi.customer_uuid,
	pi.sales_rep_uuid
   from ledgerservice.gl_transaction gl
     join ledgerservice.ledger_company lc on lc.ledger_company_id = gl.ledger_company_id
     left join ledgerservice.gl_transaction_detail det on det.gl_transaction_id = gl.gl_transaction_id
     left join ledgerservice.batch b on b.batch_id = gl.batch_id
     left join ledgerservice.payment_info pi on gl.gl_transaction_id = pi.gl_transaction_id
     left join ledgerservice.payment pm on pm.payment_id = pi.payment_id
     left join ledgerservice.ledger_bank lb on lb.ledger_bank_id = pm.ledger_bank_id
  group by gl.gl_transaction_id
	,gl.external_id
	,gl.ledger_company_id
	,gl.ledger_project_id
	,gl.batch_id
	,gl.subsystem_type
	,gl.gl_transaction_type
	,gl.transaction_number
	,gl.created_ts
	,gl.document_number
	,gl.document_date
	,gl.description
	,gl.post_date
	,gl.post_state
	,gl.reversal_date
	,gl.reference_gl_transaction_id
	,gl.recurrence_type
	,gl.recurrence_start_date
	,gl.recurrence_end_date
	,gl.thirteenth_period
	,gl.created_by_user
	,gl.last_modified_user
	,gl.has_errors
	,lc.company_uuid
	,b.name
	,b.company_uuid
	,b.user_uuid
	,b.retain_batch
	,b.shared_batch
	,b.is_default
	,b.allow_journals
	,b.allow_payables
	,b.allow_receivables
	,b.allow_pettycash
	,b.allow_creditcard
	,pi.payment_info_id
	,pi.reference_po
	,pi.vendor_uuid
	,pi.due_date
	,gl.document_amount
	,lb.bank_uuid
	,pm.payment_number
	,pm.payment_type
	,pm.payment_date
	,pm.payment_ref
	,pi.customer_uuid
	,pi.sales_rep_uuid;

  ALTER TABLE ledgerservice.v_headertransactions
    OWNER TO calgsv_write;
