﻿set search_path=ledgerservice,public;

CREATE TABLE bank_reconciliation
(
    bank_reconciliation_id BIGSERIAL PRIMARY KEY NOT NULL,
    ledger_bank_id bigint REFERENCES ledger_bank,
    beginning_balance NUMERIC(16,6),
    ending_balance NUMERIC(16,6),
    statement_date DATE,
    finalized BOOLEAN DEFAULT NULL,
    finalized_ts timestamp with time zone NOT NULL DEFAULT now(),
    created_ts timestamp with time zone NOT NULL DEFAULT now(),
    created_by_user uuid,
    modified_ts timestamp with time zone NOT NULL DEFAULT now(),
    last_modified_user uuid
);

 CREATE TABLE bank_charge_type
(
    bank_charge_typename CHARACTER VARYING(50) PRIMARY KEY NOT NULL

);

CREATE TABLE bank_reconciliation_charges
(
  bank_reconciliation_charge_id BIGSERIAL PRIMARY KEY NOT NULL,
  bank_reconciliation_id bigint references bank_reconciliation,
  bank_charge_typename CHARACTER VARYING(50) NOT NULL references bank_charge_type,
  gl_account_id bigint NOT NULL references gl_account,
  amount NUMERIC(16,6),
  description CHARACTER VARYING(50),
  date DATE 
);

CREATE TABLE bank_reconciliation_journal
(
  bank_reconciliation_journal_id BIGSERIAL PRIMARY KEY NOT NULL,
  bank_reconciliation_id bigint references bank_reconciliation,
  gl_transaction_id bigint references ledgerservice.gl_transaction
);


Insert into bank_charge_type(bank_charge_typename) values
    ('Bank Charge'),
    ('Interest Earned');
