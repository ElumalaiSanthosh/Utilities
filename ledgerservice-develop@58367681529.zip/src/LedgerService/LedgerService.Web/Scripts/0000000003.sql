set search_path=ledgerservice,public;

alter table gl_account
add column if not exists ledger_company_id bigint references ledger_company;

alter table gl_transaction
add column if not exists  variance_amount numeric(16,6);

alter table gl_transaction_detail
add column if not exists  item_memo_1 character varying(250),
add column if not exists  item_memo_2 character varying(250);

CREATE TABLE gl_acct_memo
(
    gl_memo_id BIGSERIAL PRIMARY KEY,
    gl_transaction_detail_id bigint NOT NULL references gl_transaction_detail,
    item_memo_1 character varying(250),
    item_memo_2 character varying(250)
);