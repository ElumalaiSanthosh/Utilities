set search_path=ledgerservice,public;

ALTER TABLE payment_info
    ADD  COLUMN if not exists check_memo character varying(150);


CREATE TABLE if not exists ledger_tax_form
(
    ledger_tax_form_id BIGSERIAL PRIMARY KEY,
    name character varying(50)
);


CREATE TABLE if not exists ledger_tax_code
(
    ledger_tax_code_id BIGSERIAL PRIMARY KEY,
    ledger_tax_form_id bigint references ledger_tax_form,
    tax_code character varying(10)
);

ALTER TABLE gl_account
add column ledger_tax_code_id bigint references ledger_tax_code;
