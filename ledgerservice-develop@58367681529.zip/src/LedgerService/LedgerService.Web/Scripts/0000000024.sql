insert into ledger_tax_form(name) values ('1099');
 
insert into ledger_tax_code(ledger_tax_form_id, tax_code) values 
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'01'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'02'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'03'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'04'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'06'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'07'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'14'),
((SELECT 1 FROM ledger_tax_form WHERE name='1099'),'16')


