CREATE TABLE ledgerservice.positive_pay(
	positive_pay_id BIGSERIAL PRIMARY KEY,
	external_id uuid DEFAULT uuid_generate_v4(),
	ledger_bank_id bigint NOT NULL references ledgerservice.ledger_bank,
	created_time timestamp without time zone NOT NULL,
	void_count int NOT NULL,
	void_amount numeric(16,6),
	check_amount numeric(16,6),
	check_count int NOT NULL,
	funding_date timestamp without time zone,
	file_name character varying(255) COLLATE pg_catalog."default",
	file_size character varying(255) COLLATE pg_catalog."default",
	eom_date timestamp without time zone,
	is_last_transfer boolean NOT NULL default false,
	retransfer_time timestamp without time zone,
	is_eft boolean NOT NULL default false,
	is_ach boolean NOT NULL default false,
	is_ep_send boolean NOT NULL default false,
	transfer_status_id int NULL,
	transfer_status_message character varying(255) COLLATE pg_catalog."default",
	transfer_code character varying(4) COLLATE pg_catalog."default"
	)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;


CREATE UNIQUE INDEX idx_unique_positive_pay_external_id
    ON ledgerservice.positive_pay USING btree
    (external_id)
    TABLESPACE pg_default;

CREATE TABLE ledgerservice.positive_pay_payment(
	positive_pay_payment_id BIGSERIAL PRIMARY KEY,
	positive_pay_id bigint NOT NULL references ledgerservice.positive_pay,
	payment_id bigint NOT NULL references ledgerservice.positive_pay
	)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

