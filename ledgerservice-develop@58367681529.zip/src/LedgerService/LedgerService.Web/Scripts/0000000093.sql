ALTER TABLE ledgerservice.payment ADD COLUMN external_id uuid DEFAULT uuid_generate_v4();

CREATE UNIQUE INDEX idx_unique_payment_external_id
    ON ledgerservice.payment USING btree
    (external_id)
    TABLESPACE pg_default;

drop VIEW ledgerservice.v_payment_records;

CREATE VIEW ledgerservice.v_payment_records AS
 SELECT 
    payment_id,
    external_id as payment_uuid,
    payment_type,
    payment_number,    
    payment_date,
    check_memo,
    payment_ref,
    created_ts,
    uc.user_uuid as ledger_user_created_uuid,
    um.user_uuid as ledger_user_last_modified_uuid,
    post_payment_gl_transaction_id,
    amount,
    payee_name,
    posted_ts,
    amount_subject_to_tax,
    discount_amount,
 	lv.vendor_uuid,
	lb.bank_uuid    
   FROM ledgerservice.payment pm
     JOIN ledgerservice.ledger_vendor lv ON lv.ledger_vendor_id = pm.ledger_vendor_id
	 JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pm.ledger_bank_id
     LEFT JOIN ledgerservice.ledger_user uc ON uc.ledger_user_id = pm.ledger_user_created_id
     LEFT JOIN ledgerservice.ledger_user um ON um.ledger_user_id = pm.ledger_user_last_modified_id;