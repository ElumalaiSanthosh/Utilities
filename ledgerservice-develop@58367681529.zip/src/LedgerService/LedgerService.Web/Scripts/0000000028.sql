set search_path=ledgerservice,public;

create table if not exists ledger_bank(
	ledger_bank_id bigserial primary key,
	bank_uuid uuid not null
);

create table if not exists payment_type(
	payment_type character varying(50) not null primary key
);

create unique index idx_unique_bank_uuid on ledger_bank(bank_uuid);

create table if not exists payment(
	payment_id bigserial primary key,
	ledger_bank_id bigint references ledger_bank,
	payment_type character varying(50) references payment_type,
	payment_number bigint,
	vendor_uuid uuid,
	payment_date date,
	check_memo character varying(150),
	payment_ref character varying(100),
	created_ts timestamp default now(),
	created_by_user uuid,
	last_modified_user uuid,
	posted_ts boolean
);

alter table payment_info add column payment_id bigint null references payment;

insert into payment_type(payment_type)
values('Check'),
	  ('Manual Check'),
	  ('Wire Transfer'),
	  ('Cash');