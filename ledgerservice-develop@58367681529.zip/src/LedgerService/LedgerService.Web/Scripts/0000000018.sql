set search_path=ledgerservice,public;
 
CREATE OR REPLACE FUNCTION alphanumeric_sort(
    text)
    RETURNS character varying
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE
AS $BODY$
declare input_value character varying;
BEGIN
input_value:= trim(lower(regexp_replace((lower($1)), '[!@#$%^&*(),.?":{}|<>]', ' ', 'g')));
IF coalesce(TRIM(input_value), '') = '' THEN
  return '0';
ELSE
 return
                lpad(COALESCE(SUBSTRING(input_value FROM '^(\d+)'), lpad('', 50, '9')), 50, '0') ||
                rpad(COALESCE(SUBSTRING(input_value FROM '[a-zA-z_-]+'), ''), 50, '0') ||
                lpad(COALESCE(SUBSTRING(input_value FROM '(\d+)$'), ''), 50, '0') ||
                input_value;
END IF;
END; $BODY$;