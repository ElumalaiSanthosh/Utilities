set search_path=ledgerservice,public;

ALTER TABLE gl_transaction ALTER COLUMN document_number DROP NOT NULL;
ALTER TABLE gl_transaction ALTER COLUMN document_date DROP NOT NULL;

