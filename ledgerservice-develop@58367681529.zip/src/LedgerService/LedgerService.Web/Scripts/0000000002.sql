set search_path=ledgerservice,public;

alter table batch alter column company_uuid set not null;
alter table batch alter column user_uuid set not null;
alter table batch alter column name set not null;
