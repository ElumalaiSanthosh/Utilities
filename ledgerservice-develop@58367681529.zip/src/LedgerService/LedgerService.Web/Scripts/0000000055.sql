﻿set search_path=ledgerservice,public;

INSERT INTO ledgerservice.gl_transaction_type(
	gl_transaction_type, subsystem_type, is_system_only)
	VALUES ('STANDARD', 'PP', true);
