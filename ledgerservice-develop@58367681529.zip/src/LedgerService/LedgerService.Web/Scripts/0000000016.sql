set search_path=ledgerservice,public;

alter table gl_transaction
drop column if exists void_date;