﻿set search_path=ledgerservice,public;

ALTER TABLE bank_reconciliation_charges 
    ALTER COLUMN description TYPE CHARACTER VARYING(150);

CREATE TABLE bank_reconciliation_clearing
(
  bank_reconciliation_clearing_id BIGSERIAL PRIMARY KEY NOT NULL,
  bank_reconciliation_id bigint references bank_reconciliation,
  gl_transaction_id bigint references gl_transaction
);

