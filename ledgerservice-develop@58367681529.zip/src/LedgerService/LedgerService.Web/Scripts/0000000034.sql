set search_path=ledgerservice,public;


CREATE OR REPLACE VIEW ledgerservice.v_bankactivities
 AS
 WITH gl_adjustments AS (
         SELECT gl.gl_transaction_id,
            gl.external_id,
            gl.subsystem_type,
            gl.gl_transaction_type,
            gl.document_number,
            ''::text AS vendor_uuid,
            gl.document_date,
            gl.post_state,
            gl.document_amount,
            lc.company_uuid,
                CASE
                    WHEN sign(det.amount) = '-1'::numeric THEN abs(det.amount)
                    ELSE NULL::numeric
                END AS debit,
                CASE
                    WHEN sign(det.amount) = 1::numeric THEN det.amount
                    ELSE NULL::numeric
                END AS credit,
            ''::text AS bank_uuid,
            0 AS ar_gl_transaction_id,
            0 AS post_payment_gl_transaction_id,
            ga.detail_id_code,
            'Journal Entry'::text AS transaction_type,
                CASE
                    WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
                    ELSE '-'::character varying
                END AS void_date,
            'ADJUSTMENTS'::text AS bank_activity_type
           FROM ledgerservice.gl_transaction gl
             LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
             LEFT JOIN ledgerservice.gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
             LEFT JOIN ledgerservice.gl_account ga ON ga.gl_account_id = det.gl_account_id
          WHERE gl.subsystem_type::text = 'JE'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text) AND ga.detail_id_code IS NOT NULL
        ), payments AS (
         SELECT gl.gl_transaction_id,
            gl.external_id,
            gl.subsystem_type,
            gl.gl_transaction_type,
            gl.document_number,
            pi.vendor_uuid::character varying AS vendor_uuid,
            gl.document_date,
            gl.post_state,
            gl.document_amount,
            lc.company_uuid,
                CASE
                    WHEN sign(det.amount) = 1::numeric THEN det.amount
                    ELSE NULL::numeric
                END AS debit,
                CASE
                    WHEN sign(det.amount) = '-1'::numeric THEN abs(det.amount)
                    ELSE NULL::numeric
                END AS credit,
            lb.bank_uuid::character varying AS bank_uuid,
            0 AS ar_gl_transaction_id,
            payment.post_payment_gl_transaction_id,
            ga.detail_id_code,
            payment.payment_type AS transaction_type,
                CASE
                    WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
                    ELSE '-'::character varying
                END AS void_date,
            'PAYMENTS'::text AS bank_activity_type
           FROM ledgerservice.gl_transaction gl
             LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
             LEFT JOIN ledgerservice.gl_transaction_detail det ON det.gl_transaction_id = gl.gl_transaction_id
             LEFT JOIN ledgerservice.gl_account ga ON ga.gl_account_id = det.gl_account_id
             LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
             LEFT JOIN ledgerservice.payment payment ON payment.payment_id = pi.payment_id
             LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = payment.ledger_bank_id
          WHERE gl.subsystem_type::text = 'PP'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text) AND gl.gl_transaction_type::text = 'PAYMENTS'::text AND gl.gl_transaction_id = 2393
        ), deposits AS (
         SELECT gl.gl_transaction_id,
            gl.external_id,
            gl.subsystem_type,
            gl.gl_transaction_type,
            gl.document_number,
            ''::text AS vendor_uuid,
            gl.document_date,
            gl.post_state,
            gl.document_amount,
            lc.company_uuid,
                CASE
                    WHEN sign(gl.document_amount) = '-1'::integer::numeric THEN abs(gl.document_amount)
                    ELSE NULL::numeric
                END AS debit,
                CASE
                    WHEN sign(gl.document_amount) = 1::numeric THEN gl.document_amount
                    ELSE NULL::numeric
                END AS credit,
            lb.bank_uuid::character varying AS bank_uuid,
            0 AS ar_gl_transaction_id,
            0 AS post_payment_gl_transaction_id,
            ''::text AS detail_id_code,
            'Deposit'::text AS transaction_type,
                CASE
                    WHEN gl.post_state::text = 'VOIDED'::text THEN gl.document_date::character varying
                    ELSE '-'::character varying
                END AS void_date,
            'DEPOSITS'::text AS bank_activity_type,
            lbs.bank_uuid::character varying AS sending_bank_uuid,
            pi.sending_bank_id
           FROM ledgerservice.gl_transaction gl
             LEFT JOIN ledgerservice.ledger_company lc ON lc.ledger_company_id = gl.ledger_company_id
             LEFT JOIN ledgerservice.payment_info pi ON gl.gl_transaction_id = pi.gl_transaction_id
             LEFT JOIN ledgerservice.ledger_bank lb ON lb.ledger_bank_id = pi.ledger_bank_id
             LEFT JOIN ledgerservice.ledger_bank lbs ON lbs.ledger_bank_id = pi.sending_bank_id
          WHERE gl.subsystem_type::text = 'DE'::text AND (gl.post_state::text = 'POSTED'::text OR gl.post_state::text = 'VOIDED'::text)
        ), bank_activity AS (
         SELECT gl_adjustments.gl_transaction_id,
            gl_adjustments.external_id,
            gl_adjustments.subsystem_type,
            gl_adjustments.gl_transaction_type,
            gl_adjustments.document_number,
            gl_adjustments.vendor_uuid,
            gl_adjustments.document_date,
            gl_adjustments.post_state,
            gl_adjustments.document_amount,
            gl_adjustments.company_uuid,
            gl_adjustments.debit,
            gl_adjustments.credit,
            gl_adjustments.bank_uuid,
            gl_adjustments.ar_gl_transaction_id,
            gl_adjustments.post_payment_gl_transaction_id,
            gl_adjustments.detail_id_code,
            gl_adjustments.transaction_type,
            gl_adjustments.void_date,
            gl_adjustments.bank_activity_type
           FROM gl_adjustments
        UNION ALL
         SELECT payments.gl_transaction_id,
            payments.external_id,
            payments.subsystem_type,
            payments.gl_transaction_type,
            payments.document_number,
            payments.vendor_uuid,
            payments.document_date,
            payments.post_state,
            payments.document_amount,
            payments.company_uuid,
            payments.debit,
            payments.credit,
            payments.bank_uuid,
            payments.ar_gl_transaction_id,
            payments.post_payment_gl_transaction_id,
            payments.detail_id_code,
            payments.transaction_type,
            payments.void_date,
            payments.bank_activity_type
           FROM payments
        UNION ALL
         SELECT deposits.gl_transaction_id,
            deposits.external_id,
            deposits.subsystem_type,
            deposits.gl_transaction_type,
            deposits.document_number,
            deposits.vendor_uuid,
            deposits.document_date,
            deposits.post_state,
            deposits.document_amount,
            deposits.company_uuid,
            deposits.debit,
            deposits.credit,
            deposits.bank_uuid,
            deposits.ar_gl_transaction_id,
            deposits.post_payment_gl_transaction_id,
            deposits.detail_id_code,
            deposits.transaction_type,
            deposits.void_date,
            deposits.bank_activity_type
           FROM deposits
          WHERE deposits.sending_bank_id IS NULL
        UNION ALL
         SELECT deposits.gl_transaction_id,
            deposits.external_id,
            deposits.subsystem_type,
            deposits.gl_transaction_type,
            deposits.document_number,
            deposits.vendor_uuid,
            deposits.document_date,
            deposits.post_state,
            deposits.document_amount,
            deposits.company_uuid,
            deposits.debit,
            NULL::numeric,
            deposits.sending_bank_uuid,
            deposits.ar_gl_transaction_id,
            deposits.post_payment_gl_transaction_id,
            deposits.detail_id_code,
            'Bank Transfer'::text,
            deposits.void_date,
            deposits.bank_activity_type
           FROM deposits
          WHERE deposits.sending_bank_id IS NOT NULL
        UNION ALL
         SELECT deposits.gl_transaction_id,
            deposits.external_id,
            deposits.subsystem_type,
            deposits.gl_transaction_type,
            deposits.document_number,
            deposits.vendor_uuid,
            deposits.document_date,
            deposits.post_state,
            deposits.document_amount,
            deposits.company_uuid,
            NULL::numeric,
            deposits.credit,
            deposits.bank_uuid,
            deposits.ar_gl_transaction_id,
            deposits.post_payment_gl_transaction_id,
            deposits.detail_id_code,
            'Bank Transfer'::text,
            deposits.void_date,
            deposits.bank_activity_type
           FROM deposits
          WHERE deposits.sending_bank_id IS NOT NULL
        )
 SELECT bank_activity.gl_transaction_id,
    bank_activity.external_id,
    bank_activity.subsystem_type,
    bank_activity.gl_transaction_type,
    bank_activity.document_number,
    bank_activity.vendor_uuid,
    bank_activity.document_date,
    bank_activity.post_state,
    bank_activity.document_amount,
    bank_activity.company_uuid,
    bank_activity.debit,
    bank_activity.credit,
    bank_activity.bank_uuid,
    bank_activity.ar_gl_transaction_id,
    bank_activity.post_payment_gl_transaction_id,
    bank_activity.detail_id_code,
    bank_activity.transaction_type,
    bank_activity.void_date,
    bank_activity.bank_activity_type
   FROM bank_activity;
