﻿CREATE UNIQUE INDEX idx_unique_positive_pay_transfer_code
    ON ledgerservice.positive_pay USING btree
    (ledger_bank_id,transfer_code)
    TABLESPACE pg_default;

CREATE UNIQUE INDEX idx_unique_positive_pay_payment
    ON ledgerservice.positive_pay_payment USING btree
    (payment_id)
    TABLESPACE pg_default;