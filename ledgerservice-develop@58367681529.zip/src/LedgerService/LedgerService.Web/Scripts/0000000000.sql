/*
--create database
CREATE DATABASE "ca-ledgerservice"
    WITH
    OWNER = calgsv_admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    CONNECTION LIMIT = -1;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

GRANT ALL ON DATABASE "ca-ledgerservice" TO calgsv_admin;


--create ledgerservice schema
CREATE SCHEMA ledgerservice AUTHORIZATION calgsv_admin;

GRANT ALL ON SCHEMA ledgerservice TO calgsv_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA ledgerservice TO calgsv_write WITH GRANT OPTION;
GRANT USAGE ON SCHEMA ledgerservice TO calgsv_read;

ALTER DEFAULT PRIVILEGES IN SCHEMA ledgerservice
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO calgsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA ledgerservice
GRANT SELECT, USAGE ON SEQUENCES TO calgsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA ledgerservice
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO calgsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA ledgerservice
GRANT SELECT, USAGE ON SEQUENCES TO calgsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA ledgerservice GRANT SELECT ON TABLES TO calgsv_read;

SET search_path=ledgerservice,public;

--create po schema
CREATE SCHEMA po AUTHORIZATION calgsv_admin;

GRANT ALL ON SCHEMA po TO calgsv_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA po TO calgsv_write WITH GRANT OPTION;
GRANT USAGE ON SCHEMA po TO calgsv_read;

ALTER DEFAULT PRIVILEGES IN SCHEMA po
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO calgsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA po
GRANT SELECT, USAGE ON SEQUENCES TO calgsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA po
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO calgsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA po
GRANT SELECT, USAGE ON SEQUENCES TO calgsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA po GRANT SELECT ON TABLES TO calgsv_read;

CREATE TABLE db_properties
(
    db_properties_id SERIAL PRIMARY KEY,
    last_update timestamp,
    host_name character varying(255),
    script character varying(255)
);
*/


CREATE TABLE batch
(
    batch_id BIGSERIAL PRIMARY KEY,
    name character varying(50)
);

CREATE TABLE subsystem_type
(
    subsystem_type character varying(10) PRIMARY KEY,
    description character varying(30) NOT NULL
);

CREATE TABLE gl_transaction_type
(
    gl_transaction_type character varying(30) PRIMARY KEY,
    subsystem_type character varying(10) NOT NULL references subsystem_type,
    is_system_only boolean NOT NULL DEFAULT false
);

CREATE TABLE post_state
(
    post_state character varying(20) PRIMARY KEY
);

CREATE TABLE recurrence_type
(
    recurrence_type character varying(20) PRIMARY KEY
);

CREATE TABLE ledger_company
(
    ledger_company_id BIGSERIAL PRIMARY KEY,
    company_uuid uuid NOT NULL
);

CREATE TABLE ledger_project
(
    ledger_project_id BIGSERIAL PRIMARY KEY,
    project_uuid uuid NOT NULL
);

CREATE TABLE ledger_coa
(
    ledger_coa_id BIGSERIAL PRIMARY KEY,
    coa_uuid uuid NOT NULL
);

CREATE TABLE ca_tax_credit
(
    ca_tax_credit_id BIGSERIAL PRIMARY KEY,
    ledger_company_id bigint NOT NULL references ledger_company,
    tax_credit character varying(50)
);

CREATE TABLE gl_account
(
    gl_account_id BIGSERIAL PRIMARY KEY,
    ledger_coa_id bigint NOT NULL references ledger_coa,
    ledger_project_id bigint references ledger_project,
    company_division_id_code character varying(15),
    company_subaccount_id_code character varying(15),
    detail_id_code character varying(15)
);

CREATE TABLE gl_transaction
(
    gl_transaction_id BIGSERIAL PRIMARY KEY,
    external_id uuid DEFAULT uuid_generate_v4(),
    ledger_company_id bigint references ledger_company,
    ledger_project_id bigint references ledger_project,
    batch_id bigint references batch,
    subsystem_type character varying(10) NOT NULL references subsystem_type,
    gl_transaction_type character varying(30) NOT NULL references gl_transaction_type,
    transaction_number character varying(30),
    entry_date date NOT NULL DEFAULT CURRENT_DATE,
    document_number character varying(30) NOT NULL,
    document_date date NOT NULL,
    description character varying(100),
    post_date date,
    post_state character varying(20) NOT NULL references post_state,
    reversal_date date,
    reference_gl_transaction_id bigint references gl_transaction,
    recurrence_type character varying(20) references recurrence_type,
    recurrence_start_date date,
    recurrence_end_date date,
    thirteenth_period boolean
);

CREATE TABLE gl_transaction_detail
(
    gl_transaction_detail_id BIGSERIAL PRIMARY KEY,
    gl_transaction_id bigint NOT NULL references gl_transaction,
    line_number integer NOT NULL,
    amount numeric(16,6),
    description character varying(100),
    ca_tax_credit_id bigint references ca_tax_credit,
    gl_account_id bigint NOT NULL references gl_account
);

insert into subsystem_type (subsystem_type, description) values
    ('JE', 'Journal Entry');

insert into gl_transaction_type(gl_transaction_type, subsystem_type, is_system_only) values
    ('STANDARD', 'JE', false),
    ('REVERSING', 'JE', false),
    ('RECURRING', 'JE', false),
    ('ICT', 'JE', true);

insert into post_state(post_state) values
    ('UNPOSTED'),
    ('POSTED');

insert into recurrence_type(recurrence_type) values
    ('Daily'),
    ('Weekly'),
    ('Monthly'),
    ('Quarterly'),
    ('Yearly');
