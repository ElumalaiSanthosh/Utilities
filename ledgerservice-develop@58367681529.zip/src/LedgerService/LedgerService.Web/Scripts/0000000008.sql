set search_path=ledgerservice,public;

ALTER TABLE gl_transaction

add column if not exists created_by_user uuid,
add column if not exists last_modified_user uuid;