﻿using System;
using Microsoft.AspNetCore.Hosting;
using System.Diagnostics.CodeAnalysis;
using Steeltoe.Extensions.Configuration.ConfigServer;
using Microsoft.Extensions.Configuration;
using Steeltoe.Management.Endpoint;
using Microsoft.Extensions.Hosting;
using NLog.Web;

namespace LedgerService.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
		[ExcludeFromCodeCoverage]
        public static void Main(string[] args)
        {
            var logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

            try
            {
                var host = CreateHostBuilder(args).Build();
                Startup.RunAfterStartup(host.Services);
                host.Run();
            }
            catch (Exception ex)
            {
                //NLog: catch setup errors
                logger.Error(ex, "Stopped program because of exception");

                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                NLog.LogManager.Shutdown();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        [ExcludeFromCodeCoverage]
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .AddConfigServer()
                .ConfigureAppConfiguration(config =>
                {
                    var initialConfig = config.Build();
                    config.AddInMemoryCollection(Startup.GetActuatorProperties(initialConfig));
                    config.AddInMemoryCollection(Startup.GetConnectionStrings(initialConfig));
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                        .UseStartup<Startup>()
                        .UseIISIntegration();
                })
                .UseNLog()
                .AddHypermediaActuator()
                .AddInfoActuator()
                .AddHealthActuator();

    }
}
