﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class LedgerCompaniesController
    {
        /// <summary>
        /// Gets data by searchquery
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="searchKey"></param>
        /// <returns></returns>
        [HttpGet("{companyExternalId}/{searchKey}")]
        public async Task<IActionResult> GetLedgerCompanyBySearchKey(Guid companyExternalId, string searchKey)
        {
            try
            {
                var result = await LedgerCompanyService.GetLedgerCompanyBySearchKey(companyExternalId, searchKey);

                if (result != null) return Ok(result);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
