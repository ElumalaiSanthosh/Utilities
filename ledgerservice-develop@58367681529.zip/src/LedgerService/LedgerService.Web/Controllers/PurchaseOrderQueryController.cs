using ApiService.Commons.DataStore;
using ApiService.Commons.Extensions;
using ApiService.Extensions;
using LedgerService.Models.Dtos;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class PurchaseOrdersController
    {
        /// <summary>
        /// Gets PurchaseOrders with Child data
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <returns></returns>
        [HttpGet("Company/{companyExternalId}/purchaseorders")]
        public async Task<IActionResult> GetPurchaseOrders(Guid companyExternalId, ODataQueryOptions<GlTransaction> options)
        {
            try
            {
                QueryOptions queryOptions = options.ParseOdata();
                var returnMany = (await PurchaseOrderService.GetPurchaseOrders(companyExternalId, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                if (returnMany != null) return Ok(returnMany);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
