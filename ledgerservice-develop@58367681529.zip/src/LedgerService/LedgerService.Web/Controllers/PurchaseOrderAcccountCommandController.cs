﻿using LedgerService.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{

    public partial class PurchaseOrderAccountsController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sameValueForAllRecords"></param>
        /// <param name="poAccounts"></param>
        /// <returns></returns>
        [HttpPatch("patchmany")]
        [ProducesResponseType(200, Type = typeof(List<PurchaseOrderAccount>))]
        public async Task<IActionResult> PatchManyAsync(bool sameValueForAllRecords, [FromBody, Required] List<PurchaseOrderAccount> poAccounts)
        {
            try
            {
                var result = await PurchaseOrderAccountService.PatchManyAsync(poAccounts, sameValueForAllRecords);
                if (result != null)
                    return Ok(result);
                else
                    return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}