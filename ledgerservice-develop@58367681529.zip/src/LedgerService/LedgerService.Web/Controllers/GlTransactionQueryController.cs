using ApiService.Commons.DataStore;
using ApiService.Commons.Extensions;
using ApiService.Extensions;
using LedgerService.Models.Dtos;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class GlTransactionsController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        [HttpGet("Company/{companyExternalId}/Unposted")]
        public async Task<IActionResult> GetUnpostedByLedgerCompanyId(Guid companyExternalId, ODataQueryOptions<GlTransaction> options, string columns = null)
        {
            try
            {
                ICollection<string> listColumns = columns?.Split(',').Select(p => p.Trim()).ToList();
                QueryOptions queryOptions = options.ParseOdata();

                if (listColumns == null || listColumns.Count == 0)
                {
                    var returnMany = (await GlTransactionService.GetUnPostedJournals(companyExternalId, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                    if (returnMany != null) return Ok(returnMany);

                    return NoContent();
                }

                if (listColumns.Count == 1)
                {
                    var returnList = (await GlTransactionService.GetListAsync(listColumns.First(), queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                    if (returnList != null) return Ok(returnList);

                    return NoContent();
                }

                var resultDynamic = (await GlTransactionService.GetDynamicObjectsAsync(listColumns, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                if (resultDynamic != null) return Ok(resultDynamic);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        [HttpGet("Company/{companyExternalId}/Transactions")]
        public async Task<IActionResult> GetTransactions(Guid companyExternalId, ODataQueryOptions<GlTransaction> options, string columns = null)
        {
            try
            {
                ICollection<string> listColumns = columns?.Split(',').Select(p => p.Trim()).ToList();
                QueryOptions queryOptions = options.ParseOdata();

                if (listColumns == null || listColumns.Count == 0)
                {
                    var returnMany = (await GlTransactionService.GetTransactions(companyExternalId, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                    if (returnMany != null) return Ok(returnMany);

                    return NoContent();
                }

                if (listColumns.Count == 1)
                {
                    var returnList = (await GlTransactionService.GetListAsync(listColumns.First(), queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                    if (returnList != null) return Ok(returnList);

                    return NoContent();
                }

                var resultDynamic = (await GlTransactionService.GetDynamicObjectsAsync(listColumns, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                if (resultDynamic != null) return Ok(resultDynamic);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }

        /// <summary>
        /// Gets GlTransactions with Child data
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="columns"></param>
        /// <returns></returns>
        [HttpGet("Company/{companyExternalId}/gltransactions")]
        public async Task<IActionResult> GetGlTransactions(Guid companyExternalId, ODataQueryOptions<GlTransaction> options, string columns = null)
        {
            try
            {
                QueryOptions queryOptions = options.ParseOdata();
                var returnMany = (await GlTransactionService.GetGlTransactions(companyExternalId, queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                if (returnMany != null) return Ok(returnMany);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="subSystemType"></param>
        /// <returns></returns>
        [HttpGet("{companyExternalId}/unPostedExists")]
        public async Task<IActionResult> GetUnpostedByCompanyExternalId(Guid companyExternalId, string subSystemType = "JE")
        {
            try
            {
                var result = await GlTransactionService.GetUnpostedGlCount(companyExternalId, subSystemType);

                return Ok(result);

            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
