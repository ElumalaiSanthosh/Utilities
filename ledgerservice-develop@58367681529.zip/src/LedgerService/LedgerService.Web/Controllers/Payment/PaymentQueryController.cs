using System;
using System.Linq;
using System.Collections.Generic;
using LedgerService.Web.Services;
using LedgerService.Models.Dtos;
using ApiService.Commons.DataStore;
using ApiService.Extensions;
using ApiService.Commons.Extensions;
using ApiService.Commons.CacheService;
using System.Threading.Tasks;
using ApiService.Controllers;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Mvc;

namespace LedgerService.Web.Controllers
{    
    public partial class PaymentsController : DefaultApiController<PaymentsController>
    {
        /// <summary>
        /// Creates a PaymentRecord by pulling them from the accounting package.
        /// </summary>
        /// <param name="license"></param>
        /// <param name="transferCode"></param>
        /// <param name="top"></param>
        /// <param name="skip"></param>
        /// <returns></returns>
        /// <response code="201">Created - The request has been fulfilled and resulted in a new resource being created</response>
        /// <response code="202">Accepted - The request has been accepted for processing, but the processing has not been completed</response>
        /// <response code="205">Reset Content - The server has fulfilled the request and the user agent SHOULD reset the document view which caused the request to be sent</response>
        /// <response code="400">Bad Request - The request could not be understood by the server due to malformed syntax</response>
        /// <response code="401">Unauthorized - The request requires user authentication</response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpGet("license/{license}/sync/transfercode/{transferCode}")]
        [ProducesResponseType(200)]
        public async Task<IActionResult> GetSyncAsync(string license, string transferCode, int top, int skip)
        {
            try
            {
                var result = await PaymentService.SyncByLicenseAsync(license, transferCode, top, skip);

                return Ok(result);
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
