﻿using ApiService.Commons.DataStore;
using ApiService.Commons.Extensions;
using ApiService.Extensions;
using LedgerService.Models.Dtos;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class BatchesController
    {

        /// <summary>
        /// Returns a list of Batches
        /// </summary>
        /// <response code="200">Record found and returned</response>
        /// <response code="204">Record Not found</response>
        /// <response code="400">Bad Request - The request is malformed or invalid</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="404">Record not found for id</response>
        /// <response code="410">The requested resource is no longer available at the server and no forwarding address is known </response>
        /// <response code="414">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpGet("usercompany/{user_uuid}/{company_uuid}")]
        public async Task<IActionResult> GetManyByUserAndCompanyIdAsync(ODataQueryOptions<Batch> options,  Guid user_uuid, Guid company_uuid, bool defaultBatch = false, string name = null)
        {
            try
            {
                QueryOptions queryOptions = options.ParseOdata();
                queryOptions.Filter = $"company_uuid eq '{company_uuid}'";
                if (defaultBatch)
                {
                    queryOptions.Filter += $" and user_uuid eq '{user_uuid}' and is_default eq true";
                }
                else
                {
                    queryOptions.Filter += $" and (user_uuid eq '{user_uuid}' or shared_batch eq true)";
                    if (!string.IsNullOrEmpty(name))
                    {
                        string filter= $" and name ilike '%{name.ToDbCompatibleString()}%'";

                        if (Utilities.EscapeSpecialCharecters(ref name, out string escapeString))
                        {
                            filter = $" and name ilike '%{name.ToDbCompatibleString()}%' {escapeString}";
                        }

                        queryOptions.Filter += filter;
                    }
                }
                var result = (await BatchService.GetManyAsync(queryOptions)).WrapResults(queryOptions, BaseRequestUrl(Request));

                if (result != null) return Ok(result);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
