﻿using LedgerService.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class GlTransactionsController
    {
        /// <summary>
        /// Updates a GlTransactions record using the provided glTransaction object.
        /// </summary>
        /// <param name="glTransactionIds"></param>
        /// <param name="dto"></param>
        /// <returns></returns>
        /// <response code="200">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>
        /// <response code="204">No Content - The server has fulfilled the request but does not need to return an entity-body</response>
        /// <response code="400">Bad Request - The request could not be understood by the server due to malformed syntax</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpPatch("{glTransactionIds}")]
        public async Task<IActionResult> PatchAsync(string glTransactionIds, [FromBody, Required]GlTransaction dto)
        {
            try
            {
                long[] ids = glTransactionIds.Split(',').Select(long.Parse).ToArray();
                return Ok(await GlTransactionService.PatchAsync(ids, dto));
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }

        /// <summary>
        /// Delete multiple GlTransaction records using the Gl transaction ids. User need pass comma separated Ids
        /// </summary>
        /// <param name="glTransactionIds"></param>
        /// <returns></returns>
        /// <response code="200">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>
        /// <response code="204">No Content - The server has fulfilled the request but does not need to return an entity-body</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpDelete]
        public async Task<IActionResult> DeleteManyAsync([Required]string glTransactionIds)
        {
            try
            {
                var result = await GlTransactionService.DeleteManyAsync(glTransactionIds);
                return Ok(result);
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }

        /// <summary>
        /// Updates a GlTransactions records using the provided glTransaction list.
        /// </summary>
        /// <param name="glTransactions"></param>
        /// <returns></returns>
        /// <response code="200">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>
        /// <response code="204">No Content - The server has fulfilled the request but does not need to return an entity-body</response>
        /// <response code="400">Bad Request - The request could not be understood by the server due to malformed syntax</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpPut]
        public async Task<IActionResult> PutManyAsync([FromBody, Required]IEnumerable<GlTransaction> glTransactions)
        {
            try
            {
                return Ok(await GlTransactionService.PutAsync(glTransactions, null, true));
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }

        /// <summary>
        /// Creates GlTransactions records using the provided glTransaction list.
        /// </summary>
        /// <param name="glTransactions"></param>
        /// <returns></returns>
        /// <response code="200">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>
        /// <response code="204">No Content - The server has fulfilled the request but does not need to return an entity-body</response>
        /// <response code="400">Bad Request - The request could not be understood by the server due to malformed syntax</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpPost("postmany")]
        public async Task<IActionResult> PostManyAsync([FromBody, Required]IEnumerable<GlTransaction> glTransactions)
        {
            try
            {
                return Ok(await GlTransactionService.PostAsync(glTransactions, null, true));
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
