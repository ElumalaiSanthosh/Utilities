﻿using LedgerService.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
namespace LedgerService.Web.Controllers
{
    public partial class BankReconciliationClearingsController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clearings"></param>
        /// <returns></returns>
        [HttpPost("postmany")]
        public async Task<IActionResult> PostManyAsync([FromBody, Required]IEnumerable<BankReconciliationClearing> clearings)
        {
            try
            {
                return Ok(await BankReconciliationClearingService.PostAsync(clearings, null, true));
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
