﻿using LedgerService.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{

    public partial class GlAccountsController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sameValueForAllRecords"></param>
        /// <param name="glAccounts"></param>
        /// <returns></returns>
        [HttpPatch("patchmany")]
        [ProducesResponseType(200, Type = typeof(List<GlAccount>))]
        public async Task<IActionResult> PatchManyAsync(bool sameValueForAllRecords, [FromBody, Required] List<GlAccount> glAccounts)
        {
            try
            {
                var result = await GlAccountService.PatchManyAsync(glAccounts, sameValueForAllRecords);
                if (result != null)
                    return Ok(result);
                else
                    return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}