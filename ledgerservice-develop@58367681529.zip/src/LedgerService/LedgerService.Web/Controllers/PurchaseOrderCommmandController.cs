using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace LedgerService.Web.Controllers
{
    public partial class PurchaseOrdersController
    {
        /// <summary>
        /// Delete multiple Purchase order records using the PO ids. User need pass comma separated Ids
        /// </summary>
        /// <param name="glTransactionIds"></param>
        /// <returns></returns>
        /// <response code="200">OK - The request has succeeded and an entity corresponding to the requested resource is sent in the response</response>
        /// <response code="204">No Content - The server has fulfilled the request but does not need to return an entity-body</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpDelete]
        public async Task<IActionResult> DeleteManyAsync([Required]string glTransactionIds)
        {
            try
            {
                var result = await PurchaseOrderService.DeleteManyAsync(glTransactionIds);
                return Ok(result);
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
