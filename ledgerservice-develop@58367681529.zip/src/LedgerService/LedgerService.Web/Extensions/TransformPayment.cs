﻿using InterfaceTemplates.Models.Dtos;
using LedgerService.Models.Dtos;
using System;

namespace LedgerService.Web.Extensions
{
    internal static class TransformPayment
    {
        public static Payment Transform(this InterfaceCheck record)
        {
            return new Payment()
            {
                PaymentType = record.CheckTypeDescription,
                PaymentNumber = record.CheckNumber == null ? null : record.CheckNumber.ToString(),
                PaymentDate = record.CheckDate ?? DateTime.Now,
                //CheckMemo = , 
                //PaymentRef =,
                Amount = record.NativeCheckAmount ?? 0,
                CreatedTs = record.CreatedTs,
                LedgerUserCreatedUuid = record.CreatedByUser,
                LedgerUserLastModifiedUuid = record.LastModifiedUser,
                PostedTs = record.PostedTimestamp,
                PayeeName = record.PayeeName,
                BankUuid = record.BankUuid ?? Guid.Empty,
                VendorUuid = record.VendorUuid ?? Guid.Empty,
            };
        }
    }
}
