﻿using System.Threading.Tasks;

namespace LedgerService.Web.Services.AccountingInterface
{
    /// <summary>
    /// 
    /// </summary>
    public interface IAccountingInterfaceService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="license"></param>
        /// <param name="transferCode"></param>
        /// <param name="top"></param>
        /// <param name="skip"></param>
        /// <returns></returns>
        Task<bool> GetPayments(string license, string transferCode, int top = 0, int skip = 0);
    }
}
