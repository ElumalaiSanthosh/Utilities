﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using AccountingInterfaces.Clients;
using AccountingInterfaces.Enums;
using ApiService.Commons.Logger;
using ApiService.Commons.Rest;
using ApiService.Commons.CacheService;
using InterfaceTemplates.Models.Dtos;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using LedgerService.Web.Extensions;

namespace LedgerService.Web.Services.AccountingInterface
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountingInterfaceService : IAccountingInterfaceService
    {
        private AccountingInterfacesClient Client { get; }

        private ILogger Log { get; }

        private IApiCache Cache { get; }

        private IPaymentService PaymentService;


        /// <summary>
        /// 
        /// </summary>
        public AccountingInterfaceService(IConfiguration config, IPaymentService paymentService, IApiCache cache)
        {
            Log = ApiLogging.CreateLogger<AccountingInterfaceService>();
            Client = new AccountingInterfacesClient(config, cache);
            PaymentService = paymentService;
            Cache = cache;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="license"></param>
        /// <param name="transferCode"></param>
        /// <param name="top"></param>
        /// <param name="skip"></param>
        /// <returns></returns>
        public async Task<bool> GetPayments(string license, string transferCode, int top, int skip)
        {
            if (string.IsNullOrEmpty(license))
            {
                throw new ArgumentException("Cannot Get Payments for a Blank License Number");
            }

            if (string.IsNullOrEmpty(transferCode))
            {
                throw new ArgumentException("Cannot Get Payments for a Blank Transfer Code");
            }

            try
            {
                Log.LogInformation($"License ({license}) - top ({top}) skip({skip})");

                var startTime = DateTime.Now;
                var payments = Client.GetChecksByTransferCodeAsync(license, transferCode, top, skip).Result;
                Log.LogInformation($"AccountingInterfaceService.GetPayments: Getting ({top}) Payments took {DateTime.Now - startTime}");

                if (payments?.StatusCode == HttpStatusCode.OK)
                {
                    startTime = DateTime.Now;
                    await Add(license, payments.Value.Items);
                    Log.LogInformation($"AccountingInterfaceService.GetPayments: Adding ({top}) Payments took {DateTime.Now - startTime}");
                    return true;
                }

                if (payments?.StatusCode == HttpStatusCode.NoContent)
                {                   
                    return true;
                }

                throw new ApiRestException(payments.StatusCode, $"Could not get Payments records for License({license}) transfer code ({transferCode}){Environment.NewLine} URL-{payments.Url}{Environment.NewLine} Message-{payments.Message}");
            }
            catch (Exception e)
            {
                if (!e.Message.Contains("The given header was not found.")) throw;

                throw new ApiRestException(HttpStatusCode.Forbidden);
            }
        }
        
        private async Task Add(string license, IEnumerable<InterfaceCheck> payments)
        {
            List<InterfaceTransferStatusDetail> goodPayments = new List<InterfaceTransferStatusDetail>();
            List<InterfaceTransferStatusDetail> badPayments = new List<InterfaceTransferStatusDetail>();
            
            foreach (var payment in payments)
            {
                try
                {
                    var check = await PaymentService.PostAsync(payment.Transform());
                    goodPayments.Add(new InterfaceTransferStatusDetail { TransferStatusId = (int) TransferStatusEnum.SentToCorp, InternalXferId = payment.InternalXferId, ExternalXferId = check.ExternalId.ToString() });
                }
                catch (Exception e)
                {
                    string message = $"License ({license}) - Could not add payment ({payment.CheckNumber}) - ({e.Message})";
                    Log.LogTrace(message);
                    badPayments.Add(new InterfaceTransferStatusDetail { TransferStatusId = (int)TransferStatusEnum.FailedCorpPost, InternalXferId = payment.InternalXferId, StatusMessage = message.Length < 254 ? message : message.Substring(0, 254) });
                }                
            }

            goodPayments.AddRange(badPayments);

            var update = await Client.PutCheckStatusAsync(license, goodPayments);

            if(update.StatusCode != HttpStatusCode.OK)
            {
                string message = $"License ({license}) - Send Update Failed {update.StatusCode}-{update.Message}";
                Log.LogTrace(message);
            }
        }
    }
}
