using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;
using ApiService.Commons.Extensions;
using LedgerService.Web.Services.AccountingInterface;
using ApiService.Commons.DataStore;
using System.Linq;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PaymentService
    {
        private IAccountingInterfaceService _accountingInterfaceService;
        private IAccountingInterfaceService AccountingInterfaceService => _accountingInterfaceService ?? (_accountingInterfaceService = (IAccountingInterfaceService)ServiceProvider.GetService(typeof(IAccountingInterfaceService)));

        private ILedgerVendorService _ledgerVendorService;
        private ILedgerVendorService LedgerVendorService => _ledgerVendorService ?? (_ledgerVendorService = (ILedgerVendorService)ServiceProvider.GetService(typeof(ILedgerVendorService)));

        private ILedgerUserService _ledgerUserService;
        private ILedgerUserService LedgerUserService => _ledgerUserService ?? (_ledgerUserService = (ILedgerUserService)ServiceProvider.GetService(typeof(ILedgerUserService)));

        private ILedgerBankService _ledgerBankService;
        private ILedgerBankService LedgerBankService => _ledgerBankService ?? (_ledgerBankService = (ILedgerBankService)ServiceProvider.GetService(typeof(ILedgerBankService)));

        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bankUuid"></param>
        /// <param name="paymentType"></param>
        /// <param name="paymentNumber"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<long> GetIdByBankTypeCheckNumberAsync(Guid bankUuid, string paymentType, string paymentNumber, IDbTransaction transaction = null)
        {
            if (bankUuid.IsNullOrEmpty())
            {
                throw new ArgumentException("Invalid Parameter (bankUuid).");
            }

            if (string.IsNullOrEmpty(paymentType))
            {
                throw new ArgumentException("Invalid Parameter (paymentType).");
            }

            if (string.IsNullOrEmpty(paymentNumber))
            {
                throw new ArgumentException("Invalid Parameter (paymentNumber).");
            }

            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();

            try
            {
                var ledgerBankId = await LedgerBankService.GetIdByBankUuid(bankUuid, trans);

                if (ledgerBankId < 1)
                {
                    throw new ArgumentException($"Could Not find Bank Account ({bankUuid}).");
                }

                var payment = await GetByLedgerBankIdPaymentTypePaymentNumberAsync(ledgerBankId, paymentType, paymentNumber, trans);

                if (payment == null || payment.PaymentId < 1)
                {
                    throw new ArgumentException($"Could Not find Payment Type({paymentType}) - PaymentNumber({paymentNumber}).");
                }

                CommitTransaction(handleTransaction, trans);
                return payment.PaymentId;
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="license"></param>
        /// <param name="transferCode"></param>
        /// <param name="top"></param>
        /// <param name="skip"></param>
        /// <returns></returns>
        public async Task<bool> SyncByLicenseAsync(string license, string transferCode, int top, int skip)
        {
            if (string.IsNullOrEmpty(license))
            {
                throw new ArgumentException("You must provide a license");
            }

            if (string.IsNullOrEmpty(transferCode))
            {
                throw new ArgumentException("You must provide a transferCode");
            }

            return await AccountingInterfaceService.GetPayments(license, transferCode, top, skip);
        }

        partial void AfterGetMany(ref bool result, ref QueryResults<Payment> values, ref IDbTransaction transaction)
        {
            if (values?.Items?.Count > 0 && values.Items.Any(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0))
            {
                QueryOptions options = new QueryOptions { Filter = $"ledger_bank_id in({string.Join(',', values.Items.Where(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0).Select(x => x.LedgerBankId).Distinct())})" };
                var ledgerBanks = LedgerBankService.GetManyAsync(options, transaction).Result;
                if (ledgerBanks?.Items?.Count > 0)
                {
                    foreach (var item in values.Items.Where(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0))
                    {
                        var ledgerBank = ledgerBanks.Items.FirstOrDefault(x => x.LedgerBankId == item.LedgerBankId);
                        if (ledgerBank != null)
                            item.BankUuid = ledgerBank.BankUuid;
                    }
                }
            }
        }
        #endregion QueryService
    }
}
