/*
Created by ProjectBuilder Version: 3.1.0.14
On: 8/30/2020 11:21:02 PM
*/

using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Web.Services;
using ApiService.DataStore;
using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using ApiService.Services;
using System.Reflection;
using System.Linq;
using ApiService.Commons.Helpers;
using ApiService.Commons.Extensions;
using ApiService.Commons.Exceptions;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface IPaymentService : IService<Payment>
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bankUuid"></param>
        /// <param name="paymentType"></param>
        /// <param name="paymentNumber"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<long> GetIdByBankTypeCheckNumberAsync(Guid bankUuid, string paymentType, string paymentNumber, IDbTransaction transaction = null);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="license"></param>
        /// <param name="transferCode"></param>
        /// <param name="top"></param>
        /// <param name="skip"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<bool> SyncByLicenseAsync(string license, string transferCode, int top, int skip);

        #endregion QueryService
    }
}
