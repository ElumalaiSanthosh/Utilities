﻿using ApiService.Commons.Extensions;
using LedgerService.Models.Dtos;
using System;
using System.Data;

namespace LedgerService.Web.Services
{
    public partial class PaymentService
    {            
        partial void BeforePost(ref bool result, ref Payment dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            UpdateIds(dto, transaction);

            if (dto.CreatedTs == null)
            {
                dto.CreatedTs = DateTime.UtcNow;
            }
        }

        private void UpdateIds(Payment dto, IDbTransaction transaction)
        {
            UpdateLedgerUserCreatedId(dto, transaction);
            UpdateLedgerUserLastModifiedId(dto, transaction);
            UpdateVendorId(dto, transaction);
            UpdateLedgerBankId(dto, transaction);
        }

        private void UpdateLedgerUserCreatedId(Payment dto, IDbTransaction transaction)
        {
            if ((dto.LedgerUserCreatedId == 0 || dto.LedgerUserCreatedId == null) && !dto.LedgerUserCreatedUuid.IsNullOrEmpty())
            {
                dto.LedgerUserCreatedId = LedgerUserService.GetIdByUserUuid(dto.LedgerUserCreatedUuid ?? Guid.Empty, transaction).Result;
            }
        }

        private void UpdateLedgerUserLastModifiedId(Payment dto, IDbTransaction transaction)
        {
            if ((dto.LedgerUserLastModifiedId == 0 || dto.LedgerUserLastModifiedId == null) && !dto.LedgerUserLastModifiedUuid.IsNullOrEmpty())
            {                
                dto.LedgerUserLastModifiedId = LedgerUserService.GetIdByUserUuid(dto.LedgerUserLastModifiedUuid ?? Guid.Empty, transaction).Result;
            }
        }

        private void UpdateVendorId(Payment dto, IDbTransaction transaction)
        {
            if ((dto.LedgerVendorId == 0 || dto.LedgerVendorId == null) && !dto.VendorUuid.IsNullOrEmpty())
            {
                dto.LedgerVendorId = LedgerVendorService.GetIdByVendorUuid((Guid)dto.VendorUuid, transaction).Result;
            }
        }

        private void UpdateLedgerBankId(Payment dto, IDbTransaction transaction)
        {
            if ((dto.LedgerBankId == 0 || dto.LedgerBankId == null) && !dto.BankUuid.IsNullOrEmpty())
            {
                dto.LedgerBankId = LedgerBankService.GetIdByBankUuid((Guid)dto.BankUuid, transaction).Result;
            }
        }

        partial void BeforePut(ref bool result, ref Payment dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            //retain CreatedTs,CreatedByUser
            var existingDto = GetAsync(dto.PaymentId, transaction).Result;
            
            if (existingDto != null)
            {
                dto.CreatedTs = existingDto.CreatedTs;
                dto.LedgerUserCreatedId = existingDto.LedgerUserCreatedId;
            }
            
            UpdateIds(dto, transaction);
        }
    }
}
