/*
Created by ProjectBuilder Version: 2.1.0.109
On: 8/21/2020 10:40:51 AM
*/

using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;
using ApiService.Services;
using ApiService.Commons.Rest;
using System.Net;
using Microsoft.Extensions.Logging;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerUserService : Service<LedgerUser>, ILedgerUserService
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<long> GetIdByUserUuid(Guid userUuid, IDbTransaction transaction = null)
        {
            if (userUuid == null || userUuid == Guid.Empty)
            {
                throw new ArgumentException("Invalid Parameter (userUuid).");
            }

            long userId = 0;

            string cacheKey = $"{Startup.BaseCacheKey}.ledgerusers.userUuid-{ userUuid }";

            string cacheValue = Cache.GetString(cacheKey);

            if (cacheValue != null)
            {
                //Log.LogTrace($"LedgerUserService.GetIdByUserUuid: Got Id from Cache {userUuid}");
                long.TryParse(cacheValue, out userId);
            }

            if (userId > 0)
            {
                return userId;
            }

            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();

            try
            {
                var user = await GetByUserUuidAsync(userUuid, trans);

                bool addUser = false;

                if (user == null || user.LedgerUserId < 1)
                {
                    user = await PostAsync(new LedgerUser { UserUuid = userUuid }, trans);

                    if (user == null || user.LedgerUserId < 1)
                    {
                        throw new ApiRestException(HttpStatusCode.BadRequest, $"Could not find Ledger User with UUID ({userUuid})");
                    }

                    addUser = true;
                }

                if (!addUser)
                {
                    Cache.SetString(cacheKey, user.LedgerUserId.ToString());
                }

                CommitTransaction(handleTransaction, trans);
                return user.LedgerUserId;
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
        }
        #endregion QueryService
    }
}
