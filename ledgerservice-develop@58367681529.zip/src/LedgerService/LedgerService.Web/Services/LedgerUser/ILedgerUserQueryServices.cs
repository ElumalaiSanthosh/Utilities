/*
Created by ProjectBuilder Version: 2.1.0.109
On: 8/21/2020 10:40:51 AM
*/

using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;
using ApiService.Services;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface ILedgerUserService : IService<LedgerUser>
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<long> GetIdByUserUuid(Guid userUuid, IDbTransaction transaction = null);
        #endregion QueryService
    }
}
