using System.Data;
using LedgerService.Models.Dtos;
using ApiService.Services;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerUserService : Service<LedgerUser>, ILedgerUserService
    {
        #region CommandService
        partial void AfterPost(ref bool result, ref LedgerUser dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            string cacheKey = $"{Startup.BaseCacheKey}.ledgerusers.userUuid-{ dto.UserUuid }";
            Cache.SetString(cacheKey, dto.LedgerUserId.ToString());
        }

        #endregion CommandService
    }
}
