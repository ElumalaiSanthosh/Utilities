using ApiService.Commons.DataStore;
using ApiService.Commons.Events;
using ApiService.Commons.Utility;
using LedgerService.Models.Dtos;
using Newtonsoft.Json;
using System.Data;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class BankReconciliationService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="createRelatedRecords"></param>
        partial void AfterPost(ref bool result, ref BankReconciliation dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(dto);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Create, dto.GetType().Name);

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="createRelatedRecords"></param>
        partial void AfterPut(ref bool result, ref BankReconciliation dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(dto);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Update, dto.GetType().Name);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        partial void AfterDelete(ref bool result, ref QueryOptions options, ref IDbTransaction transaction)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(options);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Delete, "BankReconciliation");
            }
        }

    }
}
