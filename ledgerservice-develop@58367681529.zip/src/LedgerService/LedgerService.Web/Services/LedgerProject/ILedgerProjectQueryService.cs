﻿using LedgerService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial interface ILedgerProjectService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="project_uuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<LedgerProject> GetLedgerProjectByProjectUuid(Guid project_uuid, IDbTransaction transaction = null);
    }
}
