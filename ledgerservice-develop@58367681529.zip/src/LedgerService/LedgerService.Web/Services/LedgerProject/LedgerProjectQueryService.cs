﻿using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial class LedgerProjectService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="project_uuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public Task<LedgerProject> GetLedgerProjectByProjectUuid(Guid project_uuid, IDbTransaction transaction = null)
        {
            var options = new QueryOptions
            {
                Filter = $"project_uuid eq '{project_uuid}'"
            };
            return ReadAsync(options, transaction);
        }
    }
}
