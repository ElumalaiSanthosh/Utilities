using System.Data;
using LedgerService.Models.Dtos;
using ApiService.Services;
using ApiService.Commons.Extensions;
using System;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class PositivePayPaymentService : Service<PositivePayPayment>, IPositivePayPaymentService
    {
        private IPaymentService _paymentService;
        private IPaymentService PaymentService => _paymentService ?? (_paymentService = (IPaymentService)ServiceProvider.GetService(typeof(IPaymentService)));

        #region CommandService
        partial void BeforePost(ref bool result, ref PositivePayPayment dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if(dto.PaymentId < 1 && !dto.BankUuid.IsNullOrEmpty() && !string.IsNullOrEmpty(dto.PaymentType) && !string.IsNullOrEmpty(dto.PaymentNumber))
            {
                dto.PaymentId = PaymentService.GetIdByBankTypeCheckNumberAsync((Guid) dto.BankUuid, dto.PaymentType, dto.PaymentNumber, transaction).Result;
            }
        }
        #endregion CommandService
    }
}
