using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerCompanyService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<LedgerCompany> GetLedgerCompanyByCompanyUuidAsync(Guid companyUuid, IDbTransaction transaction = null)
        {
            var result = await ReadAsync(new QueryOptions
            {
                Filter = $"company_uuid eq '{ companyUuid.ToString() }'"
            }, transaction);

            return result;
        }

        /// <summary>
        /// Gets data by search query
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="searchKey"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<LedgerCompany> GetLedgerCompanyBySearchKey(Guid companyExternalId, string searchKey, IDbTransaction transaction)
        {
            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();

            try
            {
                if (!string.IsNullOrWhiteSpace(companyExternalId.ToString()))
                {
                    var ledgerCompanies = await GetManyAsync(new QueryOptions { Filter = "company_uuid eq '" + companyExternalId + "'" }, trans);
                    
                    if (ledgerCompanies?.Items?.Count > 0)
                    {
                        var ledgerCompany = ledgerCompanies.Items.FirstOrDefault();

                        string filter = $" and tax_credit ilike '%{searchKey.ToDbCompatibleString()}%'";

                        if (Utilities.EscapeSpecialCharecters(ref searchKey, out string escapeString))
                        {
                            filter = $" and tax_credit ilike '%{searchKey.ToDbCompatibleString()}%' {escapeString}";
                        }

                        var caTaxCredits = await CaTaxCreditService.GetManyAsync(new QueryOptions
                        {
                            Filter = $"ledger_company_id eq {ledgerCompany.LedgerCompanyId}" + filter,
                            Orderby = Utilities.GetAutofillOrderbyQuery(searchKey, "tax_credit")
                        }, trans);

                        CommitTransaction(handleTransaction, trans);
                        
                        if (caTaxCredits?.Items?.Count > 0)
                        {
                            ledgerCompany.CaTaxCredits = new List<CaTaxCredit>();
                            ledgerCompany.CaTaxCredits.AddRange(caTaxCredits.Items);
                            return ledgerCompany;
                        }
                        else                        
                            return null;
                    }
                }

                CommitTransaction(handleTransaction, trans);
                return null;
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
        }
    }
}
