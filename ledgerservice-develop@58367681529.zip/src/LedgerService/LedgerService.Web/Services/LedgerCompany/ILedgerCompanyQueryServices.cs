using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial interface ILedgerCompanyService
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>

        Task<LedgerCompany> GetLedgerCompanyByCompanyUuidAsync(Guid companyUuid, IDbTransaction transaction = null);
        /// <summary>
        /// Gets data by searchquery
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="searchKey"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<LedgerCompany> GetLedgerCompanyBySearchKey(Guid companyExternalId, string searchKey, IDbTransaction transaction = null);
        #endregion QueryService
    }
}
