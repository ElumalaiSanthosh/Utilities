using System.Data;
using LedgerService.Models.Dtos;
using ApiService.Commons.Extensions;
using System;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class PositivePayService
    {
        private ILedgerBankService _ledgerBankService;
        private ILedgerBankService LedgerBankService => _ledgerBankService ?? (_ledgerBankService = (ILedgerBankService)ServiceProvider.GetService(typeof(ILedgerBankService)));

        #region CommandService
        partial void BeforePost(ref bool result, ref PositivePay dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if(dto.LedgerBankId < 1 && !dto.BankUuid.IsNullOrEmpty())
            {
                dto.LedgerBankId = LedgerBankService.GetIdByBankUuid((Guid) dto.BankUuid, transaction).Result;
            }
        }
        #endregion CommandService
    }
}
