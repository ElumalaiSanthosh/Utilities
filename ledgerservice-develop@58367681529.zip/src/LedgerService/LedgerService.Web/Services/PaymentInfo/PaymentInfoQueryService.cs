﻿using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System.Data;
using System.Linq;

namespace LedgerService.Web.Services
{
    public partial class PaymentInfoService
    {

        private IPaymentService PaymentService => (IPaymentService)ServiceProvider.GetService(typeof(IPaymentService));
        private ILedgerBankService LedgerBankService => (ILedgerBankService)ServiceProvider.GetService(typeof(ILedgerBankService));
        private IGlTransactionPaymentService GlTransactionPaymentService => (IGlTransactionPaymentService)ServiceProvider.GetService(typeof(IGlTransactionPaymentService));

        partial void AfterGetMany(ref bool result, ref QueryResults<PaymentInfo> values, ref IDbTransaction transaction)
        {
            if (values?.Items?.Count > 0)
            {
                QueryOptions options = new QueryOptions { Filter = $"payment_info_id in({string.Join(',', values.Items.Select(x => x.PaymentInfoId))})" };
                var glTransactionPayments = GlTransactionPaymentService.GetManyAsync(options, transaction).Result?.Items;
                if (glTransactionPayments?.Count > 0)
                {
                    foreach (var paymentInfo in values.Items)
                    {
                        paymentInfo.GlTransactionPayment = glTransactionPayments.Where(x => x.PaymentInfoId == paymentInfo.PaymentInfoId)?.ToList();
                        var paymentids = glTransactionPayments.Where(x => x.PaymentInfoId == paymentInfo.PaymentInfoId)?.Select(x => x.PaymentId);
                        if (paymentids != null && paymentids.Count() > 0)
                        {
                            var payments = PaymentService.GetManyAsync(new QueryOptions
                            {
                                Filter = $"payment_id in ({string.Join(",", paymentids)})"
                            }, transaction).Result?.Items;
                            if (payments?.Count > 0)
                            {
                                paymentInfo.Payments = payments;
                            }
                        }
                    }
                }
            }
            if (values?.Items?.Count > 0 && (values.Items.Any(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0) || values.Items.Any(x => x.SendingBankId.HasValue && x.SendingBankId > 0)))
            {
                var bankIds = values.Items.Where(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0).Select(x => x.LedgerBankId).Distinct().ToList();
                bankIds.AddRange(values.Items.Where(x => x.SendingBankId.HasValue && x.SendingBankId > 0).Select(x => x.SendingBankId).Distinct().ToList());
                var options = new QueryOptions { Filter = $"ledger_bank_id in({string.Join(',', bankIds)})" };
                var ledgerBanks = LedgerBankService.GetManyAsync(options, transaction).Result;
                if (ledgerBanks?.Items?.Count > 0)
                {
                    foreach (var item in values.Items.Where(x => x.LedgerBankId.HasValue && x.LedgerBankId > 0))
                    {
                        var ledgerBank = ledgerBanks.Items.FirstOrDefault(x => x.LedgerBankId == item.LedgerBankId);
                        if (ledgerBank != null)
                            item.LedgerBankUuid = ledgerBank.BankUuid;

                        var sendingBank = ledgerBanks.Items.FirstOrDefault(x => x.LedgerBankId == item.SendingBankId);
                        if (sendingBank != null)
                            item.SendingBankUuid = sendingBank.BankUuid;
                    }
                }
            }
        }
    }
}
