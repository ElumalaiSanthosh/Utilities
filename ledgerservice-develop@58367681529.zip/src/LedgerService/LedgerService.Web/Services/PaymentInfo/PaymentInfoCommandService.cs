﻿using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial class PaymentInfoService
    {
        private List<Payment> payments = null;
        partial void BeforePost(ref bool result, ref PaymentInfo dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if (dto.Payments != null && dto.Payments.Any())
            {
                payments = dto.Payments = PaymentService.PostAsync(dto.Payments, transaction).Result?.ToList();
            }
            UpdateBankDetails(dto, transaction);
        }
        partial void AfterPost(ref bool result, ref PaymentInfo dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            dto.Payments = payments;
            if (dto.Payments?.Count > 0)
            {
                long paymentInfoId = dto.PaymentInfoId;
                var glTransactionPayments = dto.Payments.Select(x => new GlTransactionPayment { PaymentId = x.PaymentId, PaymentInfoId = paymentInfoId });
                dto.GlTransactionPayment = GlTransactionPaymentService.PostAsync(glTransactionPayments, transaction).Result?.ToList();
            }
        }

        private void UpdateBankDetails(PaymentInfo dto, IDbTransaction transaction)
        {
            if (!dto.LedgerBankUuid.GetValueOrDefault().Equals(default(Guid)))
            {
                var ledgerBank = CheckAndGetLedgerBank(dto.LedgerBankUuid.Value, transaction).Result;
                dto.LedgerBankId = ledgerBank?.LedgerBankId;
            }

            if (!dto.SendingBankUuid.GetValueOrDefault().Equals(default(Guid)))
            {
                var ledgerBank = CheckAndGetLedgerBank(dto.SendingBankUuid.Value, transaction).Result;
                dto.SendingBankId = ledgerBank?.LedgerBankId;
            }
        }

        private async Task<LedgerBank> CheckAndGetLedgerBank(Guid bankUuid, IDbTransaction transaction)
        {
            var ledgerbank = await LedgerBankService.GetManyAsync(new QueryOptions { Filter = $"bank_uuid eq '{bankUuid.ToString()}'" });

            if (ledgerbank?.Items?.Count > 0)
                return ledgerbank.Items.First();
            else
                return await LedgerBankService.PostAsync(new LedgerBank { BankUuid = bankUuid }, transaction);
        }

        partial void BeforePut(ref bool result, ref PaymentInfo dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            if (dto.Payments != null && dto.Payments.Any())
                UpdatePaymentDto(dto, transaction).Wait();

            UpdateBankDetails(dto, transaction);
        }

        partial void AfterPut(ref bool result, ref PaymentInfo dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            long paymentInfoId = dto.PaymentInfoId;
            var glTransactionPayments = dto.Payments?.Select(x => new GlTransactionPayment { PaymentId = x.PaymentId, PaymentInfoId = paymentInfoId });
            if (glTransactionPayments != null && glTransactionPayments.Any())
                dto.GlTransactionPayment = GlTransactionPaymentService.PostAsync(glTransactionPayments, transaction).Result?.ToList();
        }

        private async Task UpdatePaymentDto(PaymentInfo dto, IDbTransaction transaction)
        {
            if (dto.Payments?.Count > 0)
            {
                if (await DeletPaymentData(new QueryOptions { Filter = $"payment_info_id eq {dto.PaymentInfoId}" }, transaction))
                {
                    dto.Payments = PaymentService.PostAsync(dto.Payments, transaction).Result?.ToList();
                }
            }
        }

        partial void AfterDelete(ref bool result, ref QueryOptions options, ref IDbTransaction transaction)
        {   
            result = DeletPaymentData(options, transaction).Result;
        }

        private async Task<bool> DeletPaymentData(QueryOptions options, IDbTransaction transaction)
        {
            var existingData = await ReadManyAsync(options);
            if (existingData?.Items?.Count > 0)
            {
                QueryOptions glTransactionPaymentOptions = new QueryOptions { Filter = $"payment_info_id in ({string.Join(',', existingData.Items.Select(x => x.PaymentInfoId))})" };
                var filteredglTransactionPayments = (await GlTransactionPaymentService.ReadManyAsync(glTransactionPaymentOptions, transaction)).Items;
                if (filteredglTransactionPayments.Count() > 0)
                {
                    QueryOptions paymentOptions = new QueryOptions { Filter = $"payment_id in ({string.Join(',', filteredglTransactionPayments.Select(x => x.PaymentId))})" };
                    return await GlTransactionPaymentService.DeleteAsync(glTransactionPaymentOptions, transaction)
                        && await PaymentService.DeleteAsync(paymentOptions, transaction);
                }
            }
            return true;
        }
    }
}
