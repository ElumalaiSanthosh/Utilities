using ApiService.Commons.DataStore;
using ApiService.Commons.Events;
using ApiService.Commons.Utility;
using ApiService.Repositories;
using LedgerService.Models.Dtos;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial class GlTransactionDetailService
    {
        private ILedgerVendorService LedgerVendorService => (ILedgerVendorService)ServiceProvider.GetService(typeof(ILedgerVendorService));
        

        

        partial void BeforePost(ref bool result, ref GlTransactionDetail dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            UpdateVendorDetails(dto, transaction);
        }

        partial void BeforePut(ref bool result, ref GlTransactionDetail dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            UpdateVendorDetails(dto, transaction);
        }

        private void UpdateVendorDetails(GlTransactionDetail dto, IDbTransaction transaction)
        {
            if (dto.VendorUuid != null && !dto.VendorUuid.GetValueOrDefault().Equals(default(Guid)))
            {
                var ledgerVendor = CheckAndGetLedgerVendor(dto.VendorUuid.Value, transaction).Result;
                dto.LedgerVendorId = ledgerVendor?.LedgerVendorId;
            }
        }

        private async Task<LedgerVendor> CheckAndGetLedgerVendor(Guid vendorUuid, IDbTransaction transaction)
        {
            var ledgerVendor = await LedgerVendorService.GetManyAsync(new QueryOptions { Filter = $"vendor_uuid eq '{vendorUuid.ToString()}'" });

            if (ledgerVendor?.Items?.Count > 0)
                return ledgerVendor.Items.First();
            else
                return await LedgerVendorService.PostAsync(new LedgerVendor { VendorUuid = vendorUuid }, transaction);
        }
    }
}
