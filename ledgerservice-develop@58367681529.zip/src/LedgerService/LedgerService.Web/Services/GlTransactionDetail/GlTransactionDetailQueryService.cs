using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System.Data;
using System.Linq;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class GlTransactionDetailService
    {
        partial void AfterGetMany(ref bool result, ref QueryResults<GlTransactionDetail> values, ref IDbTransaction transaction)
        {
            var data = values.Items.Where(x => x.LedgerVendorId.HasValue && x.LedgerVendorId > 0).ToList();
            if (data != null && data.Any())
            {
                var options = new QueryOptions { Filter = $"ledger_vendor_id in({string.Join(',', data.Select(x => x.LedgerVendorId).Distinct())})" };
                var ledgerVendors = LedgerVendorService.GetManyAsync(options, transaction).Result;
                if (ledgerVendors?.Items?.Count > 0)
                {
                    foreach (var item in data)
                    {
                        var ledgerVendor = ledgerVendors.Items.FirstOrDefault(x => x.LedgerVendorId == item.LedgerVendorId);
                        if (ledgerVendor != null)
                            item.VendorUuid = ledgerVendor.VendorUuid;
                    }
                }
            }
        }
    }
}
