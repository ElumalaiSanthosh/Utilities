﻿using ApiService.Commons.DataStore;
using ApiService.Commons.Events;
using ApiService.Commons.Rest;
using ApiService.Commons.Utility;
using LedgerService.Models.Dtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial class PurchaseOrderService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        partial void AfterDelete(ref bool result, ref QueryOptions options, ref IDbTransaction transaction)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(options);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Delete, "PurchaseOrder", "PO");
            }
        }

        /// <summary>
        /// Method to delete multiple records
        /// </summary>
        /// <param name="strPurchaseOrderIds"></param>
        /// <param name="transaction"></param>
        public async Task<bool> DeleteManyAsync(string strPurchaseOrderIds, IDbTransaction transaction = null)
        {
            var purchaseOrderIdList = strPurchaseOrderIds.Split(',').Where(i => long.TryParse(i, out long num)).ToList();
            var purchaseOrderIds = await GetIdListForDelete(new QueryOptions() { Filter = "purchase_order_id in (" + string.Join(",", purchaseOrderIdList) + ") " }, transaction);

            if (!purchaseOrderIds.Any())
                return false;

            var purchaseOrderDetails = await PurchaseOrderDetailService.GetDynamicObjectsAsync(new List<string>() { "purchase_order_account_id" }, new QueryOptions() { Filter = "purchase_order_id in (" + string.Join(",", purchaseOrderIds) + ")" }, transaction);

            var accountIds = new List<long>();
            accountIds.AddRange(purchaseOrderDetails.Items.Select(t => (long)t.purchase_order_account_id));

            bool handleTransaction = transaction == null;
            transaction = transaction ?? BeginTransaction();

            var deleteResult = true;

            if (accountIds?.Count > 0)
                deleteResult = await PurchaseOrderAccountService.DeleteAsync(new QueryOptions() { Filter = "purchase_order_account_id in (" + string.Join(",", accountIds) + ")" }, transaction);

            if (purchaseOrderIds?.Count() > 0)
                deleteResult = deleteResult && await DeleteAsync(new QueryOptions() { Filter = "purchase_order_id in (" + string.Join(",", purchaseOrderIds) + ")" }, transaction);

            if (deleteResult)
                CommitTransaction(handleTransaction, transaction);
            else
                RollbackTransaction(handleTransaction, transaction);

            return deleteResult;
        }

        partial void BeforePost(ref bool result, ref PurchaseOrder dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if (dto.CreatedTs == null)
                dto.CreatedTs = DateTime.UtcNow;

            CheckAndUpdateCompanyAndVendor(dto, transaction);
            CheckDuplicateJournal(dto, transaction);
            UpdateTaxCodeIdAsync(dto, transaction).Wait();
        }

        partial void AfterPost(ref bool result, ref PurchaseOrder dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            CheckAndUpdatePurchaseOrderAccounts(dto, transaction).Wait();

            string jsonStringify = JsonConvert.SerializeObject(dto);
            ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Create, dto.GetType().Name, "PO");
        }

        partial void BeforePut(ref bool result, ref PurchaseOrder dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            PurchaseOrder po = GetAsync(dto.PurchaseOrderId).Result;
            dto.ExternalId = po.ExternalId;
            dto.CreatedTs = po.CreatedTs;

            CheckDuplicateJournal(dto, transaction);
            CheckAndUpdateCompanyAndVendor(dto, transaction);
            UpdateTaxCodeIdAsync(dto, transaction).Wait();
        }

        partial void AfterPut(ref bool result, ref PurchaseOrder dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            if (updateRelatedRecords)
                result = UpdateAccountsAsync(dto, transaction).Result;

            string jsonStringify = JsonConvert.SerializeObject(dto);
            ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Update, dto.GetType().Name, "PO");
        }


        private async Task UpdateTaxCodeIdAsync(PurchaseOrder dto, IDbTransaction transaction)
        {
            if (dto.PurchaseOrderAccounts != null && dto.PurchaseOrderAccounts.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(dto.PurchaseOrderAccounts?.First().TaxFormName))
                {
                    var taxForm = await TaxFormService.ReadAsync(new QueryOptions { Filter = $"name eq '{dto.PurchaseOrderAccounts.First().TaxFormName}'" }, transaction);
                    if (taxForm == null)
                        throw new ApiRestException(HttpStatusCode.BadRequest, "Invalid Tax Code");

                    var taxCodeList = await POTaxCodeService.ReadManyAsync(new QueryOptions { Filter = $"tax_form_id eq '{ taxForm.TaxFormId}'" });

                    dto.PurchaseOrderAccounts.ForEach(item =>
                    {
                        if (!string.IsNullOrWhiteSpace(item.TaxCode))
                        {
                            var taxCodeDetails = taxCodeList?.Items?.FirstOrDefault(x => x.TaxCode.Equals(item.TaxCode));
                            if (taxCodeDetails == null)
                                throw new ApiRestException(HttpStatusCode.BadRequest, "Invalid Tax Code");

                            item.TaxCodeId = taxCodeDetails.TaxCodeId;
                        }
                    });
                }
            }
        }

        private void CheckDuplicateJournal(PurchaseOrder dto, IDbTransaction transaction)
        {
            var options = new QueryOptions
            {
                Filter = $"company_id eq {dto.CompanyId} and po_number eq '{dto.PONumber.ToDbCompatibleString()}'"
            };
            if (dto.PurchaseOrderId > 0)
                options.Filter += $" and purchase_order_id ne {dto.PurchaseOrderId}";

            var records = GetManyAsync(options, transaction).Result;
            if (records?.Items.Count > 0)
                throw new ApiRestException(System.Net.HttpStatusCode.Conflict, $"Purchase Order cannot be duplicate");
        }

        private void CheckAndUpdateCompanyAndVendor(PurchaseOrder dto, IDbTransaction transaction)
        {
            if (dto.CompanyId == 0 && (dto.CompanyUuid == null || dto.CompanyUuid == Guid.Empty))
                throw new ApiRestException(HttpStatusCode.NotAcceptable, "Invalid company_uuid");

            if (dto.CompanyId == 0)
            {
                var company = CheckAndGetCompanyAsync((Guid)dto.CompanyUuid, transaction).Result;
                if (company != null)
                    dto.CompanyId = company.CompanyId;
            }

            if ((dto.VendorId == null || dto.VendorId == 0) && dto.VendorUuid != null && dto.VendorUuid != Guid.Empty)
            {
                var vendor = CheckAndGetVendorAsync((Guid)dto.VendorUuid, transaction).Result;
                if (vendor != null)
                    dto.VendorId = vendor.VendorId;
            }
        }

        private async Task<Company> CheckAndGetCompanyAsync(Guid company_uuid, IDbTransaction transaction)
        {
            var company = await CompanyService.GetManyAsync(new QueryOptions { Filter = "company_uuid eq '" + company_uuid + "'" }, transaction);
            if (company == null || company?.Items?.Count == 0)
                return await CompanyService.PostAsync(new Company { CompanyUuid = company_uuid }, transaction);

            return company.Items.First();
        }

        private async Task<Vendor> CheckAndGetVendorAsync(Guid vendor_uuid, IDbTransaction transaction)
        {
            var vendor = await VendorService.GetManyAsync(new QueryOptions { Filter = "vendor_uuid eq '" + vendor_uuid + "'" }, transaction);
            if (vendor == null || vendor?.Items?.Count == 0)
                return await VendorService.PostAsync(new Vendor { VendorUuid = vendor_uuid }, transaction);

            return vendor.Items.First();
        }

        private async Task CheckAndUpdatePurchaseOrderAccounts(PurchaseOrder dto, IDbTransaction transaction)
        {
            if (dto.PurchaseOrderAccounts?.Count > 0)
            {
                await UpdatePurchaseOrderDetails(dto, transaction);
                PurchaseOrderAccount poAccount = null;
                List<PurchaseOrderDetail> purchaseOrderDetail = null;
                await dto.PurchaseOrderAccounts.ForEachAsync(async account =>
                {
                    poAccount = await PurchaseOrderAccountService.PostAsync(account, transaction, false);
                    if (poAccount != null)
                    {
                        account.PurchaseOrderDetails.ToList().ForEach(c => c.PurchaseOrderAccountId = poAccount.PurchaseOrderAccountId);
                        purchaseOrderDetail = (await PurchaseOrderDetailService.PostAsync(account.PurchaseOrderDetails, transaction)).ToList();
                        poAccount.PurchaseOrderDetails = purchaseOrderDetail;
                        account = poAccount;
                    }
                });
            }
        }

        private async Task UpdatePurchaseOrderDetails(PurchaseOrder dto, IDbTransaction transaction)
        {
            if (dto.PurchaseOrderAccounts?.Count > 0)
            {
                await dto.PurchaseOrderAccounts.ForEachAsync(async account =>
                {
                    account.CoaId = (await CheckAndGetCOAAsync(account.CoaUuid, transaction))?.CoaId;
                    account.ProjectId = (await CheckAndGetProjectAsync(account.ProjectUuid, transaction))?.ProjectId;

                    await account.PurchaseOrderDetails.ForEachAsync(async detail =>
                    {
                        detail.PurchaseOrderId = dto.PurchaseOrderId;
                        detail.TaxCreditId = (await CheckAndGetTaxCreditAsync(detail.TaxCredit, dto.CompanyId, transaction))?.TaxCreditId;
                    });
                });

            }
        }

        private async Task<Coa> CheckAndGetCOAAsync(Guid? coa_uuid, IDbTransaction transaction)
        {
            if (!string.IsNullOrWhiteSpace(coa_uuid.ToString()))
            {
                var coa = await CoaService.GetManyAsync(new QueryOptions { Filter = "coa_uuid eq '" + coa_uuid + "'" }, transaction);
                if (coa == null || coa?.Items?.Count < 1)
                    return await CoaService.PostAsync(new Coa { CoaUuid = (Guid)coa_uuid }, transaction);

                return coa.Items.FirstOrDefault();
            }
            return null;
        }

        private async Task<Project> CheckAndGetProjectAsync(Guid? project_uuid, IDbTransaction transaction)
        {
            if (!string.IsNullOrWhiteSpace(project_uuid.ToString()))
            {
                var project = await ProjectService.GetManyAsync(new QueryOptions { Filter = "project_uuid eq '" + project_uuid + "'" }, transaction);
                if (project == null || project?.Items?.Count < 1)
                    return await ProjectService.PostAsync(new Project { ProjectUuid = (Guid)project_uuid }, transaction);

                return project.Items.FirstOrDefault();
            }
            return null;
        }

        private async Task<POTaxCredit> CheckAndGetTaxCreditAsync(string taxCredit, long? companyId, IDbTransaction transaction)
        {
            if (!string.IsNullOrWhiteSpace(taxCredit) && companyId != null)
            {
                var poTaxCredit = await POTaxCreditService.GetManyAsync(new QueryOptions { Filter = "tax_credit eq '" + taxCredit + "' and company_id eq " + companyId.ToString() }, transaction);
                if (poTaxCredit == null || poTaxCredit?.Items?.Count < 1)
                    return await POTaxCreditService.PostAsync(new POTaxCredit { CompanyId = (long)companyId, TaxCredit = taxCredit }, transaction);

                return poTaxCredit.Items.FirstOrDefault();
            }
            return null;
        }

        private async Task<bool> UpdateAccountsAsync(PurchaseOrder dto, IDbTransaction transaction)
        {
            bool result = true;
            if (dto?.PurchaseOrderAccounts != null)
            {
                string filter = $"purchase_order_id eq {dto.PurchaseOrderId}";
                var purchaseOrderDetailIds = dto.PurchaseOrderAccounts?.Where(e => e.PurchaseOrderAccountId > 0 && e.PurchaseOrderDetails.FirstOrDefault() != null).Select(C => C.PurchaseOrderDetails.FirstOrDefault().PurchaseOrderDetailId).ToList();
                if (purchaseOrderDetailIds.Any())
                    filter += $" and purchase_order_detail_id NOT IN({string.Join(", ", purchaseOrderDetailIds)})";

                var purchaseOrderDetails = await PurchaseOrderDetailService.GetManyAsync(new QueryOptions { Filter = filter }, transaction);
                if (purchaseOrderDetails?.Items.Count > 0)
                {
                    string accountIds = string.Join(',', purchaseOrderDetails.Items.Select(d => d.PurchaseOrderDetailId));
                    result = await PurchaseOrderAccountService.DeleteAsync(new QueryOptions() { Filter = $"purchase_order_account_id in ({accountIds})" }, transaction);
                }

                if (result && dto.PurchaseOrderAccounts?.Count > 0)
                {
                    await UpdatePurchaseOrderDetails(dto, transaction);

                    //Update
                    if (dto.PurchaseOrderAccounts.Any(x => x.PurchaseOrderAccountId > 0))
                        await PurchaseOrderAccountService.PutAsync(dto.PurchaseOrderAccounts.Where(a => a.PurchaseOrderAccountId > 0), transaction);
                    //create
                    if (dto.PurchaseOrderAccounts.Any(x => x.PurchaseOrderAccountId == 0))
                        await PurchaseOrderAccountService.PostAsync(dto.PurchaseOrderAccounts.Where(a => a.PurchaseOrderAccountId == 0), transaction);
                }
            }
            return result;
        }

    }
}
