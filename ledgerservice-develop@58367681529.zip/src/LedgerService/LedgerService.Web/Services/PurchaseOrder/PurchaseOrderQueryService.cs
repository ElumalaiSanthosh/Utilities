using ApiService.Commons.DataStore;
using ApiService.Repositories;
using LedgerService.Models.Dtos;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial class PurchaseOrderService
    {

        private IPurchaseOrderAccountService PurchaseOrderAccountService => (IPurchaseOrderAccountService)ServiceProvider.GetService(typeof(IPurchaseOrderAccountService));
        private IPurchaseOrderDetailService PurchaseOrderDetailService => (IPurchaseOrderDetailService)ServiceProvider.GetService(typeof(IPurchaseOrderDetailService));
        private ICoaService CoaService => (ICoaService)ServiceProvider.GetService(typeof(ICoaService));
        private IPOTaxCreditService POTaxCreditService => (IPOTaxCreditService)ServiceProvider.GetService(typeof(IPOTaxCreditService));
        private IVendorService VendorService => (IVendorService)ServiceProvider.GetService(typeof(IVendorService));
        private ITaxFormService TaxFormService => (ITaxFormService)ServiceProvider.GetService(typeof(ITaxFormService));
        private IPOTaxCodeService POTaxCodeService => (IPOTaxCodeService)ServiceProvider.GetService(typeof(IPOTaxCodeService));

        /// <summary>
        /// Gets GlTransactions with Child data
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<QueryResults<PurchaseOrder>> GetPurchaseOrders(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null)
        {
            var company = await CompanyService.GetManyAsync(new QueryOptions { Filter = $"company_uuid eq '{ companyExternalId.ToString() }'" }, transaction);

            if (company == null || company.Items?.Count == 0)
                return new QueryResults<PurchaseOrder>(new List<PurchaseOrder>(), null, null, 0);

            string filter = $"company_id eq {company.Items.First().CompanyId}";
            filter = string.IsNullOrEmpty(options.Filter) ? filter : filter + " and " + options.Filter;
            return await GetPurchaseOrders(companyExternalId, options, filter, transaction);
        }

        private async Task<QueryResults<PurchaseOrder>> GetPurchaseOrders(Guid companyExternalId, QueryOptions options, string filter, IDbTransaction transaction = null)
        {
            var result = await GetManyAsync(options, transaction);

            if (result == null || !result.Items.Any())
                return new QueryResults<PurchaseOrder>(new List<PurchaseOrder>(), null, null, 0);

            foreach (var item in result.Items)
            {
                if (item.PurchaseOrderAccounts == null)
                    item.PurchaseOrderAccounts = new List<PurchaseOrderAccount>();

                if (item.PurchaseOrderId > 0)
                {
                    var details = PurchaseOrderDetailService.GetManyAsync(
                                          new QueryOptions
                                          {
                                              Filter = "purchase_order_id eq " + item.PurchaseOrderId
                                          }, transaction).Result;

                    if (details != null && details.Items != null)
                    {
                        foreach (var row in details?.Items)
                        {
                            var poAccount = PurchaseOrderAccountService.GetAsync((long)row.PurchaseOrderAccountId, transaction).Result;
                            if (poAccount != null)
                            {
                                if (poAccount.CoaId != null && poAccount.CoaId > 0)
                                {
                                    var ledgerCoa = CoaService.GetAsync((long)poAccount.CoaId, transaction).Result;
                                    if (ledgerCoa != null)
                                        poAccount.CoaUuid = ledgerCoa.CoaUuid;
                                }
                                if (poAccount.ProjectId != null && poAccount.ProjectId > 0)
                                {
                                    var ledgerProject = await ProjectService.GetAsync((long)poAccount.ProjectId, transaction);
                                    if (ledgerProject != null)
                                        poAccount.ProjectUuid = ledgerProject.ProjectUuid;
                                }

                                if (row.TaxCreditId.HasValue && row.TaxCreditId > 0)
                                    row.TaxCredit = (await POTaxCreditService.GetAsync((long)row.TaxCreditId, transaction))?.TaxCredit;

                                if (poAccount.PurchaseOrderDetails == null)
                                    poAccount.PurchaseOrderDetails = new List<PurchaseOrderDetail>();

                                poAccount.PurchaseOrderDetails.Add(row);

                                item.PurchaseOrderAccounts.Add(poAccount);
                            }
                        }
                    }
                }
            }

            return result;
        }

        partial void AfterGetMany(ref bool result, ref QueryResults<PurchaseOrder> values, ref IDbTransaction transaction)
        {
            var companyIds = values.Items.Select(s => s.CompanyId).ToList();
            if (companyIds != null && companyIds.Count > 0)
            {
                var companies = CompanyService.GetManyAsync(new QueryOptions() { Filter = $"company_id in ({string.Join(",", companyIds)})" }, transaction).Result;
                if (companies != null)
                {
                    values.Items.ForEach(x =>
                    {
                        var company = companies.Items.FirstOrDefault(m => m.CompanyId == x.CompanyId);
                        if (company != null)
                            x.CompanyUuid = company.CompanyUuid;
                    });
                }
            }

            var vendorIds = values.Items.Where(w => w.VendorId != null).Select(s => s.VendorId).ToList();
            if (vendorIds != null && vendorIds.Count > 0)
            {
                var vendors = VendorService.GetManyAsync(new QueryOptions() { Filter = $"vendor_id in ({string.Join(",", vendorIds)})" }, transaction).Result;
                if (vendors != null)
                {
                    values.Items.ForEach(x =>
                    {
                        var vendor = vendors.Items.FirstOrDefault(m => m.VendorId == x.VendorId);
                        if (vendor != null)
                            x.VendorUuid = vendor.VendorUuid;
                    });
                }
            }
        }
    }
}
