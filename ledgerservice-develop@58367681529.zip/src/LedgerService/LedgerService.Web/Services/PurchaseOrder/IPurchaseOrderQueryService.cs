using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial interface IPurchaseOrderService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<QueryResults<PurchaseOrder>> GetPurchaseOrders(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null);
    }
}
