﻿using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial interface IPurchaseOrderService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="glTranscationIds"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<bool> DeleteManyAsync(string glTranscationIds, IDbTransaction transaction = null);
    }
}
