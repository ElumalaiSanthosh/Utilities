﻿using ApiService.Commons.DataStore;
using ApiService.Commons.Events;
using ApiService.Commons.Exceptions;
using ApiService.Commons.Rest;
using ApiService.Commons.Utility;
using ApiService.Repositories;
using LedgerService.Models.Dtos;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{

    public partial class BatchService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="createRelatedRecords"></param>
        partial void AfterPost(ref bool result, ref Batch dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(dto);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Create, dto.GetType().Name);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="createRelatedRecords"></param>
        partial void AfterPut(ref bool result, ref Batch dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {

            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(dto);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Update, dto.GetType().Name);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        partial void AfterDelete(ref bool result, ref QueryOptions options, ref IDbTransaction transaction)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(options);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Delete, "Batch");
            }
        }


        /// <summary>
        /// This method validates and updates the default batch
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="createRelatedRecords"></param>
        partial void BeforePost(ref bool result, ref Batch dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            ValidateBatchDto(dto, transaction);
            if (dto.IsDefault)
                result = UpdateDefaultBatch(dto, transaction).Result;
            else
                result = true;
        }
        /// <summary>
        /// This method validates and updates the default batch 
        /// </summary>
        /// <param name="result"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <param name="updateRelatedRecords"></param>
        partial void BeforePut(ref bool result, ref Batch dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            ValidateBatchDto(dto, transaction);
            QueryOptions options = new QueryOptions
            {
                Filter = $"batch_id eq '{dto.BatchId}'  and company_uuid eq '{dto.CompanyUuid}' and user_uuid eq '{dto.UserUuid}'"
            };
            var batch = ReadAsync(options).Result;
            if (batch == null)
                throw new ApiServiceException(406, "Batch does not belong to either Company or User");
            else if (dto.IsDefault && !batch.IsDefault)
                result = UpdateDefaultBatch(dto, transaction).Result;
        }
        /// <summary>
        /// It checks whether the default key is assigned to any batch, if exist then it will set that batch is_default to false and current request batch to default.
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task<bool> UpdateDefaultBatch(Batch dto, IDbTransaction transaction = null)
        {
            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();
            try
            {
                string filter = $"user_uuid eq '{dto.UserUuid}' and is_default eq true";
                if (dto.BatchId > 0)
                {
                    filter += $" and batch_id ne {dto.BatchId}";
                }
               
                QueryResults<Batch> defaultBatchList = await GetManyAsync(new QueryOptions { Filter=filter});
                if (defaultBatchList != null && defaultBatchList.Items.Any())
                {
                    Batch defaultBatch = defaultBatchList.Items.FirstOrDefault();
                    defaultBatch.IsDefault = false;
                    defaultBatch = await UpdateAsync(defaultBatch, trans);
                    if (defaultBatch == null)
                    {
                        throw new ApiServiceException(100, "Record Not Updated properly");
                    }
                    return true;
                }
                CommitTransaction(handleTransaction, trans);
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
            return true;
        }
        /// <summary>
        /// Validates batch dto
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        private void ValidateBatchDto(Batch dto, IDbTransaction transaction)
        {
            dto.Name = dto.Name.Trim();
            if (dto==null)
            {
                throw new ApiRestException(HttpStatusCode.NotAcceptable, "Invalid input payload.");
            }
            else if (string.IsNullOrEmpty(dto.Name))
            {
                throw new ApiRestException(HttpStatusCode.NotAcceptable, "Batch Name is a Mandatory Field.");
            }
            else if (dto.Name.Length>50)
            {
                throw new ApiRestException(HttpStatusCode.NotAcceptable, "Batch Name cannot be longer than 50 characters.");
            }
            else if (IsValidBatchNameAsync(dto, transaction).Result)
            {
                throw new ApiRestException(HttpStatusCode.Conflict, $"Batch Name \"{dto.Name}\" already exists.");
            }
            else if (dto.BatchId < 1 && IsValidatMaxBatchCountAsync(dto, transaction).Result)
            {
                throw new ApiRestException(HttpStatusCode.NotAcceptable, $"Maximum 15 Batches can create for single User.");
            }
            else if (!(dto.AllowCreditCard == true || dto.AllowJournals==true||dto.AllowPayables==true || dto.AllowPettyCash == true || dto.AllowReceivables == true))
            {
                throw new ApiRestException(HttpStatusCode.NotAcceptable, $"Must have at least one module selected.");
            }
        }
       
        /// <summary>
        /// Validates whether batch with same batch Name exists
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task<bool> IsValidBatchNameAsync(Batch dto, IDbTransaction transaction)
        {
            string filter = $"LOWER(name) eq LOWER('{dto.Name}') and company_uuid eq '{dto.CompanyUuid}' and user_uuid eq '{dto.UserUuid}'";
            if(dto.BatchId>0)
            {
                filter += $" and batch_id ne {dto.BatchId}";
            }
            var batchDetails = await ReadAsync(new QueryOptions { Filter = filter}, transaction);
            return (batchDetails != null);
        }
        /// <summary>
        /// Validates whether maximum batches for user reached or not
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task<bool> IsValidatMaxBatchCountAsync(Batch dto, IDbTransaction transaction)
        {
            var batchDetails = await ReadManyAsync(new QueryOptions { Filter = $"user_uuid eq '{dto.UserUuid}' and company_uuid eq '{dto.CompanyUuid}'" }, transaction);
            return (batchDetails != null && batchDetails.Items.Count()==15);
        }
    }
}
