using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;
using ApiService.Services;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface ILedgerVendorService : IService<LedgerVendor>
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="vendorUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<long> GetIdByVendorUuid(Guid vendorUuid, IDbTransaction transaction = null);
        #endregion QueryService
    }
}
