﻿using ApiService.Commons.Rest;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerVendorService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="vendorUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<long> GetIdByVendorUuid(Guid vendorUuid, IDbTransaction transaction = null)
        {
            if (vendorUuid == null || vendorUuid == Guid.Empty)
            {
                throw new ArgumentException("Invalid Parameter (bankUuid).");
            }

            long vendorId = 0;

            string cacheKey = $"{Startup.BaseCacheKey}.ledgervendors.vendorUuid-{ vendorUuid }";

            string cacheValue = Cache.GetString(cacheKey);

            if (cacheValue != null)
            {
                //Log.LogTrace($"LedgerVendorService.GetIdByVendorUuid: Got Id from Cache {vendorUuid}");
                long.TryParse(cacheValue, out vendorId);
            }

            if (vendorId > 1)
            {
                return vendorId;
            }

            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();

            try
            {
                var vendor = await GetByVendorUuidAsync(vendorUuid, trans);

                bool addVendor = false;

                if (vendor == null || vendor.LedgerVendorId < 1)
                {
                    vendor = await PostAsync(new Models.Dtos.LedgerVendor { VendorUuid = vendorUuid }, trans);

                    if (vendor == null || vendor.LedgerVendorId < 1)
                    {
                        throw new ApiRestException(System.Net.HttpStatusCode.BadRequest, $"Could not find Ledger Vendor with UUID ({vendorUuid})");
                    }

                    addVendor = true;
                }

                if (!addVendor)
                {
                    Cache.SetString(cacheKey, vendor.LedgerVendorId.ToString());
                }

                CommitTransaction(handleTransaction, trans);
                return vendor.LedgerVendorId;
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
        }
    }
}
