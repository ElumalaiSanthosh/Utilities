﻿using LedgerService.Models.Dtos;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial interface IGlTransactionService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="glTransactionIds"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<bool> PatchAsync(long[] glTransactionIds, GlTransaction dto, IDbTransaction transaction = null);

        /// <summary>
        /// method signature to delete multiple gl transcation
        /// </summary>
        /// <param name="glTranscationIds"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<bool> DeleteManyAsync(string glTranscationIds, IDbTransaction transaction = null);

    }
}
