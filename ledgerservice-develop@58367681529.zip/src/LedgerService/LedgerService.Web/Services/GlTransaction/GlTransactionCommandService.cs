﻿using ApiService.Commons.DataStore;
using ApiService.Commons.Rest;
using ApiService.Commons.Utility;
using LedgerService.Models.Dtos;
using LedgerService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    public partial class GlTransactionService
    {
        partial void AfterDelete(ref bool result, ref QueryOptions options, ref IDbTransaction transaction)
        {
            if (result)
            {
                //here need to trigger an event
                string jsonStringify = JsonConvert.SerializeObject(options);
                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Delete, "GlTransaction");
            }
        }

        private List<GlAccount> glAccounts = null;
        private PaymentInfo paymentInfo = null;
        private Dictionary<string, long> bankDetails = new Dictionary<string, long>();

        partial void BeforePost(ref bool result, ref GlTransaction dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            var bankList = dto.PaymentInfo?.Payments?.Where(x => x.BankUuid != null && x.BankUuid != default(Guid)).Select(x => x.BankUuid);
            if (bankList != null)
            {
                dto.PaymentInfo.Payments.ForEach(x =>
                {
                    x.LedgerBankId = bankDetails.ContainsKey(x.BankUuid.ToString()) ? bankDetails[x.BankUuid.ToString()] : 0;
                });
            }

            if (dto.CreatedTs == null)
                dto.CreatedTs = DateTime.UtcNow;

            CheckAndUpdateCompanyAndProject(dto, transaction);

            UpdateLedgerTaxCodeIdAsync(dto, transaction).Wait();

            glAccounts = dto.GlAccounts;
            paymentInfo = dto.PaymentInfo;
        }

        private async Task UpdateLedgerTaxCodeIdAsync(GlTransaction dto, IDbTransaction transaction)
        {
            if (dto.SubsystemType == "AP" && dto.GlAccounts != null && dto.GlAccounts.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(dto.GlAccounts?.First().TaxFormName))
                {
                    var taxForm = await LedgerTaxFormService.ReadAsync(new QueryOptions { Filter = $"name eq '{dto.GlAccounts.First().TaxFormName}'" }, transaction);
                    if (taxForm == null)
                        throw new ApiRestException(HttpStatusCode.BadRequest, "Invalid Tax Code");

                    var taxCodeList = await LedgerTaxCodeService.ReadManyAsync(new QueryOptions { Filter = $"ledger_tax_form_id eq '{ taxForm.LedgerTaxFormId}'" }, transaction);

                    dto.GlAccounts.ForEach(item =>
                    {
                        if (!string.IsNullOrWhiteSpace(item.TaxCode))
                        {
                            var taxCodeDetails = taxCodeList?.Items?.FirstOrDefault(x => x.TaxCode.Equals(item.TaxCode));
                            if (taxCodeDetails == null)
                                throw new ApiRestException(HttpStatusCode.BadRequest, "Invalid Tax Code");

                            item.LedgerTaxCodeId = taxCodeDetails.LedgerTaxCodeId;
                        }
                    });
                }
            }
        }

        partial void AfterPost(ref bool result, ref GlTransaction dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            dto.GlAccounts = glAccounts;
            dto.PaymentInfo = paymentInfo;
            CheckAndUpdateGlAccounts(dto, transaction).Wait();
            PostPaymentInfo(dto, transaction).Wait();
            dto.PaymentInfo?.Payments?.ForEach(x =>
            {
                if (x.LedgerBankId != null && x.LedgerBankId > 0)
                    bankDetails.TryAdd(x.BankUuid.ToString(), (long)x.LedgerBankId);
            });

            // Add Batch to dto to be passed to
            var newDto = dto;
            if (dto.BatchId != null && dto.BatchId > 0)
            {
                var batches = new List<Batch>();
                var batch = BatchService.GetAsync(dto.BatchId.Value).Result;
                if (batch != null)
                {
                    batches.Add(batch);
                    newDto.Batches = batches;
                }
            }

            string jsonStringify = JsonConvert.SerializeObject(newDto);
            ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Create, dto.GetType().Name);
        }

        /// <summary>
        /// Validate dto's
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public bool ValidateDto(GlTransaction dto, IDbTransaction transaction)
        {
            TransactionType type;
            switch (dto.SubsystemType.ToEnum<SubsystemType>())
            {
                case SubsystemType.JE:
                    type = dto.GlTransactionType.ToEnum<TransactionType>();
                    switch (type)
                    {
                        case TransactionType.REVERSING:
                            if (dto.ReversalDate == null || dto.ReversalDate == default(DateTime))
                                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Reversal Date is a Mandatory Field");
                            break;

                        case TransactionType.RECURRING:
                            if (dto.RecurrenceStartDate == null || dto.RecurrenceStartDate == default(DateTime))
                                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Recurring Start Date is a Mandatory Field");
                            else if (dto.RecurrenceEndDate == null || dto.RecurrenceEndDate == default(DateTime))
                                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Recurring End Date is a Mandatory Field");
                            //Implemet validation in recurring story:
                            //ValidateJERecurringTypeDto(dto)
                            break;

                        case TransactionType.STANDARD:
                            CheckDuplicateJournal(dto, transaction);
                            break;

                        case TransactionType.ICT:
                        case TransactionType.None:
                            throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid JE Transaction Type");
                    }
                    dto.GlTransactionType = type.GetDescription();
                    break;

                case SubsystemType.AP:
                    type = dto.GlTransactionType.ToEnum<TransactionType>();
                    switch (type)
                    {
                        case TransactionType.ICT:
                        case TransactionType.None:
                            throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid AP Transaction Type");
                    }
                    dto.GlTransactionType = type.GetDescription();
                    break;

                default:
                    throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid Subsystem Type");
            }
            return true;
        }

        /// <summary>
        /// check duplicate journal number
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        private void CheckDuplicateJournal(GlTransaction dto, IDbTransaction transaction)
        {
            var options = new QueryOptions
            {
                Filter = $"ledger_company_id eq {dto.LedgerCompanyId} and document_number eq '{dto.DocumentNumber.ToDbCompatibleString()}'"
            };
            if (dto.GlTransactionId > 0)
                options.Filter += $" and gl_transaction_id ne {dto.GlTransactionId}";

            var records = GetManyAsync(options, transaction).Result;
            if (records?.Items.Count > 0)
                throw new ApiRestException(System.Net.HttpStatusCode.Conflict, $"Journal cannot be duplicate");
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        private void CheckAndUpdateCompanyAndProject(GlTransaction dto, IDbTransaction transaction)
        {
            if (dto.CompanyUuid != null && dto.CompanyUuid != default(Guid))
            {
                if (!dto.LedgerCompanyId.HasValue || dto.LedgerCompanyId == 0)
                {
                    //check data if exists in ledger company table.
                    var ledgerCompany = CheckAndGetLedgerCompanyAsync((Guid)dto.CompanyUuid, transaction).Result;
                    dto.LedgerCompanyId = ledgerCompany?.LedgerCompanyId;
                }
                if (dto.ProjectUuid != null && dto.ProjectUuid != default(Guid) && (!dto.LedgerProjectId.HasValue || dto.LedgerProjectId == 0))
                {
                    var ledgerProject = CheckAndGetLedgerProjectAsync((Guid)dto.ProjectUuid, transaction).Result;
                    dto.LedgerProjectId = ledgerProject?.LedgerProjectId;
                }
            }
            else
                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid company_uuid");
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="company_uuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task<LedgerCompany> CheckAndGetLedgerCompanyAsync(Guid company_uuid, IDbTransaction transaction)
        {
            var ledgerCompany = await LedgerCompanyService.GetLedgerCompanyByCompanyUuidAsync(company_uuid);
            if (ledgerCompany == null)
                ledgerCompany = await LedgerCompanyService.PostAsync(new LedgerCompany { CompanyUuid = company_uuid }, transaction);

            return ledgerCompany;
        }

        private async Task<LedgerProject> CheckAndGetLedgerProjectAsync(Guid project_uuid, IDbTransaction transaction)
        {
            var ledgerProject = await LedgerProjectService.GetLedgerProjectByProjectUuid(project_uuid);
            if (ledgerProject == null)
                ledgerProject = await LedgerProjectService.PostAsync(new LedgerProject { ProjectUuid = project_uuid }, transaction);

            return ledgerProject;
        }

        private async Task CheckAndUpdateGlAccounts(GlTransaction dto, IDbTransaction transaction)
        {
            if (dto.GlAccounts?.Count > 0)
            {
                await UpdateGlAccountDetails(dto, transaction);
                GlAccount glAccount = null;
                List<GlTransactionDetail> glTransactionDetail = null;
                await dto.GlAccounts.ForEachAsync(async account =>
                {
                    glAccount = await GlAccountService.PostAsync(account, transaction, false);
                    if (glAccount != null)
                    {
                        account.GlTransactionDetails.ToList().ForEach(c => c.GlAccountId = glAccount.GlAccountId);
                        glTransactionDetail = (await GlTransactionDetailService.PostAsync(account.GlTransactionDetails, transaction)).ToList();
                        glAccount.GlTransactionDetails = glTransactionDetail;
                        account = glAccount;
                    }
                });
            }
        }

        private async Task PostPaymentInfo(GlTransaction dto, IDbTransaction transaction)
        {
            if (dto.PaymentInfo != null)
            {
                switch (dto.SubsystemType.ToEnum<SubsystemType>())
                {
                    case SubsystemType.AP:
                    case SubsystemType.PP:
                    case SubsystemType.AR:
                    case SubsystemType.DE:
                    case SubsystemType.PC:
                    case SubsystemType.CC:
                        dto.PaymentInfo.GlTransactionId = dto.GlTransactionId;
                        await PaymentInfoService.PostAsync(dto.PaymentInfo, transaction);
                        break;
                }
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task PutPaymentInfo(GlTransaction dto, IDbTransaction transaction)
        {
            switch (dto.SubsystemType.ToEnum<SubsystemType>())
            {
                case SubsystemType.AP:
                case SubsystemType.AR:
                case SubsystemType.DE:
                case SubsystemType.PC:
                case SubsystemType.CC:
                    var paymentInfo = await PaymentInfoService.GetManyAsync(new QueryOptions { Filter = $"gl_transaction_id eq {dto.GlTransactionId}" });
                    if (dto.PaymentInfo != null)
                    {
                        dto.PaymentInfo.GlTransactionId = dto.GlTransactionId;
                        if (paymentInfo?.Items?.Count > 0)
                        {
                            dto.PaymentInfo.PaymentInfoId = paymentInfo.Items.First().PaymentInfoId;
                            await PaymentInfoService.PutAsync(dto.PaymentInfo.PaymentInfoId, dto.PaymentInfo, transaction);
                        }
                        else
                        {
                            dto.PaymentInfo.PaymentInfoId = 0;
                            await PaymentInfoService.PostAsync(dto.PaymentInfo, transaction);
                        }
                    }
                    else
                    {
                        if (paymentInfo?.Items?.Count > 0)
                            await PaymentInfoService.DeleteAsync(new QueryOptions { Filter = $"payment_info_id eq {paymentInfo.Items.First().PaymentInfoId}" }, transaction);
                    }
                    break;
            }
        }

        private async Task UpdateGlAccountDetails(GlTransaction dto, IDbTransaction transaction)
        {
            if (dto.GlAccounts?.Count > 0)
            {
                if (!dto.SkipUpdateAccountDetails)
                {
                    await dto.GlAccounts.ForEachAsync(async account =>
                    {
                        account.LedgerCoaId = (await CheckAndGetLedgerCOAAsync(account.CoaUuid, transaction))?.LedgerCoaId;
                        if (account.ProjectUuid != null)
                            account.LedgerProjectId = (await CheckAndGetLedgerProjectAsync((Guid)account.ProjectUuid, transaction)).LedgerProjectId;
                        await account.GlTransactionDetails.ForEachAsync(async detail =>
                        {
                            detail.GlTransactionId = dto.GlTransactionId;
                            detail.CaTaxCreditId = (await CheckAndGetTaxCreditAsync(detail.TaxCredit, dto.LedgerCompanyId, transaction))?.CaTaxCreditId;
                        });
                    });
                }
                else
                {
                    dto.GlAccounts.ForEach(account =>
                    {
                        account.GlTransactionDetails?.ForEach(detail =>
                        {
                            detail.GlTransactionId = dto.GlTransactionId;
                        });
                    });
                }
            }
        }

        private async Task<LedgerCoa> CheckAndGetLedgerCOAAsync(Guid? coa_uuid, IDbTransaction transaction)
        {
            if (!string.IsNullOrWhiteSpace(coa_uuid.ToString()))
            {
                var ledgerCoa = await LedgerCoaService.GetManyAsync(new QueryOptions { Filter = "coa_uuid eq '" + coa_uuid + "'" });
                if (ledgerCoa == null || ledgerCoa?.Items?.Count < 1)
                    return await LedgerCoaService.PostAsync(new LedgerCoa { CoaUuid = (Guid)coa_uuid }, transaction);

                return ledgerCoa.Items.FirstOrDefault();
            }
            return null;
        }

        private async Task<CaTaxCredit> CheckAndGetTaxCreditAsync(string taxCredit, long? ledgerCompanyId, IDbTransaction transaction)
        {
            if (!string.IsNullOrWhiteSpace(taxCredit) && ledgerCompanyId != null)
            {
                var caTaxCredit = await CaTaxCreditService.GetManyAsync(new QueryOptions { Filter = "tax_credit eq '" + taxCredit + "' and ledger_company_id eq " + ledgerCompanyId.ToString() });
                if (caTaxCredit == null || caTaxCredit?.Items?.Count < 1)
                    return await CaTaxCreditService.PostAsync(new CaTaxCredit { LedgerCompanyId = (long)ledgerCompanyId, TaxCredit = taxCredit }, transaction);

                return caTaxCredit.Items.FirstOrDefault();
            }

            return null;
        }

        /// <summary>
        /// Validate dto recurring type
        /// </summary>
        /// <param name="dto"></param>
        public void ValidateJERecurringTypeDto(GlTransaction dto)
        {
            if (dto.RecurrenceStartDate == null || dto.RecurrenceStartDate == default(DateTime))
                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Recurring Start Date is a Mandatory Field");
            else if (dto.RecurrenceEndDate == null || dto.RecurrenceEndDate == default(DateTime))
                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Recurring End Date is a Mandatory Field");

            //Remove time part from the inupt dates
            dto.RecurrenceStartDate = dto.RecurrenceStartDate.Value.Date;
            dto.RecurrenceEndDate = dto.RecurrenceEndDate.Value.Date;
            bool invalidDateRange = false;
            if (dto.RecurrenceEndDate > dto.RecurrenceStartDate)
            {
                switch (dto.RecurrenceType.ToEnum<RecurringType>())
                {
                    case RecurringType.Daily:
                        if (((DateTime)dto.RecurrenceEndDate - (DateTime)dto.RecurrenceStartDate).TotalDays < 1)
                            invalidDateRange = true;
                        break;

                    case RecurringType.Weekly:
                        if ((((DateTime)dto.RecurrenceEndDate - (DateTime)dto.RecurrenceStartDate).TotalDays % 7) != 0)
                            invalidDateRange = true;
                        break;

                    case RecurringType.Monthly:
                    case RecurringType.Quarterly:
                    case RecurringType.Yearly:
                        if (!IsValidMonthRange((DateTime)dto.RecurrenceEndDate, (DateTime)dto.RecurrenceStartDate, dto.RecurrenceType.ToEnum<RecurringType>()))
                            invalidDateRange = true;
                        break;

                    case RecurringType.None:
                        throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid Recurring Type");
                }
            }
            else
                invalidDateRange = true;

            if (invalidDateRange)
                throw new ApiRestException(System.Net.HttpStatusCode.NotAcceptable, "Invalid recurring date range");
        }

        /// <summary>
        /// Check valid month range between 2 dates
        /// </summary>
        /// <param name="recurrenceEndDate"></param>
        /// <param name="recurrenceStartDate"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private bool IsValidMonthRange(DateTime recurrenceEndDate, DateTime recurrenceStartDate, RecurringType type)
        {
            bool result = false;
            DateTime startMonthDate;
            DateTime endMonthDate;
            int maxMonth = 12;
            int mApart = 0;
            if ((recurrenceEndDate - recurrenceStartDate).TotalDays > 28)
            {
                if (recurrenceStartDate.Year == recurrenceEndDate.Year)
                {
                    if (recurrenceEndDate.Month - recurrenceStartDate.Month > 0)
                        mApart = recurrenceEndDate.Month - recurrenceStartDate.Month;
                    else
                        mApart = 1;
                }
                else
                {
                    int yearDiff = recurrenceEndDate.Year - recurrenceStartDate.Year;
                    if (yearDiff > 1)
                    {
                        int smDiff = maxMonth - recurrenceStartDate.Month;
                        mApart = smDiff + recurrenceEndDate.Month + ((yearDiff - 1) * maxMonth);
                    }
                    else
                    {
                        int smDiff = maxMonth - recurrenceStartDate.Month;
                        mApart = smDiff + recurrenceEndDate.Month;
                    }
                }
                if (mApart > 0)
                {
                    startMonthDate = new DateTime(recurrenceStartDate.Year, recurrenceStartDate.Month, 1);
                    endMonthDate = startMonthDate.AddMonths(mApart);
                    if ((endMonthDate - startMonthDate).TotalDays == (recurrenceEndDate - recurrenceStartDate).TotalDays)
                    {
                        result = true;
                    }
                }
            }
            if (result)
                result = (mApart % int.Parse(type.GetDescription())) == 0;

            return result;
        }

        partial void BeforePut(ref bool result, ref GlTransaction dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            GlTransaction glTransaction = GetAsync(dto.GlTransactionId).Result;
            dto.ExternalId = glTransaction.ExternalId;
            dto.CreatedTs = glTransaction.CreatedTs;
            dto.PreviousPostState = glTransaction.PostState;

            UpdateLedgerTaxCodeIdAsync(dto, transaction).Wait();
        }

        partial void AfterPut(ref bool result, ref GlTransaction dto, ref IDbTransaction transaction, ref bool updateRelatedRecords)
        {
            if (updateRelatedRecords)
                result = UpdateAccountsAsync(dto, transaction).Result;

            PutPaymentInfo(dto, transaction).Wait();

            if (result && (dto.PostState.ToEnum<PostState>() == PostState.POSTED
            || dto.PostState.ToEnum<PostState>() == PostState.REVERSED
            || dto.PostState.ToEnum<PostState>() == PostState.VOIDED))
            {
                if (dto.PreviousPostState.ToEnum<PostState>() == PostState.POSTED && dto.PostState.ToEnum<PostState>() == PostState.VOIDED)
                {
                    var voidTransaction = CreateReversingOrVoidEntry(dto, ref transaction, true);
                    var patchData = new GlTransaction
                    {
                        GlTransactionId = dto.GlTransactionId,
                        ReferenceGlTransactionId = voidTransaction.GlTransactionId,
                        Tags = GlTransactionPatchTag.ReferenceGlTransactionId.ToString()
                    };
                    dto.ReferenceGlTransactionId = voidTransaction.GlTransactionId;
                    PatchAsync(new long[] { dto.GlTransactionId }, patchData, transaction).Wait();
                }
            }

            // Add Batch to dto to be passed to
            var newDto = dto;
            if (dto.BatchId != null && dto.BatchId > 0)
            {
                var batches = new List<Batch>();
                var batch = BatchService.GetAsync(dto.BatchId.Value).Result;
                if (batch != null)
                {
                    batches.Add(batch);
                    newDto.Batches = batches;
                }
            }

            string jsonStringify = JsonConvert.SerializeObject(newDto);
            ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Update, dto.GetType().Name);
        }

        private GlTransaction CreateReversingOrVoidEntry(GlTransaction dto, ref IDbTransaction transaction, bool isVoid = false)
        {
            GlTransaction glTransaction = dto.Clone();

            if (glTransaction.PaymentInfo?.Payments != null)
                glTransaction.PaymentInfo.Payments = null;

            glTransaction.GlTransactionId = 0;
            glTransaction.DocumentAmount = glTransaction.DocumentAmount * -1;
            glTransaction.ExternalId = null;
            glTransaction.ReversalDate = null;
            glTransaction.ReferenceGlTransactionId = dto.GlTransactionId;
            glTransaction.SkipUpdateAccountDetails = true;
            glTransaction.CreatedTs = DateTime.UtcNow;
            if (isVoid)
            {
                glTransaction.DocumentNumber += "-VOID";
                glTransaction.GlTransactionType = TransactionType.STANDARD.ToString();
                glTransaction.PostState = PostState.VOIDED.ToString();
                glTransaction.DocumentDate = dto.VoidDate;
                if (dto.SubsystemType != SubsystemType.AP.ToString() && dto.SubsystemType != SubsystemType.AR.ToString())
                    glTransaction.PostDate = DateTime.UtcNow;
            }
            else
            {
                glTransaction.DocumentNumber += "-Reversing";
                glTransaction.GlTransactionType = TransactionType.STANDARD.ToString();
                glTransaction.PostState = PostState.UNPOSTED.ToString();
                glTransaction.DocumentDate = dto.ReversalDate;
                glTransaction.PostDate = null;
            }
            glTransaction.GlAccounts = new List<GlAccount>();
            GlAccount account = null;
            dto.GlAccounts?.ForEach(glAccount =>
            {
                account = glAccount.Clone();
                account.GlAccountId = 0;
                var transactionDetail = account.GlTransactionDetails?.FirstOrDefault().Clone();
                if (transactionDetail != null)
                {
                    transactionDetail.GlAccountId = 0;
                    transactionDetail.GlTransactionDtailId = 0;
                    transactionDetail.GlTransactionId = 0;
                    transactionDetail.Amount *= -1;
                }
                account.GlTransactionDetails = new List<GlTransactionDetail> { transactionDetail };
                glTransaction.GlAccounts.Add(account);
            });
            if (dto.PaymentInfo != null)
            {
                glTransaction.PaymentInfo = dto.PaymentInfo.Clone();
                glTransaction.PaymentInfo.PaymentInfoId = 0;
                if (dto.PaymentInfo.Payments?.Count > 0)
                {
                    glTransaction.PaymentInfo.Payments = new List<Payment>();
                    Payment payment = null;
                    dto.PaymentInfo.Payments.ForEach(x =>
                  {
                      payment = x.Clone();
                      payment.PaymentId = 0;
                      glTransaction.PaymentInfo.Payments.Add(x);
                  });
                }
            }

            var reversedDto = PostAsync(glTransaction, transaction).Result;

            //Update reference transaction id for reversal JE
            if (reversedDto.ReferenceGlTransactionId != null
                && (reversedDto.SubsystemType.ToEnum<SubsystemType>() == SubsystemType.JE
                || reversedDto.SubsystemType.ToEnum<SubsystemType>() == SubsystemType.AP
                || reversedDto.SubsystemType.ToEnum<SubsystemType>() == SubsystemType.PP)
                && reversedDto.GlTransactionType.ToEnum<TransactionType>() == TransactionType.STANDARD
                && reversedDto.PostState.ToEnum<PostState>() == PostState.UNPOSTED)
            {
                var patchData = new GlTransaction
                {
                    GlTransactionId = (long)reversedDto.ReferenceGlTransactionId,
                    ReferenceGlTransactionId = reversedDto.GlTransactionId,
                    Tags = GlTransactionPatchTag.ReferenceGlTransactionId.ToString()
                };
                PatchAsync(new long[] { (long)reversedDto.ReferenceGlTransactionId }, patchData, transaction).Wait();
            }
            return reversedDto;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        private async Task<bool> UpdateAccountsAsync(GlTransaction dto, IDbTransaction transaction)
        {
            bool result = true;
            string filter = $"gl_transaction_id eq {dto.GlTransactionId}";
            var transactionDetailIds = dto.GlAccounts?.Where(e => e.GlAccountId > 0 && e.GlTransactionDetails.FirstOrDefault() != null).Select(C => C.GlTransactionDetails.FirstOrDefault().GlTransactionDtailId).ToList();
            if (transactionDetailIds != null && transactionDetailIds.Any())
            {
                filter += $" and gl_transaction_detail_id NOT IN({string.Join(", ", transactionDetailIds)})";
            }
            var glTransactionDetails = await GlTransactionDetailService.GetManyAsync(new QueryOptions { Filter = filter });
            if (glTransactionDetails?.Items.Count > 0)
            {
                string accountIds = string.Join(',', glTransactionDetails.Items.Select(d => d.GlAccountId));
                result = await GlAccountService.DeleteAsync(new QueryOptions() { Filter = $"gl_account_id in ({accountIds})" }, transaction);
            }

            if (result && dto.GlAccounts?.Count > 0)
            {
                await UpdateGlAccountDetails(dto, transaction);
                //Update
                if (dto.GlAccounts.Any(x => x.GlAccountId > 0))
                    await GlAccountService.PutAsync(dto.GlAccounts.Where(a => a.GlAccountId > 0), transaction);
                //Create
                if (dto.GlAccounts.Any(x => x.GlAccountId == 0))
                    await GlAccountService.PostAsync(dto.GlAccounts.Where(a => a.GlAccountId == 0), transaction);
            }
            return result;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="glTransactionIds"></param>
        /// <param name="dto"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<bool> PatchAsync(long[] glTransactionIds, GlTransaction dto, IDbTransaction transaction = null)
        {
            if (dto == null)
                throw new ApiRestException(HttpStatusCode.BadRequest, "The Dto is null.");

            if (glTransactionIds.Length == 1 && dto.GlTransactionId != glTransactionIds[0])
                throw new ApiRestException(HttpStatusCode.NotAcceptable, "Id does not match with Dto Id");

            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();
            try
            {
                bool result = false;
                string filter = $"gl_transaction_id in ({string.Join(',', glTransactionIds)})";
                string statement = PatchHelper.GetStatement("GlTransaction", GetTagValueDictionary(dto), filter);
                if (!string.IsNullOrEmpty(statement))
                {
                    int rows = await ExecuteAsync(statement, trans);
                    result = rows == glTransactionIds.Length;
                }
                if (result)
                    CommitTransaction(handleTransaction, trans);
                else
                    RollbackTransaction(handleTransaction, trans);
                return result;
            }
            catch (Exception e)
            {
                RollbackTransaction(handleTransaction, trans);
                throw e;
            }
        }

        private Dictionary<string, object> GetTagValueDictionary(GlTransaction dto)
        {
            Dictionary<string, object> tagValueDictionary = null;
            if (!string.IsNullOrEmpty(dto.Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = dto.Tags.Split(',');
                foreach (var tag in tags)
                {
                    GlTransactionPatchTag enumTag = tag.ToEnum<GlTransactionPatchTag>();
                    if (enumTag != GlTransactionPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, GetValueFromTag(dto, enumTag));
                    }
                }
            }
            return tagValueDictionary;
        }

        private object GetValueFromTag(GlTransaction dto, GlTransactionPatchTag tag)
        {
            switch (tag)
            {
                case GlTransactionPatchTag.PostState:
                    return dto.PostState;

                case GlTransactionPatchTag.PostDate:
                    return dto.PostDate;

                case GlTransactionPatchTag.DocumentDate:
                    return dto.DocumentDate;

                case GlTransactionPatchTag.Description:
                    return dto.Description.ToDbCompatibleString();

                case GlTransactionPatchTag.ReferenceGlTransactionId:
                    return dto.ReferenceGlTransactionId;

                default:
                    return null;
            }
        }

        /// <summary>
        /// Method to delete multiple records
        /// </summary>
        /// <param name="glTranscationIds"></param>
        /// <param name="transaction"></param>
        public async Task<bool> DeleteManyAsync(string glTranscationIds, IDbTransaction transaction = null)
        {
            var glTranscationIdList = glTranscationIds.Split(',').Where(i => long.TryParse(i, out long num)).ToList();
            var options = new QueryOptions
            {
                Filter = "gl_transaction_id in (" + string.Join(",", glTranscationIdList) + $")"
            };
            var glTransactionIds = await GetIdListForDelete(options);
            if (!glTransactionIds.Any())
                return false;

            bool handleTransaction = transaction == null;
            transaction = transaction ?? BeginTransaction();

            var deleteResult = true;
            try
            {
                var transactionDetails = await GlTransactionDetailService.GetDynamicObjectsAsync(new List<string>() { "gl_account_id" }, new QueryOptions() { Filter = "gl_transaction_id in (" + string.Join(",", glTransactionIds) + ")" });

                var glAccountIds = new List<long>();
                glAccountIds.AddRange(transactionDetails.Items.Select(t => (long)t.gl_account_id));
                if (glAccountIds?.Count > 0)
                    deleteResult = await GlAccountService.DeleteAsync(new QueryOptions() { Filter = "gl_account_id in (" + string.Join(",", glAccountIds) + ")" }, transaction);

                var paymentInfoIds = (await PaymentInfoService.GetManyAsync(new QueryOptions() { Filter = "gl_transaction_id in (" + string.Join(",", glTranscationIdList) + ")" }))?.Items?.Select(x => x.PaymentInfoId)?.ToList();

                if (paymentInfoIds?.Count > 0)
                    deleteResult = deleteResult && await PaymentInfoService.DeleteAsync(new QueryOptions() { Filter = "payment_info_id in (" + string.Join(",", paymentInfoIds) + ")" }, transaction);

                if (glTransactionIds?.Count() > 0)
                    deleteResult = deleteResult && await DeleteAsync(new QueryOptions() { Filter = "gl_transaction_id in (" + string.Join(",", glTransactionIds) + ")" }, transaction);

                if (deleteResult)
                    CommitTransaction(handleTransaction, transaction);
                else
                    RollbackTransaction(handleTransaction, transaction);
            }
            catch (Exception)
            {
                deleteResult = false;
                RollbackTransaction(handleTransaction, transaction);
            }
            return deleteResult;
        }
    }
}