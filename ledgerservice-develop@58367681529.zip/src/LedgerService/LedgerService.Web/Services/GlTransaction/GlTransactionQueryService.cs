using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using LedgerService.Models.Enumerations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{/// <summary>
/// 
/// </summary>
    public partial class GlTransactionService
    {
        private ILedgerCoaService _ledgerCoaService;
        private ILedgerCoaService LedgerCoaService => _ledgerCoaService ?? (_ledgerCoaService = (ILedgerCoaService)ServiceProvider.GetService(typeof(ILedgerCoaService)));

        private ICaTaxCreditService _caTaxCreditService;
        private ICaTaxCreditService CaTaxCreditService => _caTaxCreditService ?? (_caTaxCreditService = (ICaTaxCreditService)ServiceProvider.GetService(typeof(ICaTaxCreditService)));

        private IGlAccountService _glAccountService;
        private IGlAccountService GlAccountService => _glAccountService ?? (_glAccountService = (IGlAccountService)ServiceProvider.GetService(typeof(IGlAccountService)));

        private IGlTransactionDetailService _glTransactionDetailService;
        private IGlTransactionDetailService GlTransactionDetailService => _glTransactionDetailService ?? (_glTransactionDetailService = (IGlTransactionDetailService)ServiceProvider.GetService(typeof(IGlTransactionDetailService)));

        private IPaymentInfoService _paymentInfoService;
        private IPaymentInfoService PaymentInfoService => _paymentInfoService ?? (_paymentInfoService = (IPaymentInfoService)ServiceProvider.GetService(typeof(IPaymentInfoService)));


        private ILedgerTaxFormService _ledgerTaxFormService;
        private ILedgerTaxFormService LedgerTaxFormService => _ledgerTaxFormService ?? (_ledgerTaxFormService = (ILedgerTaxFormService)ServiceProvider.GetService(typeof(ILedgerTaxFormService)));

        private ILedgerTaxCodeService _ledgerTaxCodeService;
        private ILedgerTaxCodeService LedgerTaxCodeService => _ledgerTaxCodeService ?? (_ledgerTaxCodeService = (ILedgerTaxCodeService)ServiceProvider.GetService(typeof(ILedgerTaxCodeService)));


        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<QueryResults<GlTransaction>> GetUnPostedJournals(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null)
        {
            var ledgerCompany = await LedgerCompanyService.GetLedgerCompanyByCompanyUuidAsync(companyExternalId, transaction);
            if (ledgerCompany == null)
                return new QueryResults<GlTransaction>(new List<GlTransaction>(), null, null, 0);

            string filter = $"ledger_company_id eq {ledgerCompany.LedgerCompanyId} and UPPER(post_state) eq '{PostState.UNPOSTED }'";
            filter = string.IsNullOrEmpty(options.Filter) ? filter : filter + " and " + options.Filter;
            return await GetGlTransactions(companyExternalId, options, filter, transaction);
        }
        /// <summary>
        /// Gets GlTransactions with Child data
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<QueryResults<GlTransaction>> GetGlTransactions(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null)
        {
            var ledgerCompany = await LedgerCompanyService.GetLedgerCompanyByCompanyUuidAsync(companyExternalId, transaction);
            if (ledgerCompany == null)
            {
                return new QueryResults<GlTransaction>(new List<GlTransaction>(), null, null, 0);
            }
            string filter = $"ledger_company_id eq {ledgerCompany.LedgerCompanyId}";
            filter = string.IsNullOrEmpty(options.Filter) ? filter : filter + " and " + options.Filter;
            return await GetGlTransactions(companyExternalId, options, filter, transaction);
        }
        /// <summary>
        /// GetUnPostedJournals
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<QueryResults<GlTransaction>> GetTransactions(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null)
        {
            GlAccount glAccount = null;
            var ledgerCompany = await LedgerCompanyService.GetLedgerCompanyByCompanyUuidAsync(companyExternalId, transaction);
            if (ledgerCompany == null)
            {
                return new QueryResults<GlTransaction>(new List<GlTransaction>(), null, null, 0);
            }

            var filter = $"ledger_company_id eq {ledgerCompany.LedgerCompanyId}";
            filter = string.IsNullOrEmpty(options.Filter) ? filter : filter + " and " + options.Filter;
            int index = 0;
            var queryOptions = new QueryOptions
            {
                Filter = filter,
                Orderby = options.Orderby == "batch_name" ? null : options.Orderby,
                Skip = options.Skip,
                Top = options.Top
            };

            //TODO : order by child batch name
            var result = await ReadManyAsync(queryOptions, null);
            Guid? ledgerCoaUuid = null;
            Guid? ledgerProjectUuid = null;

            if (result == null || !result.Items.Any())
            {
                result = new QueryResults<GlTransaction>(new List<GlTransaction>(), null, null, 0);
            }
            else
            {
                foreach (var item in result.Items)
                {
                    index = 0;
                    if (item.GlAccounts == null)
                        item.GlAccounts = new List<GlAccount>();
                    if (item.Batches == null)
                        item.Batches = new List<Batch>();

                    if (item.GlTransactionId > 0)
                    {
                        // Get batch detail for particular transaction id
                        if (item.BatchId != null && item.BatchId > 0)
                        {
                            Batch batch = BatchService.GetAsync((long)item.BatchId, null).Result;
                            if (batch != null)
                            {
                                item.Batches.Insert(index, batch);
                            }
                        }

                        item.PaymentInfo = (await PaymentInfoService.GetManyAsync(new QueryOptions { Filter = "gl_transaction_id eq " + item.GlTransactionId }))?.Items?.FirstOrDefault();

                        // Get transaction detail for particular transaction id
                        QueryResults<GlTransactionDetail> transactions = GlTransactionDetailService.GetManyAsync(
                                                                                  new QueryOptions
                                                                                  {
                                                                                      Filter = "gl_transaction_id eq " + item.GlTransactionId
                                                                                  }, transaction).Result;
                        // Get ledger project detail for particular transaction id
                        if (item.LedgerProjectId != null && item.LedgerProjectId > 0)
                        {
                            var ledgerProject = LedgerProjectService.GetAsync((long)item.LedgerProjectId, transaction).Result;
                            if (ledgerProject != null)
                            {
                                ledgerProjectUuid = ledgerProject.ProjectUuid;
                            }
                        }

                        if (transactions != null && transactions.Items != null)
                        {
                            foreach (var row in transactions?.Items)
                            {
                                // Get account detail for particular transaction id
                                glAccount = GlAccountService.GetAsync((long)row.GlAccountId, null).Result;
                                if (glAccount != null)
                                {
                                    if (glAccount.LedgerCoaId != null && glAccount.LedgerCoaId > 0)
                                    {
                                        var ledgerCoa = LedgerCoaService.GetAsync((long)glAccount.LedgerCoaId, null).Result;
                                        if (ledgerCoa != null)
                                        {
                                            glAccount.CoaUuid = ledgerCoaUuid = ledgerCoa.CoaUuid;
                                        }
                                    }
                                    glAccount.ProjectUuid = ledgerProjectUuid;

                                    if (glAccount.GlTransactionDetails == null)
                                        glAccount.GlTransactionDetails = new List<GlTransactionDetail>();

                                    glAccount.GlTransactionDetails.Add(row);

                                    item.GlAccounts.Insert(index, glAccount);
                                    index += 1;
                                }
                            }
                        }
                        item.VarianceAmount = transactions?.Items.Sum(litem => litem.Amount);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="subSystem"></param>
        /// <returns></returns>
        public async Task<int> GetUnpostedGlCount(Guid companyExternalId, string subSystem = "JE")
        {
            var count = 0;
            if (companyExternalId != default)
            {
                var ledgerCompany = await LedgerCompanyService.GetLedgerCompanyByCompanyUuidAsync(companyExternalId);
                if (ledgerCompany?.LedgerCompanyId > 0)
                {
                    if (string.IsNullOrEmpty(subSystem))
                        subSystem = SubsystemType.JE.ToString();
                    var transactions = await GetListAsync("gl_transaction_id", new QueryOptions
                    {
                        Filter = $"ledger_company_id eq {ledgerCompany.LedgerCompanyId} and post_state eq '{PostState.UNPOSTED}' and subsystem_type eq '{subSystem}'"
                    });
                    count = transactions?.TotalCount ?? 0;
                }
            }
            return count;
        }

        #region Private Methods
        private async Task<QueryResults<GlTransaction>> GetGlTransactions(Guid companyExternalId, QueryOptions options, string filter, IDbTransaction transaction = null)
        {
            GlAccount glAccount = null;
            int index = 0;
            var queryOptions = new QueryOptions
            {
                Filter = filter,
                Orderby = options.Orderby == "batch_name" ? null : options.Orderby,
                Skip = options.Skip,
                Top = options.Top
            };

            //TODO : order by child batch name
            var result = await ReadManyAsync(queryOptions, null);
            Guid? ledgerCoaUuid = null;

            if (result == null || !result.Items.Any())
            {
                result = new QueryResults<GlTransaction>(new List<GlTransaction>(), null, null, 0);
            }
            else
            {
                foreach (var item in result.Items)
                {
                    index = 0;
                    if (item.GlAccounts == null)
                        item.GlAccounts = new List<GlAccount>();
                    if (item.Batches == null)
                        item.Batches = new List<Batch>();

                    if (item.LedgerProjectId != null && item.LedgerProjectId > 0)
                    {
                        var ledgerProject = LedgerProjectService.GetAsync((long)item.LedgerProjectId, null).Result;
                        item.ProjectUuid = ledgerProject?.ProjectUuid;
                    }
                    if (item.LedgerCompanyId != null && item.LedgerCompanyId > 0)
                    {
                        var ledgerCompany = LedgerCompanyService.GetAsync((long)item.LedgerCompanyId, null).Result;
                        item.CompanyUuid = ledgerCompany?.CompanyUuid;
                    }
                    if (item.GlTransactionId > 0)
                    {
                        // Get batch detail for particular transaction id
                        if (item.BatchId != null && item.BatchId > 0)
                        {
                            Batch batch = BatchService.GetAsync((long)item.BatchId, null).Result;
                            if (batch != null)
                            {
                                item.Batches.Insert(index, batch);
                            }
                        }

                        item.PaymentInfo = (await PaymentInfoService.GetManyAsync(new QueryOptions { Filter = "gl_transaction_id eq " + item.GlTransactionId }))?.Items?.FirstOrDefault();

                        // Get transaction detail for particular transaction id
                        QueryResults<GlTransactionDetail> transactions = GlTransactionDetailService.GetManyAsync(
                                                                                  new QueryOptions
                                                                                  {
                                                                                      Filter = "gl_transaction_id eq " + item.GlTransactionId
                                                                                  }, transaction).Result;

                        if (transactions != null && transactions.Items != null)
                        {
                            foreach (var row in transactions?.Items)
                            {
                                // Get account detail for particular transaction id
                                glAccount = GlAccountService.GetAsync((long)row.GlAccountId, null).Result;
                                if (glAccount != null)
                                {
                                    if (glAccount.LedgerCoaId != null && glAccount.LedgerCoaId > 0)
                                    {
                                        var ledgerCoa = LedgerCoaService.GetAsync((long)glAccount.LedgerCoaId, null).Result;
                                        if (ledgerCoa != null)
                                        {
                                            glAccount.CoaUuid = ledgerCoaUuid = ledgerCoa.CoaUuid;
                                        }
                                    }
                                    if (glAccount.LedgerProjectId != null && glAccount.LedgerProjectId > 0)
                                    {
                                        var ledgerProject = await LedgerProjectService.GetAsync((long)glAccount.LedgerProjectId, transaction);
                                        if (ledgerProject != null)
                                        {
                                            glAccount.ProjectUuid = ledgerProject.ProjectUuid;
                                        }
                                    }

                                    if (row.CaTaxCreditId.HasValue && row.CaTaxCreditId > 0)
                                    {
                                        row.TaxCredit = (await CaTaxCreditService.GetAsync((long)row.CaTaxCreditId))?.TaxCredit;
                                    }

                                    if (glAccount.GlTransactionDetails == null)
                                        glAccount.GlTransactionDetails = new List<GlTransactionDetail>();

                                    glAccount.GlTransactionDetails.Add(row);

                                    item.GlAccounts.Insert(index, glAccount);
                                    index += 1;
                                }
                            }
                        }
                        item.VarianceAmount = transactions?.Items.Sum(litem => litem.Amount);
                    }
                }
            }
            return result;
        }
        #endregion
    }
}
