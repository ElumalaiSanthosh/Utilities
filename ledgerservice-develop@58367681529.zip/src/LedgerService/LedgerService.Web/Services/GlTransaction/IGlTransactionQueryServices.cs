using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial interface IGlTransactionService
    {
        #region QueryService

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<QueryResults<GlTransaction>> GetUnPostedJournals(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<QueryResults<GlTransaction>> GetTransactions(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="subSystem"></param>
        /// <returns></returns>
        Task<int> GetUnpostedGlCount(Guid companyExternalId, string subSystem = "JE");

        /// <summary>
        /// /
        /// </summary>
        /// <param name="companyExternalId"></param>
        /// <param name="options"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<QueryResults<GlTransaction>> GetGlTransactions(Guid companyExternalId, QueryOptions options, IDbTransaction transaction = null);
        #endregion QueryService
    }
}
