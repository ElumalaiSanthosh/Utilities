using System;
using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;
using ApiService.Services;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface ILedgerBankService : IService<LedgerBank>
    {
        #region QueryService
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bankUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<long> GetIdByBankUuid(Guid bankUuid, IDbTransaction transaction = null);
        #endregion QueryService
    }
}
