﻿using ApiService.Commons.Rest;
using Microsoft.Extensions.Logging;
using System;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{
    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerBankService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="bankUuid"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<long> GetIdByBankUuid(Guid bankUuid, IDbTransaction transaction = null)
        {
            if (bankUuid == null || bankUuid == Guid.Empty)
            {
                throw new ArgumentException("Invalid Parameter (bankUuid).");
            }

            long bankId = 0;

            string cacheKey = $"{Startup.BaseCacheKey}.ledgerbanks.bankUuid-{ bankUuid }";

            string cacheValue = Cache.GetString(cacheKey);

            if (cacheValue != null)
            {
                //Log.LogTrace($"LedgerBankService.GetIdByBankUuid: Got Id from Cache {bankUuid}");
                long.TryParse(cacheValue, out bankId);
            }

            if (bankId > 0)
            {   
                return bankId;
            }

            bool handleTransaction = transaction == null;
            IDbTransaction trans = transaction ?? BeginTransaction();

            try
            {
                var bank = await GetByBankUuidAsync(bankUuid, trans);

                bool addBank = false;

                if (bank == null || bank.LedgerBankId < 1)
                {
                    bank = await PostAsync(new Models.Dtos.LedgerBank { BankUuid = bankUuid }, trans);

                    if (bank == null || bank.LedgerBankId < 1)
                    {
                        throw new ApiRestException(System.Net.HttpStatusCode.BadRequest, $"Could not find Ledger Bank with UUID ({bankUuid})");
                    }

                    addBank = true;
                }

                if (!addBank)
                {
                    Cache.SetString(cacheKey, bank.LedgerBankId.ToString());
                }

                CommitTransaction(handleTransaction, trans);
                return bank.LedgerBankId;
            }
            catch (Exception)
            {
                RollbackTransaction(handleTransaction, trans);
                throw;
            }
        }
    }
}
