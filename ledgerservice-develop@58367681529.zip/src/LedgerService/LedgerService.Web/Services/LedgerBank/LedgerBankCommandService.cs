using System.Data;
using LedgerService.Models.Dtos;
using ApiService.Services;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class LedgerBankService : Service<LedgerBank>, ILedgerBankService
    {
        #region CommandService
        partial void AfterPost(ref bool result, ref LedgerBank dto, ref IDbTransaction transaction, ref bool createRelatedRecords)
        {
            string cacheKey = $"{Startup.BaseCacheKey}.ledgerbanks.bankUuid-{ dto.BankUuid }";
            Cache.SetString(cacheKey, dto.LedgerBankId.ToString());
        }
        #endregion CommandService
    }
}
