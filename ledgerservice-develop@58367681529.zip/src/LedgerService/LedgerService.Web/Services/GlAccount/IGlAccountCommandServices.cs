using LedgerService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface IGlAccountService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="sameValueForAllRecords"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<List<GlAccount>> PatchManyAsync(List<GlAccount> dtos, bool sameValueForAllRecords = false, IDbTransaction transaction = null);

    }
}
