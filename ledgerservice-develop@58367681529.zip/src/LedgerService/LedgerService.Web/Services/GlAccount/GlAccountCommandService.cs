using ApiService.Commons.DataStore;
using ApiService.Commons.Rest;
using ApiService.Commons.Utility;
using LedgerService.Models.Dtos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class GlAccountService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="sameValueForAllRecords"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<List<GlAccount>> PatchManyAsync(List<GlAccount> dtos, bool sameValueForAllRecords = false, IDbTransaction transaction = null)
        {
            if (dtos == null || !dtos.Any())
                throw new ApiRestException(HttpStatusCode.BadRequest, "The Dto is null.");
            if (dtos?.Count > 0)
            {
                bool handleTransaction = transaction == null;
                IDbTransaction trans = transaction ?? BeginTransaction();
                try
                {
                    var results = new List<GlAccount>();
                    var validRecords = dtos.Where(w => w.GlAccountId > 0).ToList();
                    if (validRecords?.Count > 0)
                    {
                        if (sameValueForAllRecords)
                        {
                            string statement = PatchHelper.GetStatement("GlAccount", PatchHelper.GetTagValueDictionary(dtos.First()), $"gl_account_id in( {string.Join(",", dtos.Select(s => s.GlAccountId))})");
                            if (!string.IsNullOrEmpty(statement))
                            {
                                int updatedLines = await ExecuteAsync(statement, trans);
                                if (updatedLines > 0)
                                    results.AddRange(dtos);
                            }
                        }
                        else
                        {
                            foreach (var dto in dtos)
                            {
                                string statement = PatchHelper.GetStatement("GlAccount", PatchHelper.GetTagValueDictionary(dto), $"gl_account_id = {dto.GlAccountId}");
                                if (!string.IsNullOrEmpty(statement))
                                {
                                    int updatedLines = await ExecuteAsync(statement, trans);
                                    if (updatedLines > 0)
                                        results.Add(dto);
                                }
                            }
                        }
                    }
                    CommitTransaction(handleTransaction, trans);
                    if (results.Any())
                    {
                        string filter = $"gl_account_id in ({string.Join(",", results.Select(x => x.GlAccountId).Distinct())})";
                        var accounts = GetManyAsync(new QueryOptions { Filter = filter }).Result;

                        if (accounts.Items.Any())
                        {
                            accounts?.Items?.ForEach(account =>
                            {
                                string jsonStringify = JsonConvert.SerializeObject(account);
                                ProducerWrapper.PushEvent(jsonStringify, SourceSystemType.CA, ActionType.Update, account.GetType().Name);
                            });
                        }

                        return results;
                    }
                }
                catch (Exception)
                {
                    RollbackTransaction(handleTransaction, trans);
                    throw;
                }
            }
            return null;
        }
    }
}
