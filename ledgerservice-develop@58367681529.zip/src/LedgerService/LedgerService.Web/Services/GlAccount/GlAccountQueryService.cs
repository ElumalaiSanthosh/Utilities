using ApiService.Commons.DataStore;
using LedgerService.Models.Dtos;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial class GlAccountService
    {
        private ILedgerTaxFormService _ledgerTaxFormService;
        private ILedgerTaxFormService LedgerTaxFormService => _ledgerTaxFormService ?? (_ledgerTaxFormService = (ILedgerTaxFormService)ServiceProvider.GetService(typeof(ILedgerTaxFormService)));

        /// <summary>
        /// 
        /// </summary>
        /// <param name="glAccountId"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<GlAccount> GetAccountByAccountIdAsync(long glAccountId, IDbTransaction transaction = null)
        {
            return await ReadAsync(new QueryOptions { Filter = "gl_account_id eq " + glAccountId }, transaction);
        }

        partial void AfterGet(ref bool result, GlAccount dto, ref IDbTransaction transaction, ref bool shouldReturnRelatedRecords)
        {
            if (dto.LedgerTaxCodeId != null)
            {
                var ledgerTaxCode = LedgerTaxCodeService.GetAsync((long)dto.LedgerTaxCodeId).Result;
                if (ledgerTaxCode != null)
                {
                    dto.TaxCode = ledgerTaxCode.TaxCode;
                    var ledgerTaxForm = LedgerTaxFormService.GetAsync(ledgerTaxCode.LedgerTaxFormId).Result;
                    if (ledgerTaxForm != null)
                        dto.TaxFormName = ledgerTaxForm.Name;
                }
            }
        }

        partial void AfterGetMany(ref bool result, ref QueryResults<GlAccount> values, ref IDbTransaction transaction)
        {
            var taxCodeList = LedgerTaxCodeService.GetManyAsync(new QueryOptions()).Result;
            var taxFormList = LedgerTaxFormService.GetManyAsync(new QueryOptions()).Result;
            foreach (var item in values.Items)
            {
                if (item.LedgerTaxCodeId != null)
                {
                    var ledgerTaxCode = taxCodeList.Items.FirstOrDefault(x => x.LedgerTaxCodeId == (long)item.LedgerTaxCodeId);
                    if (ledgerTaxCode != null)
                    {
                        item.TaxCode = ledgerTaxCode.TaxCode;
                        var ledgerTaxForm = taxFormList.Items.FirstOrDefault(x => x.LedgerTaxFormId == ledgerTaxCode.LedgerTaxFormId);
                        if (ledgerTaxForm != null)
                            item.TaxFormName = ledgerTaxForm.Name;
                    }
                }
            }
        }
    }
}
