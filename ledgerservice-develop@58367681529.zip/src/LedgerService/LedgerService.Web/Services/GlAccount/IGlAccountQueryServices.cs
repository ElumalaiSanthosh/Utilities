using System.Data;
using System.Threading.Tasks;
using LedgerService.Models.Dtos;

namespace LedgerService.Web.Services
{

    /// <summary>
    /// 
    /// </summary>
    public partial interface IGlAccountService
    {
        #region QueryService
        /// <summary>
        /// Get Method
        /// </summary>
        /// <param name="glAccountId"></param>
        /// <param name="transaction"></param>
        Task<GlAccount> GetAccountByAccountIdAsync(long glAccountId, IDbTransaction transaction = null);


        #endregion QueryService
    }
}
