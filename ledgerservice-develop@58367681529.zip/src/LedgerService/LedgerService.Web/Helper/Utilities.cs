﻿using ApiService.Commons.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading.Tasks;

namespace LedgerService.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class Utilities
    {
        /// <summary>
        /// Parse String to Enum
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static TEnum ToEnum<TEnum>(this string value) where TEnum : struct
        {
            TEnum result = default(TEnum);
            return Enum.TryParse(value, true, out result) ? result : default(TEnum);
        }

        /// <summary>
        /// Returns enum value by description
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="description"></param>
        /// <returns></returns>
        public static T GetEnumFromDescription<T>(string description)
        {
            if (!string.IsNullOrWhiteSpace(description))
            {
                var type = typeof(T);
                if (!type.IsEnum)
                    throw new InvalidOperationException();
                foreach (var field in type.GetFields())
                {
                    if (Attribute.GetCustomAttribute(field,
                        typeof(DescriptionAttribute)) is DescriptionAttribute attribute)
                    {
                        if (attribute.Description.ToLower() == description.ToLower())
                            return (T)field.GetValue(null);
                    }
                    else
                    {
                        if (field.Name.ToLower() == description.ToLower())
                            return (T)field.GetValue(null);
                    }
                }
            }
            return default(T);
        }

        /// <summary>
        /// Returns description value by enum
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetDescription<T>(this T value)
        {
            var fieldInfo = value.GetType().GetField(value.ToString());

            var descriptionAttributes = fieldInfo.GetCustomAttributes(
                typeof(DescriptionAttribute), false) as DescriptionAttribute[];

            if (descriptionAttributes == null) return string.Empty;
            return (descriptionAttributes.Length > 0) ? descriptionAttributes[0].Description : value.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToDbCompatibleString(this string value)
        {
            return value?.Replace("'", "''");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public static async Task ForEachAsync<T>(this IEnumerable<T> list, Func<T, Task> action)
        {
            foreach (var item in list)
            {
                await action(item);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchKey"></param>
        /// <param name="columnName"></param>
        /// <returns></returns>
        public static string GetAutofillOrderbyQuery(string searchKey, string columnName)
        {
            if (!string.IsNullOrWhiteSpace(columnName))
            {
                return $"position({searchKey.SqlQuoteString()} in lower({columnName})),alphanumeric_sort({columnName})";
            }
            return string.Empty;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="escapeStr"></param>
        /// <returns></returns>
       public static bool EscapeSpecialCharecters(ref string query, out string escapeStr)
        {
            bool result = false;
            escapeStr = null;
            if (!string.IsNullOrEmpty(query))
            {
                //escape % sign
                if (query.Contains('%'))
                {
                    query = query.Replace(@"\", @"\\").Replace("%", @"\%");
                    escapeStr = @"escape '\'";
                    result = true;
                }
            }
            return result;
        }
    }
}
