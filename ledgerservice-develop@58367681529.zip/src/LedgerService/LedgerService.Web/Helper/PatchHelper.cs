﻿using LedgerService.Models.Dtos;
using LedgerService.Models.Enumerations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace LedgerService.Web
{
    /// <summary>
    /// 
    /// </summary>
    public static class PatchHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="tagValuePairs"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public static string GetStatement(string entityName, Dictionary<string, object> tagValuePairs, string filter)
        {
            if (tagValuePairs?.Count > 0 && !string.IsNullOrEmpty(entityName) && !string.IsNullOrEmpty(filter))
            {
                var tags = tagValuePairs.Keys.ToArray();
                var doc = XDocument.Load(Path.Combine(Startup.ApplicationRootDirectory, "PatchOperation.xml"));
                var columns = from entity in doc.Descendants("Entity")
                              where entity.Attribute("Name").Value == entityName
                              from column in entity.Descendants("Property")
                              where tags.Contains(column.Attribute("Tag").Value)
                              select new
                              {
                                  tableName = entity.Attribute("Table").Value,
                                  schemaName = entity.Attribute("Schema").Value,
                                  columnName = column.Attribute("DbName").Value,
                                  tag = column.Attribute("Tag").Value
                              };
                if (columns?.Count() > 0)
                {
                    var sb = new StringBuilder();
                    var first = columns.FirstOrDefault();
                    sb.Append($"update {first.schemaName}.{columns.FirstOrDefault().tableName} set ");
                    var assignments = new string[columns.Count()];
                    for (int i = 0; i < columns.Count(); i++)
                    {
                        assignments[i] = $"{columns.ElementAt(i).columnName}={tagValuePairs[columns.ElementAt(i).tag].ToSqlCompatibleValue()}";
                    }
                    sb.Append(string.Join(',', assignments));
                    sb.Append($" where {filter}");
                    return sb.ToString();
                }
            }
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public static Dictionary<string, object> GetTagValueDictionary(object dto)
        {
            Dictionary<string, object> tagValueDictionary = null;
            if (dto is GlAccount && !string.IsNullOrEmpty((dto as GlAccount).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                var tags = (dto as GlAccount).Tags.Split(',');
                foreach (var tag in tags)
                {
                    var enumTag = tag.ToEnum<GlAccountPatchTag>();
                    if (enumTag != GlAccountPatchTag.None)
                        tagValueDictionary.Add(tag, (dto as GlAccount).GetValueFromTag(enumTag));
                }
            }
            if (dto is PurchaseOrderAccount && !string.IsNullOrEmpty((dto as PurchaseOrderAccount).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                var tags = (dto as PurchaseOrderAccount).Tags.Split(',');
                foreach (var tag in tags)
                {
                    var enumTag = tag.ToEnum<PurchaseOrderAccountPatchTag>();
                    if (enumTag != PurchaseOrderAccountPatchTag.None)
                        tagValueDictionary.Add(tag, (dto as PurchaseOrderAccount).GetValueFromTag(enumTag));
                }
            }
            return tagValueDictionary;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Value"></param>
        /// <returns></returns>
        private static string ToSqlCompatibleValue(this object Value)
        {
            if (Value == null)
                return "null";
            else
            {
                switch (Convert.GetTypeCode(Value.GetType()))
                {
                    case TypeCode.Boolean:
                    case TypeCode.Decimal:
                    case TypeCode.Double:
                    case TypeCode.Int16:
                    case TypeCode.Int32:
                    case TypeCode.Int64:
                        return Value.ToString();
                    default:
                        return $"'{Value.ToString()}'";
                }
            }
        }
    }
}
