using System;
using System.Collections.Generic;
using ApiService.Commons.DBAttributes;
using ApiService.Commons.Models.Dtos;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class GlTransaction : DtoBase<GlTransaction>
    {
        public GlTransaction(long glTransactionId, Guid? externalId, long? ledgerCompanyId, long? ledgerProjectId, long? batchId, string subsystemType, string glTransactionType, string transactionNumber, DateTime entryDate, string documentNumber, DateTime documentDate, string description, DateTime? postDate, string postState, DateTime? reversalDate, long? referenceGlTransactionId, string recurrenceType, DateTime? recurrenceStartDate, DateTime? recurrenceEndDate, bool thirteenthPeriod, List<Batch> batch) : this()
        {
            Batches = batch;
        }

        [ForeignTable("Batch", typeof(Batch), "BatchId")]
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        [XmlArray("Batches")]
        [XmlArrayItem("Batch"), XmlArrayItem("BatchDto", Type = typeof(Batch))]

        public List<Batch> Batches { get; set; }

        [Display(Name = "VarianceAmount:")]
        [DataMember(Name = "variance_amount")]
        [JsonProperty(PropertyName = "variance_amount", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public double? VarianceAmount { get; set; }

        [Display(Name = "VoidDate:")]
        [DataMember(Name = "void_date")]
        [JsonProperty(PropertyName = "void_date", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public DateTime? VoidDate { get; set; }
    }
}
