/*
Created by ProjectBuilder Version: 1.0.4.42
On: 9/12/2019 2:34:35 PM
*/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using ApiService.Commons.DBAttributes;
using ApiService.Commons.Models.Dtos;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{


    public partial class GlTransactionDetail
    {

               public GlAccount glAccount;
        [Display(Name = "LedgerCoaId:")]
        [DataMember(Name = "ledger_coa_id")]
        [JsonProperty(PropertyName = "ledger_coa_id")]
        [XmlElement(IsNullable = false)]

        public long LedgerCoaId { get; set; }

        [Display(Name = "LedgerProjectId:")]
        [DataMember(Name = "ledger_project_id")]
        [JsonProperty(PropertyName = "ledger_project_id")]
        [XmlElement(IsNullable = false)]

        public long LedgerProjectId { get; set; }

        [Display(Name = "CompanyDivisionIdCode:")]
        [DataMember(Name = "company_division_id_code")]
        [JsonProperty(PropertyName = "company_division_id_code", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string CompanyDivisionIdCode { get; set; }

        [Display(Name = "CompanySubaccountIdCode:")]
        [DataMember(Name = "company_subaccount_id_code")]
        [JsonProperty(PropertyName = "company_subaccount_id_code", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string CompanySubaccountIdCode { get; set; }

        [Display(Name = "DetailIdCode:")]
        [DataMember(Name = "detail_id_code")]
        [JsonProperty(PropertyName = "detail_id_code", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string DetailIdCode { get; set; }

        [Display(Name = "MemoFreeField1:")]
        [DataMember(Name = "memo_freefield1")]
        [JsonProperty(PropertyName = "memo_freefield1", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string MemoFreeField1 { get; set; }

        [Display(Name = "MemoFreeField2:")]
        [DataMember(Name = "memo_freefield2")]
        [JsonProperty(PropertyName = "memo_freefield2", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string MemoFreeField2 { get; set; }


    }
}
