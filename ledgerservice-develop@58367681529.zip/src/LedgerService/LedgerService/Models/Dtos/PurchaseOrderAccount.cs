﻿using LedgerService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PurchaseOrderAccount
    {
        [DataMember(Name = "coa_uuid")]
        public Guid? CoaUuid { get; set; }

        [DataMember(Name = "project_uuid")]
        public Guid? ProjectUuid { get; set; }

        [DataMember(Name = "tax_code")]
        public string TaxCode { get; set; }

        [DataMember(Name = "tax_form_name")]
        public string TaxFormName { get; set; }

        [DataMember(Name = "tags", EmitDefaultValue = false)]
        [JsonProperty("tags", NullValueHandling = NullValueHandling.Ignore)]
        public string Tags { get; set; }

        public object GetValueFromTag(PurchaseOrderAccountPatchTag tag)
        {
            switch (tag)
            {
                case PurchaseOrderAccountPatchTag.DetailIdCode:
                    return DetailIdCode;
                case PurchaseOrderAccountPatchTag.CompanyDivisionIdCode:
                    return CompanyDivisionIdCode;
                case PurchaseOrderAccountPatchTag.CompanySubaccountIdCode:
                    return CompanySubaccountIdCode;
                default:
                    return null;
            }
        }
    }
}
