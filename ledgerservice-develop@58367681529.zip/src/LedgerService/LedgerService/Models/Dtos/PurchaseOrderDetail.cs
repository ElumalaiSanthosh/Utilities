﻿using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PurchaseOrderDetail
    {
        [DataMember(Name = "tax_credit")]
        public string TaxCredit { get; set; }
    }
}
