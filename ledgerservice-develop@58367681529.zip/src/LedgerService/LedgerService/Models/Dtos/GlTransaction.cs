﻿using ApiService.Commons.DBAttributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace LedgerService.Models.Dtos
{
    public partial class GlTransaction
    {

        [DataMember(Name = "company_uuid")]
        public Guid? CompanyUuid { get; set; }

        [DataMember(Name = "project_uuid")]
        public Guid? ProjectUuid { get; set; }

        [DataMember(Name = "gl_accounts")]
        public List<GlAccount> GlAccounts { get; set; }

        [DataMember(Name = "user_display_name")]
        public string UserDisplayName { get; set; }

        [DataMember(Name = "previous_post_state")]
        [JsonProperty(PropertyName = "previous_post_state")]
        public string PreviousPostState { get; set; }

        [IgnoreDataMember()]
        public bool SkipUpdateAccountDetails { get; set; } = false;

        [DataMember(Name = "tags")]
        public string Tags { get; set; }

        //use for - AP transaction
        [ForeignTable("PaymentInfo", typeof(PaymentInfo), "PaymentInfoId")]
        [DataMember(Name = "payment_info")]
        [JsonProperty(PropertyName = "payment_info")]
        public PaymentInfo PaymentInfo { get; set; }
    }
}
