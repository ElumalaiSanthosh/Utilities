﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PurchaseOrder
    {
        [DataMember(Name = "company_uuid")]
        public Guid? CompanyUuid { get; set; }

        [DataMember(Name = "vendor_uuid")]
        public Guid? VendorUuid { get; set; }

        [DataMember(Name = "purchase_order_accounts")]
        public List<PurchaseOrderAccount> PurchaseOrderAccounts { get; set; }
    }
}
