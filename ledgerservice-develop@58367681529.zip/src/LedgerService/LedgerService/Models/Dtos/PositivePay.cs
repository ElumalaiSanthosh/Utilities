using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PositivePay
    {
        [Display(Name = "BankUuid:")]
        [DataMember(Name = "bank_uuid", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "bank_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? BankUuid { get; set; }
    }
}
