﻿using Newtonsoft.Json;
using System;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class GlTransactionDetail
    {
        [DataMember(Name = "tax_credit")]
        public string TaxCredit { get; set; }


        [DataMember(Name = "vendor_uuid", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "vendor_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? VendorUuid { get; set; }
    }
}
