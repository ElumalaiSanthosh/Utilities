using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Runtime.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PositivePayPayment 
    {
        [Display(Name = "BankUuid:")]
        [DataMember(Name = "bank_uuid", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "bank_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? BankUuid { get; set; }

        [Display(Name = "PaymentType:")]        
        [DataMember(Name = "payment_type")]
        [StringLength(50, MinimumLength = 1, ErrorMessage = "PaymentType cannot be longer than 50 characters.")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "PaymentType cannot be blank.")]
        [JsonProperty(PropertyName = "payment_type")]
        [XmlElement(IsNullable = false)]

        public string PaymentType { get; set; }

        [Display(Name = "PaymentNumber:")]       
        [DataMember(Name = "payment_number")]
        [StringLength(50, ErrorMessage = "PaymentNumber cannot be longer than 50 characters.")]
        [JsonProperty(PropertyName = "payment_number", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public string PaymentNumber { get; set; }
    }
}
