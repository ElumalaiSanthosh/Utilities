﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class Payment
    {
        [Display(Name = "BankUuid:")]
        [DataMember(Name = "bank_uuid",EmitDefaultValue =false)]
        [JsonProperty(PropertyName = "bank_uuid",NullValueHandling =NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? BankUuid { get; set; }

        //[Display(Name = "VendorUuid:")]        
        //[DataMember(Name = "vendor_uuid")]
        //[Required]
        //[JsonProperty(PropertyName = "vendor_uuid")]
        //[XmlElement(IsNullable = false)]

        //public Guid? VendorUuid { get; set; }

        [Display(Name = "LedgerUserCreatedUuid:")]
        [DataMember(Name = "ledger_user_created_uuid")]
        [JsonProperty(PropertyName = "ledger_user_created_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public Guid? LedgerUserCreatedUuid { get; set; }

        [Display(Name = "LedgerUserLastModifiedUuid:")]
        [DataMember(Name = "ledger_user_last_modified_uuid")]
        [JsonProperty(PropertyName = "ledger_user_last_modified_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]

        public Guid? LedgerUserLastModifiedUuid { get; set; }
    }
}
