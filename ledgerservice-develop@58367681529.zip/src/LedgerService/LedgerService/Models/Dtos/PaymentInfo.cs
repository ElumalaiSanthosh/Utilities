﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace LedgerService.Models.Dtos
{
    public partial class PaymentInfo
    {
        [DataMember(Name = "payments")]
        [JsonProperty(PropertyName = "payments")]
        [XmlElement(IsNullable = true)]
        public List<Payment> Payments { get; set; }

        [DataMember(Name = "ledger_bank_uuid", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "ledger_bank_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? LedgerBankUuid { get; set; }

        [DataMember(Name = "sending_bank_uuid", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "sending_bank_uuid", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement(IsNullable = true)]
        public Guid? SendingBankUuid { get; set; }

        [DataMember(Name = "gl_transaction_payment")]
        [JsonProperty(PropertyName = "gl_transaction_payment")]
        [XmlElement(IsNullable = true)]
        public List<GlTransactionPayment> GlTransactionPayment { get; set; }
    }
}
