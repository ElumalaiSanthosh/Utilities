﻿using System.ComponentModel;

namespace LedgerService.Models.Enumerations
{
    public enum SubsystemType
    {
        None,
        [Description("Jouranal Entry")]
        JE,
        [Description("Accounts Payable")]
        AP,
        [Description("Accounts Receivable")]
        AR,
        [Description("Post Payments")]
        PP,
        [Description("Deposit Entry")]
        DE,
        [Description("Petty Cash")]
        PC,
        [Description("Credit Card")]
        CC
    }

    public enum TransactionType
    {
        None,
        [Description("STANDARD")]
        STANDARD,
        [Description("REVERSING")]
        REVERSING,
        [Description("RECURRING")]
        RECURRING,
        [Description("PAY NOW")]
        PAYNOW,
        [Description("PAYROLL")]
        PAYROLL,
        [Description("PAYMENTS")]
        PAYMENTS,
        ICT
    }

    public enum RecurringType
    {
        None = 0,
        Daily,
        Weekly,
        [Description("1")]
        Monthly,
        [Description("3")]
        Quarterly,
        [Description("12")]
        Yearly
    }

    public enum PostState
    {
        UNPOSTED,
        POSTED,
        VOIDED,
        REVERSED,
        UNPAID,
        PAID,
        [Description("PARTIALLY PAID")]
        PARTIALLYPAID
    }

    public enum GlTransactionPatchTag
    {
        None = 0,
        PostState = 1,
        PostDate = 2,
        DocumentDate = 3,
        Description = 4,
        ReferenceGlTransactionId = 5
    }
    public enum GlAccountPatchTag
    {
        None,
        DetailIdCode,
        CompanyDivisionIdCode,
        CompanySubaccountIdCode,
    }

    public enum PurchaseOrderAccountPatchTag
    {
        None,
        DetailIdCode,
        CompanyDivisionIdCode,
        CompanySubaccountIdCode,
    }
}
