## Prerequisite:

* Windows 7/10
* Visual Studio 2017
* .Net Core SDK : Download and install from    
  1. https://www.microsoft.com/net/learn/get-started/windows#windowscmd

## Database
If you want to use your local database then Execute Database script "/db/company.sql" :
   * Create database from commented section in the file.
   * Connect to the newly created database and execte the "company.sql". It will create required tables and sps
   * Update connection string with your database connections.

## Run application using below steps:

## Access Apis

## Run Unit Tests


