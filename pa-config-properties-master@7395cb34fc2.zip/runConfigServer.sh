#!/bin/bash

if [ "$1" = "" ]
then
  echo "Usage: $0 <path/to/properties/repo>"
  exit
fi

docker run --rm -it --name=config-server -p 8888:8888 \
    -v $1:/properties \
    hyness/spring-cloud-config-server \
    --spring.cloud.config.server.git.searchPaths={application} \
    --spring.cloud.config.server.git.uri=file:/properties
