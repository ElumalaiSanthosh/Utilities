Production Account Configuration Properties Repo
=========================

Configuration repository for [Spring Cloud Config Servers](https://cloud.spring.io/spring-cloud-config/multi/multi__spring_cloud_config_server.html)


Repository Layout
-----------

Property files should be organized in the following layout:
~~~~
.
+-- <application 1 name>
|   +-- application.properties
|   +-- application-dev.properties
|   +-- application-qa.properties
+-- <application 2 name>
    +-- application.yml
    +-- application-dev.yml
    +-- application-qa.yml
~~~~

Files should be organized in folders matching the application name. Property files can be in .yml or .properties format. See [Spring Configuration](https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html) for more details. All file and folder names are case-sensitive.


Running locally
-----------

The config server instances are typically Java Spring Boot instances that connect to git repositories (either directly or clones of the repository). Pre-exising Docker images for the config server are available to make running locally easy.

The docker image needs the following pieces configured to properly serve configuration data:
- Docker image name ([hyness/spring-cloud-config-server](https://hub.docker.com/r/hyness/spring-cloud-config-server/))
- Server port (default 8888:8888)
- URI for git repository
- Search path configuration to map application name to subdirectories in the repo

A sample bash script is provided in runConfigServer.sh:
1) Clone configuration repository (e.g., this repo)
2) Invoke shell script:
`./runConfigServer.sh <path to repo>`

See image page for more configuration options.
