﻿using Microsoft.VisualStudio.TemplateWizard;
using System.Collections.Generic;
using EnvDTE;

namespace Wizard
{
    public class DeployWizardImplementation : IWizard
    {
        public void RunStarted(object automationObject, Dictionary<string, string> replacementsDictionary, WizardRunKind runKind,
            object[] customParams)
        {
            replacementsDictionary.Add("$safeprojectnamelower$", replacementsDictionary["$ext_safeprojectname$"].ToLower());
        }

        public void ProjectFinishedGenerating(Project project)
        {
            
        }

        public void ProjectItemFinishedGenerating(ProjectItem projectItem)
        {
           
        }

        public bool ShouldAddProjectItem(string filePath)
        {
            return true;
        }

        public void BeforeOpeningFile(ProjectItem projectItem)
        {
           
        }

        public void RunFinished()
        {
           
        }
    }
}
