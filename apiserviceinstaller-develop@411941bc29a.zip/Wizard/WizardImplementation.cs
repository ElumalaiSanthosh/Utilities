﻿using EnvDTE;
using Microsoft.VisualStudio.TemplateWizard;
using System;
using System.IO;
using System.Collections.Generic;
using System.Reflection;
using EnvDTE100;

namespace Wizard
{
    public class WizardImplementation : IWizard
    { 
        private const string RES = "Resources";
        private const string ROOT = "Root";
        private const string DBMAP = "Mapping";
        private const string CONFIG = "Config";

        private const string REPLACE_DESTDIR = "$destinationdirectory$";
        private const string REPLACE_PROJNAME = "$safeprojectname$";
        private const string REPLACE_PROJNAME_LOWER = "$safeprojectnamelower$";

        private const string STRFRMT_WEBPROJ = "{0}.Web";

        private EnvDTE.DTE _dte;
        private string _destPath, _chosenName;
        
        // This method is called before opening any item that   
        // has the OpenInEditor attribute.  
        public void BeforeOpeningFile(ProjectItem projectItem)
        {
        }

        public void ProjectFinishedGenerating(Project project)
        {
            var sol = _dte.Solution as Solution4;
            //get path to VSIX embedded resources
            var resPath = Path.Combine(Directory.GetParent(Assembly.GetExecutingAssembly().Location).Parent.FullName, RES);

            //create top-level solution folders, and populate with appropriate resource items
            CreateAndPopulateSlnFolder(sol, resPath, DBMAP);
            CreateAndPopulateSlnFolder(sol, resPath, CONFIG);
            //set startup project
            sol.Properties.Item("StartupProject").Value = String.Format(STRFRMT_WEBPROJ, _chosenName);
        }

        private Project createSlnFolder(Solution4 solution, string subdir)
        {
            //add solution folder
            Project folder = solution.AddSolutionFolder(subdir);         

            return folder;
        }

        private void CreateAndPopulateSlnFolder(Solution4 solution, string resourcePath, string subdir)
        {
            Project folder = createSlnFolder(solution, subdir);

            //create resource sub-directory
            var newResDir = Path.Combine(_destPath, subdir);
            Directory.CreateDirectory(newResDir);

            //iterate through files in sub-resource directory
            foreach (string file in Directory.GetFiles(Path.Combine(resourcePath, subdir)))
            {
                //copy file to new resource directory
                var dest = Path.Combine(newResDir, Path.GetFileName(file));
                File.Copy(file, dest);

                ReplaceData(dest);
                
                //add file to project
                folder.ProjectItems.AddFromFile(dest);

                //NOTE: VisualStudio automatically opens these files after adding. So we have to 
                //      force close them using a VS alias.
                _dte.ExecuteCommand("File.Close");
            }
        }

        private void ReplaceData(string file)
        {
            string text = File.ReadAllText(file);
            text = text.Replace(REPLACE_PROJNAME, _chosenName);
            text = text.Replace(REPLACE_PROJNAME_LOWER, _chosenName.ToLower());
            File.WriteAllText(file, text);
        }

        // This method is only called for item templates,  
        // not for project templates.  
        public void ProjectItemFinishedGenerating(ProjectItem projectItem)
        {
        }

        // This method is called after the project is created.  
        public void RunFinished()
        {
        }
        
        private void CopyToFolder(string resourcePath, string subdir, string targetPath)
        {
            if (string.IsNullOrEmpty(targetPath))
            {
                targetPath = _destPath;
            }
            
            //iterate through files in sub-resource directory
            foreach (string file in Directory.GetFiles(Path.Combine(resourcePath, subdir)))
            {
                //copy file to new resource directory
                var dest = Path.Combine(targetPath, Path.GetFileName(file));
                File.Copy(file, dest);
                ReplaceData(dest);
            }
        }

        public void RunStarted(object automationObject,
            Dictionary<string, string> replacementsDictionary,
            WizardRunKind runKind, object[] customParams)
        {
            //save global DTE object
            _dte = automationObject as DTE;
            //path where the project will finally end up
            _destPath = replacementsDictionary[REPLACE_DESTDIR];
            //the project name chosen by the user
            _chosenName = replacementsDictionary[REPLACE_PROJNAME];
                      
            //get path to VSIX embedded resources
            var resPath = Path.Combine(Directory.GetParent(Assembly.GetExecutingAssembly().Location).Parent.FullName, RES);
            
            //create top-level solution folders, and populate with appropriate root items
            CopyToFolder(resPath, ROOT, Path.Combine(_destPath, ".."));
        }

        // This method is only called for item templates,  
        // not for project templates.  
        public bool ShouldAddProjectItem(string filePath)
        {
            return true;
        }
    }
}
