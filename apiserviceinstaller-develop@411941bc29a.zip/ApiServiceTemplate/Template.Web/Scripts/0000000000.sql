/*
--create database
CREATE DATABASE "pa-$safeprojectnamelower$"
    WITH
    OWNER = pa_admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    CONNECTION LIMIT = -1;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

GRANT ALL ON DATABASE "pa-$safeprojectnamelower$" TO pa_admin;


--create schema
CREATE SCHEMA $safeprojectnamelower$ AUTHORIZATION pa_admin;

GRANT ALL ON SCHEMA $safeprojectnamelower$ TO pa_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA $safeprojectnamelower$ TO pa_write WITH GRANT OPTION;
GRANT USAGE ON SCHEMA $safeprojectnamelower$ TO pa_read;

ALTER DEFAULT PRIVILEGES IN SCHEMA $safeprojectnamelower$
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO pa_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA $safeprojectnamelower$
GRANT SELECT, USAGE ON SEQUENCES TO pa_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA $safeprojectnamelower$
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO pa_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA $safeprojectnamelower$
GRANT SELECT, USAGE ON SEQUENCES TO pa_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA $safeprojectnamelower$ GRANT SELECT ON TABLES TO pa_read;

SET search_path=$safeprojectnamelower$,public;

CREATE TABLE db_properties
(
    db_properties_id SERIAL PRIMARY KEY,
    last_update timestamp,
    host_name character varying(255),
    script character varying(255)
);
*/

select * from db_properties;
