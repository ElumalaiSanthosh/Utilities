﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using ApiService.DataStore;
using ApiService.Extensions;
using ApiService.Middleware;
using ApiService.Commons.Logger;
using Microsoft.AspNet.OData.Extensions;
using Microsoft.AspNet.OData.Formatter;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.SwaggerGen;
using $safeprojectname$.Extensions;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using ApiService.Configuration;
using ApiService.Util;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data.Common;
using System.Runtime.Versioning;
using ApiService.Commons.CacheService;
using Microsoft.OpenApi.Models;
using $safeprojectname$.Web.Services;
using Microsoft.Extensions.Hosting;

using ApiService.Commons.Clients;
using ApiService.Commons.Events;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using ApiService.Commons.Configuration;
using Steeltoe.Common.HealthChecks;
using Steeltoe.Management.Endpoint.Health;



namespace $safeprojectname$
{
  /// <summary>
  /// 
  /// </summary>
  public class Startup
  {
	private DbUpdateConfig DbUpdateConfig { get; }

    /// <summary>
    /// 
    /// </summary>
    public static void RunAfterStartup(IServiceProvider serviceProvider)
    {
        using (var serviceScope = serviceProvider.CreateScope())
        {
            var services = serviceScope.ServiceProvider;
            var dataStoreProvider = services.GetRequiredService<IDataStoreProvider>();
            var config = services.GetRequiredService<IConfiguration>();
            DbUpdateUtil.Update(config, dataStoreProvider);
        }
    }

        /// <summary>
        /// 
        /// </summary>
        public static Dictionary<string, string> GetActuatorProperties(IConfiguration configuration)
        {
            string basePath = configuration["spring:application:name"];

            var assembly = typeof(Startup).Assembly;
            var actuatorProperties = new Dictionary<string, string>
            {
                { "management:endpoints:path", $"/{basePath}/actuator" },
                { "info:build:version", assembly.GetName().Version.ToString() },
                { "info:build:artifact", assembly.GetName().Name },
                { "info:runtime-version", assembly.GetCustomAttribute<TargetFrameworkAttribute>()?.FrameworkName },
                { "info:git:branch", ThisAssembly.Git.Branch },
                { "info:git:commit:id", ThisAssembly.Git.Commit }
            };
            return actuatorProperties;
        }

    /// <summary>
    /// 
    /// </summary>
    public static Dictionary<string, string> GetConnectionStrings(IConfiguration configuration)
    {
        var connectionStrings = new Dictionary<string, string>();

        AddConnectionString(configuration, "PostgresSql", connectionStrings);
        AddConnectionString(configuration, "SQLServer", connectionStrings);

        return connectionStrings;
    }

    private static void AddConnectionString(IConfiguration configuration, string connectionName,
        Dictionary<string, string> connectionStrings)
    {
        var rootKey = "ConnectionStrings:" + connectionName;
        DbConnectionStringBuilder builder = new DbConnectionStringBuilder
        {
            ConnectionString = configuration[rootKey]
        };

        foreach (var csProperty in configuration.GetSection(rootKey + "Properties").GetChildren())
        {
            builder[csProperty.Key] = csProperty.Value;
        }

        if (!String.IsNullOrEmpty(builder.ConnectionString))
        {
            connectionStrings.Add(rootKey, builder.ConnectionString);
        }

        if (connectionName.Equals(configuration["DbUpdateConfig:ConnectionStringName"]))
        {
            if (builder.ContainsKey("Host") && builder["Host"] != null)
            {
                connectionStrings.Add("DbUpdateConfig:ServerName", builder["Host"].ToString());
            }
            if (builder.ContainsKey("Database") && builder["Database"] != null)
            {
                connectionStrings.Add("DbUpdateConfig:DatabaseName", builder["Database"].ToString());
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="configuration"></param>
    [ExcludeFromCodeCoverage]
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
        if (Configuration.GetChildren().Any(x => x.Key == "DbUpdateConfig"))
        {
            DbUpdateConfig = new DbUpdateConfig(Configuration);
        }
    }

    /// <summary>
    /// 
    /// </summary>
    [ExcludeFromCodeCoverage]
	public IConfiguration Configuration { get; }


        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        [ExcludeFromCodeCoverage]
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<IISOptions>(options =>
            {
                options.ForwardClientCertificate = false;
            });

            services.AddSingleton(Configuration);
            //#region Redis
            services.AddSingleton<IApiCache, RedisService>();
            //#endregion Redis

            //this needs to be set by builder for the type of datastore you are using.
            if (DbUpdateConfig != null && DbUpdateConfig.ConnectionStringName == "SQLServer")
            {
                services.AddScoped(typeof(IDataStoreProvider), typeof(SqlServerDataStoreProvider));
            }
            else
            {
                services.AddScoped(typeof(IDataStoreProvider), typeof(PostgresDataStoreProvider));
            }
            services.RegisterGeneratedServices();
            services.RegisterApiServices();

            //Add health check for DB
            services.AddSingleton<IHealthContributor, DbHealthContributor>();
            services.AddHealthActuator(Configuration);

            services.AddOData();

            services.AddControllers().AddNewtonsoftJson(options =>
            {
                //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
                options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                options.SerializerSettings.DateTimeZoneHandling = Newtonsoft.Json.DateTimeZoneHandling.Utc;
                options.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
                options.SerializerSettings.TypeNameHandling = TypeNameHandling.None;
            });

            //This is for compression
            services.Configure<GzipCompressionProviderOptions>(options => options.Level = System.IO.Compression.CompressionLevel.Optimal);
            services.AddResponseCompression(options =>
            {
                options.MimeTypes = new[]
                {
			  // Default
			  "text/plain",
              "text/css",
              "application/javascript",
              "text/html",
              "application/xml",
              "text/xml",
              "application/json",
              "text/json",
			  // Custom
			  "image/svg+xml"
                };
            });

            //swagger
            services.AddMvcCore(options =>
            {
                foreach (var outputFormatter in options.OutputFormatters.OfType<ODataOutputFormatter>().Where(_ => _.SupportedMediaTypes.Count == 0))
                {
                    outputFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/prs.odatatestxx-odata"));
                }
                foreach (var inputFormatter in options.InputFormatters.OfType<ODataInputFormatter>().Where(_ => _.SupportedMediaTypes.Count == 0))
                {
                    inputFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/prs.odatatestxx-odata"));
                }
            });

            services.AddControllers(mvcOptions => mvcOptions.EnableEndpointRouting = false).AddNewtonsoftJson();

            string basePath = PlatformServices.Default.Application.ApplicationBasePath;
            string xmlPath = Path.Combine(basePath, "$safeprojectname$.xml");
	  
            string title = $"$safeprojectname$({Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion}) API";
            services.AddSwaggerGen(c =>
            {
            c.SwaggerDoc("v1",
                  new OpenApiInfo
                    {
                        Version = "v1",
                        Title = title,
                        //Description = "A sample API for testing Swashbuckle",
                        //TermsOfService = "Some terms ..."
                    }
                );
                c.IncludeXmlComments(xmlPath);
                c.OperationFilter<ODataOperationFilter>();
                c.EnableAnnotations();
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="loggerFactory"></param>
        [ExcludeFromCodeCoverage]
        public void Configure(IApplicationBuilder app, ILoggerFactory loggerFactory)
        {
            string basePath = Configuration["spring:application:name"];
            if (!string.IsNullOrEmpty(basePath))
            {
                app.UsePathBase("/" + basePath);
            }

            ApiLogging.LoggerFactory = loggerFactory;

            //these are for compression
            app.UseResponseCompression();
            app.UseMiddleware<GzipRequestMiddleware>();

            //Adding Model class to OData
            var builder = app.RegisterOdataEntities();
            app.UseMvc(routebuilder =>
            {
                routebuilder.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());
                routebuilder.EnableDependencyInjection();
            });

            app.UseRouting();

            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "$ext_safeprojectname$ V1");
                c.ShowExtensions();
            });
        }

        private class ODataOperationFilter : IOperationFilter
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="operation"></param>
            /// <param name="context"></param>
            [ExcludeFromCodeCoverage]
            public void Apply(OpenApiOperation operation, OperationFilterContext context)
            {
                if (context.ApiDescription.ParameterDescriptions.Select(p => p.ParameterDescriptor.ParameterType).All(t => t.BaseType != typeof(ODataQueryOptions)))
                {
                    return;
                }
                operation.RequestBody = null;

                //operation.Parameters = operation.Parameters.Where(p => !p.Required && p.In != "query" && p.Name != "Request.HttpContext.Request.Form").ToList();
                operation.Parameters = operation.Parameters.Where(p => p.Required || !string.IsNullOrEmpty(p.Description)).ToList();
                operation.Parameters.Insert(0, new OpenApiParameter { Name = "$skip", In = ParameterLocation.Query, Description = "Skips the first n results.", Schema = new OpenApiSchema { Type = "integer" }, Required = false });
                operation.Parameters.Insert(0, new OpenApiParameter { Name = "$top", In = ParameterLocation.Query, Description = "Returns only the first n results.", Schema = new OpenApiSchema { Type = "integer" }, Required = false });
                operation.Parameters.Insert(0, new OpenApiParameter { Name = "$orderby", In = ParameterLocation.Query, Description = "Sorts the results.", Schema = new OpenApiSchema { Type = "string" }, Required = false });
                operation.Parameters.Insert(0, new OpenApiParameter { Name = "$filter", In = ParameterLocation.Query, Description = "Filters the results, based on a Boolean condition.", Schema = new OpenApiSchema { Type = "string" }, Required = false });
            }
        }
		
        private class DbHealthContributor : IHealthContributor
        {
            public string Id => "db";

            private IDataStoreProvider DataStoreProvider { get; }
            private readonly ILogger _logger;
            private readonly String _validationQuery;

            public DbHealthContributor(IDataStoreProvider dataStoreProvider, IConfiguration config, ILogger<DbHealthContributor> logger)
            {
                DataStoreProvider = dataStoreProvider;
                _logger = logger;

                _validationQuery = config["DbUpdateConfig:ValidationQuery"];
                if (String.IsNullOrEmpty(_validationQuery))
                {
                    _validationQuery = "SELECT 1";
                }
            }

            public HealthCheckResult Health()
            {
                try
                {
                    var result = DataStoreProvider.ExecuteAsync(_validationQuery).Result;
                    return buildHealthCheckResult(HealthStatus.UP);
                }
                catch (Exception ex)
                {
                    _logger.LogError("Failed health check: {}", ex.Message);
                    return buildHealthCheckResult(HealthStatus.DOWN);
                }
            }

            private HealthCheckResult buildHealthCheckResult(HealthStatus status)
            {
                var result = new HealthCheckResult
                {
                    Status = status,
                    Description = "IDataStoreProvider health check",
                };
                result.Details.Add("status", status.ToString());
                result.Details.Add("type", DataStoreProvider.ToString());
                return result;
            }
        }
    }
}
