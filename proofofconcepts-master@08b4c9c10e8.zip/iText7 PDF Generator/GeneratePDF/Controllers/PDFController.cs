﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GeneratePDF.Models;
using GeneratePDF.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GeneratePDF.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class PDFController : ControllerBase
    {
        private readonly IPDFService _pdfService;

        public PDFController(IPDFService stampService)
        {
            _pdfService = stampService;
        }

        [HttpGet]
        [Produces(contentType: "application/pdf")]
        public FileStreamResult GetGeneratedPDF()
        {
            Stream outStream = _pdfService.Generate();
            outStream.Position = 0;
            return new FileStreamResult(outStream, "application/pdf");
        }
    }
}