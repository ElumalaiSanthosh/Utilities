﻿using GeneratePDF.Models;
using iText.Html2pdf;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GeneratePDF.Services
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPDFService
    {
        Stream Generate();
    }

    /// <summary>
    /// 
    /// </summary>
    public class PDFService : IPDFService
    {
        public PDFService()
        {
        }

        /// <summary>
        /// Generates this instance.
        /// </summary>
        /// <returns></returns>
        public Stream Generate()
        {
            FileStream fileStream = null;
            try
            {
                //HTML String
                string htmlString = "<h1>Shyam</h2>";
                //Setting destination 
                string fileName = Guid.NewGuid().ToString() + ".pdf";
                FileStream fileOutputStream = new FileStream(fileName, FileMode.OpenOrCreate);

                PdfWriter pdfWriter = new PdfWriter(fileOutputStream);
                ConverterProperties converterProperties = new ConverterProperties();
                PdfDocument pdfDocument = new PdfDocument(pdfWriter);

                //For setting the PAGE SIZE
                pdfDocument.SetDefaultPageSize(new PageSize(PageSize.A4));

                HtmlConverter.ConvertToPdf(htmlString, pdfDocument, converterProperties);
                fileStream = new System.IO.FileStream(fileName, System.IO.FileMode.OpenOrCreate);
            }
            catch (Exception e)
            {
                e.ToString();
            }
            return fileStream;
        }
    }
}
