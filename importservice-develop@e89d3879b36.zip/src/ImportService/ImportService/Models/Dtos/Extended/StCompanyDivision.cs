﻿using ImportService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace ImportService.Models.Dtos
{
    public partial class StCompanyDivision
    {
        [DataMember(Name = "tags")]
        [JsonProperty("tags")]
        public string Tags { get; set; }

        [DataMember(Name = "is_success")]
        [JsonProperty("is_success")]
        public bool IsSuccess { get; set; }

        [Display(Name = "Details:")]
        [Column("details", TypeName = "text")]
        [DataMember(Name = "details")]
        [JsonProperty(PropertyName = "details")]
        [XmlElement(IsNullable = true)]

        public string Details { get; set; }

        public object GetValueFromTag(StCompanyDivisionPatchTag tag)
        {
            switch (tag)
            {
                case StCompanyDivisionPatchTag.CompanyDivisionId:
                    return company_division_id;

                case StCompanyDivisionPatchTag.Details:
                    return Details;

                case StCompanyDivisionPatchTag.IsCreated:
                    return IsCreated;

                default:
                    return null;
            }
        }
    }
}