﻿using ImportService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace ImportService.Models.Dtos
{
    public partial class StCustomer
    {
        [DataMember(Name = "tags")]
        [JsonProperty("tags")]
        public string Tags { get; set; }

        [DataMember(Name = "is_success")]
        [JsonProperty("is_success")]
        public bool IsSuccess { get; set; }

        [Display(Name = "Details:")]
        [Column("details", TypeName = "text")]
        [DataMember(Name = "details")]
        [JsonProperty(PropertyName = "details")]
        [XmlElement(IsNullable = true)]

        public string Details { get; set; }

        public object GetValueFromTag(StCustomerPatchTag tag)
        {
            switch (tag)
            {
                case StCustomerPatchTag.CustomerUuid:
                    return CustomerExternalId;

                case StCustomerPatchTag.Details:
                    return Details;

                case StCustomerPatchTag.IsCreated:
                    return IsCreated;

                default:
                    return null;
            }
        }
    }
}