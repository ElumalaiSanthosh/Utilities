﻿using System;
using System.Runtime.Serialization;

namespace ImportService.Models.Dtos
{
    [DataContract]
    [Serializable]
    public class Notification
    {
        [DataMember(Name = "type")]
        public string Type { get; set; }

        [DataMember(Name = "ErrorCount")]
        public int ErrorCount { get; set; }

        [DataMember(Name = "SuccessCount")]
        public int SuccessCount { get; set; }
    }
}