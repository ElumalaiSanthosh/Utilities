﻿using ImportService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace ImportService.Models.Dtos
{
    public partial class StCoaAccount
    {
        [DataMember(Name = "tags")]
        [JsonProperty("tags")]
        public string Tags { get; set; }

        [DataMember(Name = "is_success")]
        [JsonProperty("is_success")]
        public bool IsSuccess { get; set; }

        [Display(Name = "Details:")]
        [Column("details", TypeName = "text")]
        [DataMember(Name = "details")]
        [JsonProperty(PropertyName = "details")]
        [XmlElement(IsNullable = true)]

        public string Details { get; set; }

        public object GetValueFromTag(StCoaAccountPatchTag tag)
        {
            switch (tag)
            {
                case StCoaAccountPatchTag.CoaUuid:
                    return CoaUuid;

                case StCoaAccountPatchTag.Details:
                    return Details;

                case StCoaAccountPatchTag.IsCreated:
                    return IsCreated;

                default:
                    return null;
            }
        }
    }
}