﻿using ImportService.Models.Enumerations;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace ImportService.Models.Dtos
{
    public partial class StVendor
    {
        [DataMember(Name = "tags")]
        [JsonProperty("tags")]
        public string Tags { get; set; }

        [DataMember(Name = "is_success")]
        [JsonProperty("is_success")]
        public bool IsSuccess { get; set; }

        [Display(Name = "Details:")]
        [Column("details", TypeName = "text")]
        [DataMember(Name = "details")]
        [JsonProperty(PropertyName = "details")]
        [XmlElement(IsNullable = true)]

        public string Details { get; set; }

        public object GetValueFromTag(StVendorPatchTag tag)
        {
            switch (tag)
            {
                case StVendorPatchTag.VendorUuid:
                    return VendorExternalId;

                case StVendorPatchTag.Details:
                    return Details;

                case StVendorPatchTag.IsCreated:
                    return IsCreated;

                default:
                    return null;
            }
        }
    }
}