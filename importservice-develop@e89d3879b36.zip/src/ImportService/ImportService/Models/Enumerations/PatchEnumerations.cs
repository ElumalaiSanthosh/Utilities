﻿namespace ImportService.Models.Enumerations
{
    public enum StCompanyDivisionPatchTag
    {
        None = 0,
        CompanyDivisionId = 1,
        Details = 2,
        IsCreated = 3
    }

    public enum StFiscalPatchTag
    {
        None = 0,
        PeriodId = 1,
        Details = 2,
        IsCreated = 3,
        FiscalId = 4
    }

    public enum StVendorPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        VendorUuid = 3
    }

    public enum StCoaAccountPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        CoaUuid = 3
    }

    public enum StSubAccountPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        CompanySubaccountId = 3
    }

    public enum StProjectChartAccountPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        CoaUuid = 3
    }

    public enum StCustomerPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        CustomerUuid = 3
    }

    public enum StProjectPatchTag
    {
        None = 0,
        Details = 1,
        IsCreated = 2,
        ProjectUuid = 3
    }
}