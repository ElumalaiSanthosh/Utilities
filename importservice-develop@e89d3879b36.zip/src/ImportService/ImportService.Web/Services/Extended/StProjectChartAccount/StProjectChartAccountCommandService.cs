﻿using ApiService.Commons.Rest;
using ImportService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    public partial class StProjectChartAccountService
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        public async Task<IEnumerable<StProjectChartAccount>> PatchManyAsync(IEnumerable<StProjectChartAccount> dtos, IDbTransaction transaction = null)
        {
            if (dtos == null || !dtos.Any())
                throw new ApiRestException(HttpStatusCode.BadRequest, "The Dto is null.");
            if (dtos?.Count() > 0)
            {
                bool handleTransaction = transaction == null;
                IDbTransaction trans = transaction ?? BeginTransaction();
                try
                {
                    var results = new List<StProjectChartAccount>();

                    foreach (var dto in dtos)
                    {
                        if (dto.StProjectChartAccountId > 0)
                        {
                            string filter = $"st_projectchart_account_id = {dto.StProjectChartAccountId}";
                            string statement = PatchHelper.GetStatement("StProjectChartAccount", PatchHelper.GetTagValueDictionary(dto), filter);
                            if (!string.IsNullOrEmpty(statement))
                            {
                                int rows = await ExecuteAsync(statement, trans);
                                dto.IsSuccess = rows > 0;
                            }
                        }
                        else
                            dto.IsSuccess = false;
                        results.Add(dto);
                    }

                    CommitTransaction(handleTransaction, trans);

                    return results;
                }
                catch (Exception)
                {
                    RollbackTransaction(handleTransaction, trans);
                    throw;
                }
            }
            return null;
        }
    }
}