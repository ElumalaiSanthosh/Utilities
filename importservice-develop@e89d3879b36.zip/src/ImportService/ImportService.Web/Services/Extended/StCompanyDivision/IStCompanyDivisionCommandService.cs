﻿using ImportService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IStCompanyDivisionService
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<IEnumerable<StCompanyDivision>> PatchManyAsync(IEnumerable<StCompanyDivision> dtos, IDbTransaction transaction = null);
    }
}