﻿using ImportService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IStProjectService
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<IEnumerable<StProject>> PatchManyAsync(IEnumerable<StProject> dtos, IDbTransaction transaction = null);
    }
}