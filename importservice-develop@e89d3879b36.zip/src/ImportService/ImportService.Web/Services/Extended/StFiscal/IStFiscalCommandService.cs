﻿using ImportService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IStFiscalService
    {
        /// <summary>
        ///PatchManyAsync
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<IEnumerable<StFiscal>> PatchManyAsync(IEnumerable<StFiscal> dtos, IDbTransaction transaction = null);
    }
}