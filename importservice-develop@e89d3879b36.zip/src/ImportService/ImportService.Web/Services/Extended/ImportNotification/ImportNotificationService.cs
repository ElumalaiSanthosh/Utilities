﻿using ApiService.Commons.DataStore;
using ImportService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial class ImportNotificationService : IImportNotificationService
    {
        private IStCompanyDivisionService StCompanyDivisionService { get; }
        private IStCoaAccountService StCoaAccountService { get; }
        private IStVendorService StVendorService { get; }
        private IStCustomerService StCustomerService { get; }
        private IStSubAccountService StSubAccountService { get; }
        private IStFiscalService StFiscalService { get; }
        private IStProjectChartAccountService StProjectChartAccountService { get; }
        private IStProjectService StProjectService { get; }

        /// <summary>
        ///
        /// </summary>
        /// <param name="stCompanyDivisionService"></param>
        /// <param name="stCoaAccountService"></param>
        /// <param name="stVendorService"></param>
        /// <param name="stCustomerService"></param>
        /// <param name="stSubAccountService"></param>
        /// <param name="stFiscalService"></param>
        /// <param name="stProjectChartAccountService"></param>
        /// <param name="stProjectService"></param>
        public ImportNotificationService(IStCompanyDivisionService stCompanyDivisionService,
                                         IStCoaAccountService stCoaAccountService,
                                         IStVendorService stVendorService,
                                         IStCustomerService stCustomerService,
                                         IStSubAccountService stSubAccountService,
                                         IStFiscalService stFiscalService,
                                         IStProjectChartAccountService stProjectChartAccountService,
                                         IStProjectService stProjectService)
        {
            StCompanyDivisionService = stCompanyDivisionService;
            StCoaAccountService = stCoaAccountService;
            StVendorService = stVendorService;
            StCustomerService = stCustomerService;
            StSubAccountService = stSubAccountService;
            StFiscalService = stFiscalService;
            StProjectChartAccountService = stProjectChartAccountService;
            StProjectService = stProjectService;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="company_uuid"></param>
        /// <returns></returns>
        public async Task<List<Notification>> GetErrorCountList(Guid company_uuid)
        {
            List<Notification> notifications = new List<Notification>();
            List<StCompanyDivision> stDivisions = await GetData<StCompanyDivision>(company_uuid, StCompanyDivisionService);
            if (stDivisions?.Count > 0)
            {
                int count = stDivisions.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Divisions",
                    ErrorCount = count,
                    SuccessCount = stDivisions.Count - count
                });
            }
            var stCOAAccounts = await GetData<StCoaAccount>(company_uuid, StCoaAccountService);
            if (stCOAAccounts?.Count > 0)
            {
                int count = stCOAAccounts.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "COA Accounts",
                    ErrorCount = count,
                    SuccessCount = stCOAAccounts.Count - count
                });
            }
            var stCustomers = await GetData<StCustomer>(company_uuid, StCustomerService);
            if (stCustomers?.Count > 0)
            {
                int count = stCustomers.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Customer",
                    ErrorCount = count,
                    SuccessCount = stCustomers.Count - count
                });
            }
            var stVendors = await GetData<StVendor>(company_uuid, StVendorService);
            if (stVendors?.Count > 0)
            {
                int count = stVendors.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Vendors",
                    ErrorCount = count,
                    SuccessCount = stVendors.Count - count
                });
            }
            var stSubAccounts = await GetData<StSubAccount>(company_uuid, StSubAccountService);
            if (stSubAccounts?.Count > 0)
            {
                int count = stSubAccounts.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Sub Accounts",
                    ErrorCount = count,
                    SuccessCount = stSubAccounts.Count - count
                });
            }
            var stFiscals = await GetData<StFiscal>(company_uuid, StFiscalService);
            if (stFiscals?.Count > 0)
            {
                int count = stFiscals.Count(x => !(x?.IsCreated ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Fiscal Periods",
                    ErrorCount = count,
                    SuccessCount = stFiscals.Count - count
                });
            }
            var stProjectChartAct = await GetData(company_uuid, StProjectChartAccountService.GetDynamicObjectsAsync, new string[] { "st_projectchart_account_id", "is_created", "coa_uuid" });
            if (stProjectChartAct.Any())
            {
                int count = stProjectChartAct.Count(x => !(x?.is_created ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Project Chart Accounts",
                    ErrorCount = count,
                    SuccessCount = stProjectChartAct.Count - count
                });
            }
            var stProjects = await GetData(company_uuid, StProjectService.GetDynamicObjectsAsync, new string[] { "st_project_id", "is_created" });
            if (stProjects.Any())
            {
                int count = stProjects.Count(x => !(x?.is_created ?? false));
                notifications.Add(new
                     Notification
                {
                    Type = "Projects",
                    ErrorCount = count,
                    SuccessCount = stProjects.Count - count
                });
            }
            return notifications;
        }

        private async Task<List<T>> GetData<T>(Guid company_uuid, dynamic service)
        {
            QueryResults<T> data = (await service.GetManyAsync(new QueryOptions { Filter = $"company_uuid eq '{company_uuid}'", Orderby = "row_number" }));
            List<T> items = new List<T>();
            if (data != null)
            {
                items = (List<T>)data.Items;
                while (data?.TotalCount > items.Count)
                {
                    data = (await service.GetManyAsync(new QueryOptions { Filter = $"company_uuid eq '{company_uuid}'", Skip = items.Count, Orderby = "row_number" }));
                    if (data != null)
                    {
                        items.AddRange(data?.Items);
                    }
                }
            }
            return items;
        }

        /// <summary>
        ///
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="company_uuid"></param>
        /// <param name="action"></param>
        /// <param name="colums"></param>
        /// <returns></returns>
        private async Task<List<T>> GetData<T>(Guid company_uuid, Func<ICollection<string>, QueryOptions, IDbTransaction, Task<QueryResults<T>>> action, ICollection<string> colums)
        {
            List<T> result = new List<T>();
            if (colums != null && colums.Any())
            {
                int skip = 0;
                do
                {
                    var options = new QueryOptions
                    {
                        Filter = $"company_uuid eq '{company_uuid}'",
                        Skip = skip,
                        Orderby = colums.First()
                    };
                    var queryResult = await action(colums, options, null);
                    if (queryResult?.Items?.Count > 0)
                    {
                        result.AddRange(queryResult.Items);
                        if (queryResult.TotalCount > result.Count)
                        {
                            skip = result.Count;
                        }
                        else skip = -1;
                    }
                    else
                        skip = -1;
                }
                while (skip > 0);
            }
            return result;
        }
    }
}