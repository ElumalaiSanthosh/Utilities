﻿using ImportService.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IImportNotificationService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="company_uuid"></param>
        /// <returns></returns>
        Task<List<Notification>> GetErrorCountList(Guid company_uuid);
    }
}