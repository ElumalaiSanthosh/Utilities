﻿using ImportService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IStCustomerService
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<IEnumerable<StCustomer>> PatchManyAsync(IEnumerable<StCustomer> dtos, IDbTransaction transaction = null);
    }
}