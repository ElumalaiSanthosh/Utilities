﻿using ImportService.Models.Dtos;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace ImportService.Web.Services
{
    /// <summary>
    ///
    /// </summary>
    public partial interface IStSubAccountService
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="dtos"></param>
        /// <param name="transaction"></param>
        /// <returns></returns>
        Task<IEnumerable<StSubAccount>> PatchManyAsync(IEnumerable<StSubAccount> dtos, IDbTransaction transaction = null);
    }
}