set search_path=importservice,public;
-- alter division
ALTER TABLE st_company_division
ALTER COLUMN division_number TYPE character varying(200),
ALTER COLUMN description TYPE character varying(200),
ALTER COLUMN is_default TYPE character varying(20) USING CASE is_default WHEN true THEN 'TRUE' ELSE 'FALSE' END,
ALTER COLUMN is_active TYPE character varying(20) USING CASE is_active WHEN true THEN 'TRUE' ELSE 'FALSE' END;

--alter project chart
ALTER TABLE st_projectchart_account
ALTER COLUMN account_id TYPE character varying(200),
ALTER COLUMN description TYPE character varying(200),
ALTER COLUMN classification TYPE character varying(200),
ALTER COLUMN override_division TYPE character varying(200),
ALTER COLUMN override_gl TYPE character varying(200),
ALTER COLUMN status TYPE character varying(20) USING CASE status WHEN true THEN 'TRUE' ELSE 'FALSE' END;

--alter coa account
ALTER TABLE st_coa_account
ALTER COLUMN account_id TYPE character varying(200),
ALTER COLUMN description TYPE character varying(200),
ALTER COLUMN classification TYPE character varying(200),
ALTER COLUMN clearing_account TYPE character varying(200),
ALTER COLUMN job_gl TYPE character varying(20) USING CASE job_gl WHEN true THEN 'TRUE' ELSE 'FALSE' END,
ALTER COLUMN status TYPE character varying(20) USING CASE status WHEN true THEN 'TRUE' ELSE 'FALSE' END;

--alter subaccount
ALTER TABLE st_sub_account
ALTER COLUMN sub_account_id TYPE character varying(200),
ALTER COLUMN sub_account_name TYPE character varying(200),
ALTER COLUMN related_accounts TYPE character varying(200),
ALTER COLUMN status TYPE character varying(20) USING CASE status WHEN true THEN 'TRUE' ELSE 'FALSE' END;

--alter fiscal
ALTER TABLE st_fiscal
ALTER COLUMN year_start_date TYPE character varying(50),
ALTER COLUMN year_end_date TYPE character varying(50),
ALTER COLUMN year_open TYPE character varying(20) USING CASE year_open WHEN true THEN 'TRUE' ELSE 'FALSE' END;

--alter import session
ALTER TABLE import_session
ALTER COLUMN file_name TYPE character varying(200),
ALTER COLUMN file_type TYPE character varying(50),
ALTER COLUMN attachement_id TYPE character varying(200);

--alter vendor
ALTER TABLE st_vendor
ALTER COLUMN vendor_name TYPE character varying(200),
ALTER COLUMN address TYPE character varying(200),
ALTER COLUMN telephone TYPE character varying(200),
ALTER COLUMN email TYPE character varying(200),
ALTER COLUMN tax_code TYPE character varying(200),
ALTER COLUMN payment_terms TYPE character varying(200),
ALTER COLUMN city TYPE character varying(200),
ALTER COLUMN zip TYPE character varying(200),
ALTER COLUMN state TYPE character varying(200),
ALTER COLUMN ssn TYPE character varying(200),
ALTER COLUMN federal_tax_id TYPE character varying(200),
ALTER COLUMN corporation TYPE character varying(200),
ALTER COLUMN vendor_type TYPE character varying(200);

--alter custome
ALTER TABLE st_customer
ALTER COLUMN customer_name TYPE character varying(200),
ALTER COLUMN address TYPE character varying(200),
ALTER COLUMN telephone TYPE character varying(200),
ALTER COLUMN email TYPE character varying(200),
ALTER COLUMN city TYPE character varying(200),
ALTER COLUMN zip TYPE character varying(200),
ALTER COLUMN state TYPE character varying(200),
ALTER COLUMN payment_terms TYPE character varying(200),
ALTER COLUMN payment_method TYPE character varying(200);

-- alter project
ALTER TABLE st_project
ALTER COLUMN project_numaber TYPE character varying(200),
ALTER COLUMN project_name TYPE character varying(200),
ALTER COLUMN product_name TYPE character varying(200),
ALTER COLUMN director TYPE character varying(200),
ALTER COLUMN sales_rep TYPE character varying(200),
ALTER COLUMN agency TYPE character varying(200),
ALTER COLUMN detail_report TYPE character varying(200),
ALTER COLUMN reporting_type TYPE character varying(200),
ALTER COLUMN wrap_up_insurance TYPE character varying(200),
ALTER COLUMN shoot_dates TYPE character varying(200),
ALTER COLUMN shoot_location TYPE character varying(200),
ALTER COLUMN agency_producer TYPE character varying(200);