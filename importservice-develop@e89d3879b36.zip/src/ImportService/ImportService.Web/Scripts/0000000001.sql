SET search_path=importservice,public;


CREATE TABLE st_company_division
(
	st_company_division_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	division_number CHARACTER VARYING(50),
	description CHARACTER VARYING(100),
	is_default boolean,
	is_active boolean DEFAULT true,
	company_division_id integer,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE st_projectchart_account
(
	st_projectchart_account_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	account_id CHARACTER VARYING(50),
	description CHARACTER VARYING(100),
	classification CHARACTER VARYING(50),
	override_division CHARACTER VARYING(50),
	override_gl CHARACTER VARYING(50),
	status boolean,
	coa_uuid uuid,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE st_coa_account
(
	st_coa_account_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	account_id CHARACTER VARYING(50),
	description CHARACTER VARYING(100),
	classification CHARACTER VARYING(50),
	clearing_account CHARACTER VARYING(50),
	elimination_account boolean,
	job_gl boolean,
	status boolean,
	coa_uuid uuid,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE st_sub_account
(
	st_sub_accounts_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	sub_account_id CHARACTER VARYING(50),
	sub_account_name CHARACTER VARYING(50),
	related_accounts CHARACTER VARYING(50),
	status boolean DEFAULT true,
	company_subaccount_id integer,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE st_fiscal
(
	st_fiscal_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	year_start_date CHARACTER VARYING(20),
	year_end_date CHARACTER VARYING(20),
	year_open boolean,
	period_id integer,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE import_session
(
	import_session_id BIGSERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	file_name CHARACTER VARYING(50),
	file_type CHARACTER VARYING(30),
	attachement_id CHARACTER VARYING(50),
	details CHARACTER VARYING(150),
	is_uploaded boolean,
	created_ts date DEFAULT CURRENT_DATE,
	created_by uuid
);

CREATE TABLE st_vendor(
    st_vendor_id SERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
    vendor_name CHARACTER VARYING(100),
	address CHARACTER VARYING(200),
	telephone CHARACTER VARYING(50),
	email CHARACTER VARYING(50),
	tax_code CHARACTER VARYING(50),
	payment_terms CHARACTER VARYING(20),
	city CHARACTER VARYING(100),
	zip CHARACTER VARYING(10),
	state CHARACTER VARYING(100),
	ssn CHARACTER VARYING(50),
	federal_tax_id CHARACTER VARYING(20),
	corporation CHARACTER VARYING(50),
	vendor_type CHARACTER VARYING(20),
	vendor_uuid uuid,
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
	);

CREATE TABLE st_customer(
    st_customer_id SERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
    customer_name CHARACTER VARYING(100),
	address CHARACTER VARYING(200),
	telephone CHARACTER VARYING(50),
	email CHARACTER VARYING(50),
	city CHARACTER VARYING(50),
	zip CHARACTER VARYING(10),
	state CHARACTER VARYING(50),
	payment_terms CHARACTER VARYING(20),
	payment_method CHARACTER VARYING(20),
    customer_uuid uuid,
	currency CHARACTER VARYING(20),
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
);

CREATE TABLE st_project(
	st_project_id SERIAL PRIMARY KEY,
	company_uuid uuid NOT NULL,
	project_numaber CHARACTER VARYING(50),
	project_name CHARACTER VARYING(50),
	product_name CHARACTER VARYING(50),
	director CHARACTER VARYING(50),
	sales_rep CHARACTER VARYING(50),
	agency CHARACTER VARYING(50),
	status CHARACTER VARYING(20),
	detail_report CHARACTER VARYING(50),
	reporting_type CHARACTER VARYING(20),
	shoot_dates CHARACTER VARYING(100),
	shoot_location CHARACTER VARYING(100),
	wrap_up_insurance CHARACTER VARYING(20),
	agency_producer CHARACTER VARYING(50),
	project_coa CHARACTER VARYING(20),
	project_type CHARACTER VARYING(20),
	details CHARACTER VARYING(150),
	is_created boolean,
	row_number integer
	);