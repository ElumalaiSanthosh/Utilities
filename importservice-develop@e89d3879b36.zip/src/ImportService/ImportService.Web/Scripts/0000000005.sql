set search_path=importservice,public;
--alter project
ALTER TABLE st_project
ADD COLUMN project_uuid uuid;

--Rename column
ALTER TABLE st_project 
RENAME COLUMN project_numaber TO project_number;