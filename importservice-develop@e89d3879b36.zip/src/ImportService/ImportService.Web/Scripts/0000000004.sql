set search_path=importservice,public;
--alter vendor
ALTER TABLE st_vendor
ALTER COLUMN vendor_name TYPE character varying(300);

--alter custome
ALTER TABLE st_customer
ALTER COLUMN customer_name TYPE character varying(300);