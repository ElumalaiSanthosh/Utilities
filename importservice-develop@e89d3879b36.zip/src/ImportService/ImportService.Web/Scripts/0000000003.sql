set search_path=importservice,public;
-- alter division
ALTER TABLE st_company_division
ALTER COLUMN details TYPE character varying(1500);

--alter project chart
ALTER TABLE st_projectchart_account
ALTER COLUMN details TYPE character varying(1500);

--alter coa account
ALTER TABLE st_coa_account
ALTER COLUMN details TYPE character varying(1500);

--alter subaccount
ALTER TABLE st_sub_account
ALTER COLUMN details TYPE character varying(1500);

--alter fiscal
ALTER TABLE st_fiscal
ALTER COLUMN details TYPE character varying(1500);

--alter vendor
ALTER TABLE st_vendor
ALTER COLUMN details TYPE character varying(1500);

--alter custome
ALTER TABLE st_customer
ALTER COLUMN details TYPE character varying(1500);

-- alter project
ALTER TABLE st_project
ALTER COLUMN details TYPE character varying(1500);