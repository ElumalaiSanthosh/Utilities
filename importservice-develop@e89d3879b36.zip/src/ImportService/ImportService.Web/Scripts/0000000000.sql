/*
--create database
CREATE DATABASE "ca-importservice"
    WITH
    OWNER = caimsv_admin
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    CONNECTION LIMIT = -1;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

GRANT ALL ON DATABASE "ca-importservice" TO caimsv_admin;


--create schema
CREATE SCHEMA importservice AUTHORIZATION caimsv_admin;

GRANT ALL ON SCHEMA importservice TO caimsv_admin WITH GRANT OPTION;
GRANT ALL ON SCHEMA importservice TO caimsv_write WITH GRANT OPTION;
GRANT USAGE ON SCHEMA importservice TO caimsv_read;

ALTER DEFAULT PRIVILEGES IN SCHEMA importservice
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO caimsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA importservice
GRANT SELECT, USAGE ON SEQUENCES TO caimsv_write;

ALTER DEFAULT PRIVILEGES IN SCHEMA importservice
GRANT INSERT, SELECT, UPDATE, DELETE ON TABLES TO caimsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA importservice
GRANT SELECT, USAGE ON SEQUENCES TO caimsv_admin;

ALTER DEFAULT PRIVILEGES IN SCHEMA importservice GRANT SELECT ON TABLES TO caimsv_read;

SET search_path=importservice,public;

CREATE TABLE db_properties
(
    db_properties_id SERIAL PRIMARY KEY,
    last_update timestamp,
    host_name character varying(255),
    script character varying(255)
);
*/
