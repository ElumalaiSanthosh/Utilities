/*
Created by ProjectBuilder Version: 1.0.4.52
On: 4/15/2020 4:31:31 PM
*/

using ImportService.Models.Dtos;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using ImportService.Web.Services;
using ApiService.Commons.Logger;
using ApiService.Controllers;

namespace ImportService.Web.Controllers
{
    /// <summary>
    /// Provides API methods for the ImportNotificationController
    /// </summary>
    [Route("importnotification")]
    [Produces("application/json")]
    public partial class ImportNotificationController : DefaultApiController
    {
        private IImportNotificationService ImportNotificationService { get; }
        /// <summary>
        ///
        /// </summary>
        public ImportNotificationController(IImportNotificationService importNotificationService) : base(ApiLogging.CreateLogger<ImportNotificationController>())
        {
            ImportNotificationService = importNotificationService;
        }

        // <summary>
        /// Returns a error list
        /// </summary>
        /// <param name="company_uuid"></param>
        /// <returns></returns>
        /// <response code="200">Record found and returned</response>
        /// <response code="204">Record Not found</response>
        /// <response code="400">Bad Request - The request is malformed or invalid</response>
        /// <response code="401">Unauthorized - The request requires user authentication </response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="404">Record not found for id</response>
        /// <response code="410">The requested resource is no longer available at the server and no forwarding address is known </response>
        /// <response code="414">Request-URI Too Long - The server is refusing to service the request because the Request-URI is longer than the server is willing to interpret </response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>

        [HttpGet("importstatus")]
        public async Task<IActionResult> GetErrorCount(Guid company_uuid)
        {
            try
            {
                var result = await ImportNotificationService.GetErrorCountList(company_uuid);

                if (result != null) return Ok(result);

                return NoContent();
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }


    }
}
