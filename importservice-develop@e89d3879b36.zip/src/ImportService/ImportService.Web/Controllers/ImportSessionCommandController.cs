/*
Created by ProjectBuilder Version: 1.0.4.52
On: 4/15/2020 4:31:31 PM
*/

using ImportService.Models.Dtos;
using Microsoft.ApplicationInsights.AspNetCore.Extensions;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ImportService.Web.Controllers
{
    public partial class ImportSessionsController
    {
        /// <summary>
        /// Creates a ImportSession record using the provided importSession object.
        /// </summary>
        /// <param name="dtos"></param>
        /// <returns></returns>
        /// <response code="201">Created - The request has been fulfilled and resulted in a new resource being created</response>
        /// <response code="202">Accepted - The request has been accepted for processing, but the processing has not been completed</response>
        /// <response code="205">Reset Content - The server has fulfilled the request and the user agent SHOULD reset the document view which caused the request to be sent</response>
        /// <response code="400">Bad Request - The request could not be understood by the server due to malformed syntax</response>
        /// <response code="401">Unauthorized - The request requires user authentication</response>
        /// <response code="403">Forbidden - The server understood the request, but is refusing to fulfill it </response>
        /// <response code="409">Conflict - The request could not be completed due to a conflict with the current state of the resource</response>
        /// <response code="500">Internal Server Error - The server encountered an unexpected condition which prevented it from fulfilling the request</response>
        [HttpPost("postmany")]
        [ProducesResponseType(201, Type = typeof(ImportSession))]
        public async Task<IActionResult> PostManyAsync([FromBody, Required]List<ImportSession> dtos)
        {
            try
            {
                var result = await ImportSessionService.PostAsync(dtos);

                var location = $"{Request.GetUri().AbsoluteUri}/{result?.FirstOrDefault()?.ImportSessionId}";
                return Created(location, result);
            }
            catch (Exception e)
            {
                return HandleException(e);
            }
        }
    }
}
