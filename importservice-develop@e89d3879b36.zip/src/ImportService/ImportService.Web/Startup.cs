﻿using System;
using System.IO;
using System.Linq;
using System.Reflection;
using ApiService.DataStore;
using ApiService.Extensions;
using ApiService.Middleware;
using ApiService.Commons.Logger;
using Microsoft.AspNet.OData.Extensions;
using Microsoft.AspNet.OData.Formatter;
using Microsoft.AspNet.OData.Query;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using ImportService.Web.Extensions;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using System.Diagnostics.CodeAnalysis;
using ApiService.Configuration;
using ApiService.Util;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data.Common;
using System.Runtime.Versioning;
using ImportService.Web.Services;

namespace ImportService.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class Startup
    {
        private readonly IHostingEnvironment _env;

        private DbUpdateConfig DbUpdateConfig { get; }

        /// <summary>
        /// 
        /// </summary>
        public static string ApplicationRootDirectory { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public static void RunAfterStartup(IServiceProvider serviceProvider)
        {
            using (var serviceScope = serviceProvider.CreateScope())
            {
                var services = serviceScope.ServiceProvider;
                var dataStoreProvider = services.GetRequiredService<IDataStoreProvider>();
                var config = services.GetRequiredService<IConfiguration>();
                if (config.GetChildren().Any(x => x.Key == "DbUpdateConfig"))
                {
                    DbUpdateUtil.Update(config, dataStoreProvider);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public static Dictionary<string, string> GetActuatorProperties(IConfiguration configuration)
        {
            string basePath = configuration["spring:application:name"];

            var assembly = typeof(Startup).Assembly;
            var actuatorProperties = new Dictionary<string, string>
            {
                { "management:endpoints:path", $"/{basePath}/actuator" },
                { "info:build:version", assembly.GetName().Version.ToString() },
                { "info:build:artifact", assembly.GetName().Name },
                { "info:runtime-version", assembly.GetCustomAttribute<TargetFrameworkAttribute>()?.FrameworkName },
                { "info:git:branch", ThisAssembly.Git.Branch },
                { "info:git:commit:id", ThisAssembly.Git.Commit }
            };
            return actuatorProperties;
        }

        /// <summary>
        /// 
        /// </summary>
        public static Dictionary<string, string> GetConnectionStrings(IConfiguration configuration)
        {
            var connectionStrings = new Dictionary<string, string>();

            AddConnectionString(configuration, "PostgresSql", connectionStrings);
            AddConnectionString(configuration, "SQLServer", connectionStrings);

            return connectionStrings;
        }

        private static void AddConnectionString(IConfiguration configuration, string connectionName,
            Dictionary<string, string> connectionStrings)
        {
            var rootKey = "ConnectionStrings:" + connectionName;
            DbConnectionStringBuilder builder = new DbConnectionStringBuilder
            {
                ConnectionString = configuration[rootKey]
            };

            foreach (var csProperty in configuration.GetSection(rootKey + "Properties").GetChildren())
            {
                builder[csProperty.Key] = csProperty.Value;
            }

            if (!String.IsNullOrEmpty(builder.ConnectionString))
            {
                connectionStrings.Add(rootKey, builder.ConnectionString);
            }

            if (connectionName.Equals(configuration["DbUpdateConfig:ConnectionStringName"]))
            {
                if (builder.ContainsKey("Host") && builder["Host"] != null)
                {
                    connectionStrings.Add("DbUpdateConfig:ServerName", builder["Host"].ToString());
                }
                if (builder.ContainsKey("Database") && builder["Database"] != null)
                {
                    connectionStrings.Add("DbUpdateConfig:DatabaseName", builder["Database"].ToString());
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        /// <param name="env"></param>
        [ExcludeFromCodeCoverage]
        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            _env = env;
            ApplicationRootDirectory = env.ContentRootPath;
            Configuration = configuration;
            if (Configuration.GetChildren().Any(x => x.Key == "DbUpdateConfig"))
            {
                DbUpdateConfig = new DbUpdateConfig(Configuration);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        [ExcludeFromCodeCoverage]
        public IConfiguration Configuration { get; }


        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        [ExcludeFromCodeCoverage]
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<IISOptions>(options =>
            {
                options.ForwardClientCertificate = false;
            });

            services.AddSingleton(Configuration);

            //#region Redis
            //services.AddDistributedRedisCache(options =>
            //{
            //    options.Configuration = Configuration.GetValue<string>("redis:Configuration");
            //    options.InstanceName = Configuration.GetValue<string>("redis:InstanceName");
            //});
            //services.AddSingleton(typeof(IApiCache<>), typeof(ApiRedisCache<>));
            //#endregion Redis

            //this needs to be set by builder for the type of datastore you are using. Default is SQLServer
            if (DbUpdateConfig != null && DbUpdateConfig.ConnectionStringName == "SQLServer")
            {
                services.AddScoped(typeof(IDataStoreProvider), typeof(SqlServerDataStoreProvider));
            }
            else
            {
                services.AddScoped(typeof(IDataStoreProvider), typeof(PostgresDataStoreProvider));
            }
            services.RegisterGeneratedServices();
            services.RegisterApiServices();
            services.AddTransient<IImportNotificationService, ImportNotificationService>();

            services.AddOData();
            services.AddMvc().AddJsonOptions(options =>
            {
            //options.SerializerSettings.ContractResolver = new DefaultContractResolver();
            options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                options.SerializerSettings.DateTimeZoneHandling = Newtonsoft.Json.DateTimeZoneHandling.Utc;
                options.SerializerSettings.Formatting = Newtonsoft.Json.Formatting.Indented;
                options.SerializerSettings.TypeNameHandling = TypeNameHandling.None;
                options.SerializerSettings.FloatParseHandling = FloatParseHandling.Decimal;
                options.SerializerSettings.Converters = new List<JsonConverter> { new DecimalStringConverter() };
            });

            //This is for compression
            services.Configure<GzipCompressionProviderOptions>(options => options.Level = System.IO.Compression.CompressionLevel.Optimal);
            services.AddResponseCompression(options =>
            {
                options.MimeTypes = new[]
                {
			  // Default
			  "text/plain",
              "text/css",
              "application/javascript",
              "text/html",
              "application/xml",
              "text/xml",
              "application/json",
              "text/json",
			  // Custom
			  "image/svg+xml"
                };
            });

            //swagger
            services.AddMvcCore(options =>
            {
                foreach (var outputFormatter in options.OutputFormatters.OfType<ODataOutputFormatter>().Where(_ => _.SupportedMediaTypes.Count == 0))
                {
                    outputFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/prs.odatatestxx-odata"));
                }
                foreach (var inputFormatter in options.InputFormatters.OfType<ODataInputFormatter>().Where(_ => _.SupportedMediaTypes.Count == 0))
                {
                    inputFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/prs.odatatestxx-odata"));
                }
            });

            string basePath = PlatformServices.Default.Application.ApplicationBasePath;
            string xmlPath = Path.Combine(basePath, "ImportService.Web.xml");

            string title = $"ImportService.Web({Assembly.GetEntryAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion}) API";
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1",
                      new Info
                      {
                          Version = "v1",
                          Title = title,
                      //Description = "A sample API for testing Swashbuckle",
                      //TermsOfService = "Some terms ..."
                  }
                    );
                c.IncludeXmlComments(xmlPath);
                c.DescribeAllEnumsAsStrings();
                c.OperationFilter<ODataOperationFilter>();
            });
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        /// <param name="loggerFactory"></param>
        [ExcludeFromCodeCoverage]
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            string basePath = Configuration["spring:application:name"];
            if (!string.IsNullOrEmpty(basePath))
            {
                app.UsePathBase("/" + basePath);
            }

            //add NLog to ASP.NET Core
            loggerFactory.AddNLog();

            ApiLogging.LoggerFactory = loggerFactory;

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //these are for compression
            app.UseResponseCompression();
            app.UseMiddleware<GzipRequestMiddleware>();

            //Adding Model class to OData
            var builder = app.RegisterOdataEntities();
            app.UseMvc(routebuilder =>
            {
                routebuilder.MapODataServiceRoute("odata", "odata", builder.GetEdmModel());
                routebuilder.EnableDependencyInjection();
            });

            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swagger, httpReq) => swagger.Host = httpReq.Host.Value);
            });

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "ImportService V1");
                c.ShowExtensions();
            });
        }

        private class ODataOperationFilter : IOperationFilter
        {
            /// <summary>
            /// 
            /// </summary>
            /// <param name="operation"></param>
            /// <param name="context"></param>
            [ExcludeFromCodeCoverage]
            public void Apply(Operation operation, OperationFilterContext context)
            {
                if (context.ApiDescription.ParameterDescriptions.Select(p => p.ParameterDescriptor.ParameterType).All(t => t.BaseType != typeof(ODataQueryOptions)))
                {
                    return;
                }

                operation.Parameters = operation.Parameters.Where(p => p.In != "query").ToList();
                operation.Parameters.Insert(0, new NonBodyParameter { Name = "$skip", In = "query", Description = "Skips the first n results.", Type = "integer", Required = false });
                operation.Parameters.Insert(0, new NonBodyParameter { Name = "$top", In = "query", Description = "Returns only the first n results.", Type = "integer", Required = false });
                operation.Parameters.Insert(0, new NonBodyParameter { Name = "$orderby", In = "query", Description = "Sorts the results.", Type = "string", Required = false });
                operation.Parameters.Insert(0, new NonBodyParameter { Name = "$filter", In = "query", Description = "Filters the results, based on a Boolean condition.", Type = "string", Required = false });
            }
        }

        internal class DecimalStringConverter : JsonConverter<Decimal>
        {
            public override void WriteJson(JsonWriter writer, decimal value, JsonSerializer serializer)
            {
                writer.WriteValue(value.ToString());
            }

            public override decimal ReadJson(JsonReader reader, Type objectType, decimal existingValue, bool hasExistingValue, JsonSerializer serializer)
            {
                return Convert.ToDecimal(reader.Value);
            }
        }
    }
}
