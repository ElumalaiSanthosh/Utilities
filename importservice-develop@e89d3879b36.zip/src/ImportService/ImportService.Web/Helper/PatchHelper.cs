﻿using ImportService.Models.Dtos;
using ImportService.Models.Enumerations;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ImportService.Web
{
    /// <summary>
    ///
    /// </summary>
    public static class PatchHelper
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="tagValuePairs"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public static string GetStatement(string entityName, Dictionary<string, object> tagValuePairs, string filter)
        {
            if (tagValuePairs?.Count > 0 && !string.IsNullOrEmpty(entityName) && !string.IsNullOrEmpty(filter))
            {
                string[] tags = tagValuePairs.Keys.ToArray();
                string appPath = Startup.ApplicationRootDirectory;
                string xmlPath = Path.Combine(appPath, "PatchOperation.xml");
                XDocument doc = XDocument.Load(xmlPath);
                var columns = from entity in doc.Descendants("Entity")
                              where entity.Attribute("Name").Value == entityName
                              from column in entity.Descendants("Property")
                              where tags.Contains(column.Attribute("Tag").Value)
                              select new
                              {
                                  tableName = entity.Attribute("Table").Value,
                                  schemaName = entity.Attribute("Schema").Value,
                                  columnName = column.Attribute("DbName").Value,

                                  tag = column.Attribute("Tag").Value
                              };
                if (columns?.Count() > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    var first = columns.FirstOrDefault();
                    sb.Append($"update {first.schemaName}.{first.tableName} set ");
                    string[] assignments = new string[columns.Count()];
                    for (int i = 0; i < columns.Count(); i++)
                    {
                        assignments[i] = $"{columns.ElementAt(i).columnName}={tagValuePairs[columns.ElementAt(i).tag].ToSqlCompatibleValue()}";
                    }
                    sb.Append(string.Join(',', assignments));
                    sb.Append($" where {filter}");
                    return sb.ToString();
                }
            }
            return null;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="Value"></param>
        /// <returns></returns>
        private static string ToSqlCompatibleValue(this object Value)
        {
            if (Value == null)
                return "null";
            else
            {
                switch (Convert.GetTypeCode(Value.GetType()))
                {
                    case TypeCode.Boolean:
                    case TypeCode.Decimal:
                    case TypeCode.Double:
                    case TypeCode.Int16:
                    case TypeCode.Int32:
                    case TypeCode.Int64:
                        return Value.ToString();

                    default:
                        return $"'{Value.ToString().ToDbCompatibleString()}'";
                }
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public static Dictionary<string, object> GetTagValueDictionary(object dto)
        {
            Dictionary<string, object> tagValueDictionary = null;
            if (dto is StCompanyDivision && !string.IsNullOrEmpty((dto as StCompanyDivision).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StCompanyDivision).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StCompanyDivisionPatchTag enumTag = tag.ToEnum<StCompanyDivisionPatchTag>();
                    if (enumTag != StCompanyDivisionPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StCompanyDivision).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StVendor && !string.IsNullOrEmpty((dto as StVendor).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StVendor).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StVendorPatchTag enumTag = tag.ToEnum<StVendorPatchTag>();
                    if (enumTag != StVendorPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StVendor).GetValueFromTag(enumTag));
                    }
                }
            }
            else if(dto is StCoaAccount && !string .IsNullOrEmpty((dto as StCoaAccount).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StCoaAccount).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StCoaAccountPatchTag enumTag = tag.ToEnum<StCoaAccountPatchTag>();
                    if (enumTag != StCoaAccountPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StCoaAccount).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StSubAccount && !string.IsNullOrEmpty((dto as StSubAccount).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StSubAccount).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StSubAccountPatchTag enumTag = tag.ToEnum<StSubAccountPatchTag>();
                    if (enumTag != StSubAccountPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StSubAccount).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StProjectChartAccount && !string.IsNullOrEmpty((dto as StProjectChartAccount).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StProjectChartAccount).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StProjectChartAccountPatchTag enumTag = tag.ToEnum<StProjectChartAccountPatchTag>();
                    if (enumTag != StProjectChartAccountPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StProjectChartAccount).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StCustomer && !string.IsNullOrEmpty((dto as StCustomer).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StCustomer).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StCustomerPatchTag enumTag = tag.ToEnum<StCustomerPatchTag>();
                    if (enumTag != StCustomerPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StCustomer).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StProject && !string.IsNullOrEmpty((dto as StProject).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StProject).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StProjectPatchTag enumTag = tag.ToEnum<StProjectPatchTag>();
                    if (enumTag != StProjectPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StProject).GetValueFromTag(enumTag));
                    }
                }
            }
            else if (dto is StFiscal && !string.IsNullOrEmpty((dto as StFiscal).Tags))
            {
                tagValueDictionary = new Dictionary<string, object>();
                string[] tags = (dto as StFiscal).Tags.Split(',');
                foreach (var tag in tags)
                {
                    StFiscalPatchTag enumTag = tag.ToEnum<StFiscalPatchTag>();
                    if (enumTag != StFiscalPatchTag.None)
                    {
                        tagValueDictionary.Add(tag, (dto as StFiscal).GetValueFromTag(enumTag));
                    }
                }
            }
            return tagValueDictionary;
        }
    }
}