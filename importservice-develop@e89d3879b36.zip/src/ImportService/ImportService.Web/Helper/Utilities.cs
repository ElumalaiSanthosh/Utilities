﻿using System;

namespace ImportService.Web
{
    /// <summary>
    ///
    /// </summary>
    public static class Utilities
    {
        /// <summary>
        /// Parse String to Enum
        /// </summary>
        /// <typeparam name="TEnum"></typeparam>
        /// <param name="value"></param>
        /// <returns></returns>
        public static TEnum ToEnum<TEnum>(this string value) where TEnum : struct
        {
            return Enum.TryParse(value, true, out TEnum result) ? result : default;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToDbCompatibleString(this string value)
        {
            return value?.Replace("'", "''");
        }
    }
}