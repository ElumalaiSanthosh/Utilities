﻿using System;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using System.Diagnostics.CodeAnalysis;
using Steeltoe.Extensions.Configuration.ConfigServer;
using Microsoft.Extensions.Configuration;
using Steeltoe.Management.CloudFoundry;

namespace ImportService.Web
{
    /// <summary>
    /// 
    /// </summary>
    public class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
		[ExcludeFromCodeCoverage]
        public static void Main(string[] args)
        {
            var logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

            try
            {
                var host = BuildWebHost(args);
                Startup.RunAfterStartup(host.Services);
                host.Run();
            }
            catch (Exception ex)
            {
                //NLog: catch setup errors
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                NLog.LogManager.Shutdown();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
		[ExcludeFromCodeCoverage]
        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .AddConfigServer()
                .ConfigureAppConfiguration((hostingContext, config) =>
                {
                    var initialConfig = config.Build();
                    config.AddInMemoryCollection(Startup.GetActuatorProperties(initialConfig));
                    config.AddInMemoryCollection(Startup.GetConnectionStrings(initialConfig));
                })
                .AddCloudFoundryActuators()
                .UseKestrel()
                .UseIISIntegration()
                .UseStartup<Startup>()
                .Build();
    }
}
