﻿using ImportService.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace ImportService.Tests
{
    [TestClass]
    public class PatchHelperTest
    {
        [TestInitialize]
        public void SetUp()
        {
            string rootpath = TestHelper.GetRootPath();
            Startup.ApplicationRootDirectory = rootpath.Substring(0, rootpath.Length - 5) + "Web";
        }

        [TestMethod]
        public void GetStatementTest()
        {
            Dictionary<string, object> tagValuePairs = new Dictionary<string, object>();
            tagValuePairs.Add("VendorUuid", Guid.Empty);
            tagValuePairs.Add("IsCreated", true);
            string filter = "st_vendor_id eq 1";
            string s = PatchHelper.GetStatement("StVendor", tagValuePairs, filter);
            Assert.IsNotNull(s);
        }
    }
}
