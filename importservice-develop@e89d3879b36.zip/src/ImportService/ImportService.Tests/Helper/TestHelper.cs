﻿using System;
using System.IO;

namespace ImportService.Tests
{
    public static class TestHelper
    {
        public static string GetRootPath()
        {
            return Environment.CurrentDirectory.GetRootPath();
        }

        private static string GetRootPath(this string path)
        {
            if (path.EndsWith(".Tests"))
                return path;
            else
            {
                return GetRootPath(Directory.GetParent(path).FullName);
            }
        }
    }
}